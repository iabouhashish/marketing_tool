from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.agentic_annotation_response import AgenticAnnotationResponse





T = TypeVar("T", bound="ListAgenticAnnotationsResponse")



@_attrs_define
class ListAgenticAnnotationsResponse:
    """ 
        Attributes:
            annotations (list[AgenticAnnotationResponse]): List of annotations
            count (int): Total number of annotations
     """

    annotations: list[AgenticAnnotationResponse]
    count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.agentic_annotation_response import AgenticAnnotationResponse
        annotations = []
        for annotations_item_data in self.annotations:
            annotations_item = annotations_item_data.to_dict()
            annotations.append(annotations_item)



        count = self.count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "annotations": annotations,
            "count": count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agentic_annotation_response import AgenticAnnotationResponse
        d = dict(src_dict)
        annotations = []
        _annotations = d.pop("annotations")
        for annotations_item_data in (_annotations):
            annotations_item = AgenticAnnotationResponse.from_dict(annotations_item_data)



            annotations.append(annotations_item)


        count = d.pop("count")

        list_agentic_annotations_response = cls(
            annotations=annotations,
            count=count,
        )


        list_agentic_annotations_response.additional_properties = d
        return list_agentic_annotations_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
