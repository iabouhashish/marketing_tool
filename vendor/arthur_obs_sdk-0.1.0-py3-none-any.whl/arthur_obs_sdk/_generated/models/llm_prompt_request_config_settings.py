from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.reasoning_effort_enum import ReasoningEffortEnum
from ..models.tool_choice_enum import ToolChoiceEnum
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.llm_response_format import LLMResponseFormat
  from ..models.logit_bias_item import LogitBiasItem
  from ..models.tool_choice import ToolChoice
  from ..models.anthropic_thinking_param import AnthropicThinkingParam
  from ..models.stream_options import StreamOptions





T = TypeVar("T", bound="LLMPromptRequestConfigSettings")



@_attrs_define
class LLMPromptRequestConfigSettings:
    """ 
        Attributes:
            timeout (float | None | Unset): Request timeout in seconds
            temperature (float | None | Unset): Sampling temperature (0.0 to 2.0). Higher values make output more random
            top_p (float | None | Unset): Top-p sampling parameter (0.0 to 1.0). Alternative to temperature
            max_tokens (int | None | Unset): Maximum number of tokens to generate in the response
            stop (None | str | Unset): Stop sequence(s) where the model should stop generating
            presence_penalty (float | None | Unset): Presence penalty (-2.0 to 2.0). Positive values penalize new tokens
                based on their presence
            frequency_penalty (float | None | Unset): Frequency penalty (-2.0 to 2.0). Positive values penalize tokens based
                on frequency
            seed (int | None | Unset): Random seed for reproducible outputs
            logprobs (bool | None | Unset): Whether to return log probabilities of output tokens
            top_logprobs (int | None | Unset): Number of most likely tokens to return log probabilities for (1-20)
            logit_bias (list[LogitBiasItem] | None | Unset): Modify likelihood of specified tokens appearing in completion
            max_completion_tokens (int | None | Unset): Maximum number of completion tokens (alternative to max_tokens)
            reasoning_effort (None | ReasoningEffortEnum | Unset): Reasoning effort level for models that support it (e.g.,
                OpenAI o1 series)
            thinking (AnthropicThinkingParam | None | Unset): Anthropic-specific thinking parameter for Claude models
            response_format (LLMResponseFormat | None | Unset): Response format specification (e.g., {'type': 'json_object'}
                for JSON mode)
            tool_choice (None | ToolChoice | ToolChoiceEnum | Unset): Tool choice configuration ('auto', 'none', 'required',
                or a specific tool selection)
            stream_options (None | StreamOptions | Unset): Additional streaming configuration options
     """

    timeout: float | None | Unset = UNSET
    temperature: float | None | Unset = UNSET
    top_p: float | None | Unset = UNSET
    max_tokens: int | None | Unset = UNSET
    stop: None | str | Unset = UNSET
    presence_penalty: float | None | Unset = UNSET
    frequency_penalty: float | None | Unset = UNSET
    seed: int | None | Unset = UNSET
    logprobs: bool | None | Unset = UNSET
    top_logprobs: int | None | Unset = UNSET
    logit_bias: list[LogitBiasItem] | None | Unset = UNSET
    max_completion_tokens: int | None | Unset = UNSET
    reasoning_effort: None | ReasoningEffortEnum | Unset = UNSET
    thinking: AnthropicThinkingParam | None | Unset = UNSET
    response_format: LLMResponseFormat | None | Unset = UNSET
    tool_choice: None | ToolChoice | ToolChoiceEnum | Unset = UNSET
    stream_options: None | StreamOptions | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.llm_response_format import LLMResponseFormat
        from ..models.logit_bias_item import LogitBiasItem
        from ..models.tool_choice import ToolChoice
        from ..models.anthropic_thinking_param import AnthropicThinkingParam
        from ..models.stream_options import StreamOptions
        timeout: float | None | Unset
        if isinstance(self.timeout, Unset):
            timeout = UNSET
        else:
            timeout = self.timeout

        temperature: float | None | Unset
        if isinstance(self.temperature, Unset):
            temperature = UNSET
        else:
            temperature = self.temperature

        top_p: float | None | Unset
        if isinstance(self.top_p, Unset):
            top_p = UNSET
        else:
            top_p = self.top_p

        max_tokens: int | None | Unset
        if isinstance(self.max_tokens, Unset):
            max_tokens = UNSET
        else:
            max_tokens = self.max_tokens

        stop: None | str | Unset
        if isinstance(self.stop, Unset):
            stop = UNSET
        else:
            stop = self.stop

        presence_penalty: float | None | Unset
        if isinstance(self.presence_penalty, Unset):
            presence_penalty = UNSET
        else:
            presence_penalty = self.presence_penalty

        frequency_penalty: float | None | Unset
        if isinstance(self.frequency_penalty, Unset):
            frequency_penalty = UNSET
        else:
            frequency_penalty = self.frequency_penalty

        seed: int | None | Unset
        if isinstance(self.seed, Unset):
            seed = UNSET
        else:
            seed = self.seed

        logprobs: bool | None | Unset
        if isinstance(self.logprobs, Unset):
            logprobs = UNSET
        else:
            logprobs = self.logprobs

        top_logprobs: int | None | Unset
        if isinstance(self.top_logprobs, Unset):
            top_logprobs = UNSET
        else:
            top_logprobs = self.top_logprobs

        logit_bias: list[dict[str, Any]] | None | Unset
        if isinstance(self.logit_bias, Unset):
            logit_bias = UNSET
        elif isinstance(self.logit_bias, list):
            logit_bias = []
            for logit_bias_type_0_item_data in self.logit_bias:
                logit_bias_type_0_item = logit_bias_type_0_item_data.to_dict()
                logit_bias.append(logit_bias_type_0_item)


        else:
            logit_bias = self.logit_bias

        max_completion_tokens: int | None | Unset
        if isinstance(self.max_completion_tokens, Unset):
            max_completion_tokens = UNSET
        else:
            max_completion_tokens = self.max_completion_tokens

        reasoning_effort: None | str | Unset
        if isinstance(self.reasoning_effort, Unset):
            reasoning_effort = UNSET
        elif isinstance(self.reasoning_effort, ReasoningEffortEnum):
            reasoning_effort = self.reasoning_effort.value
        else:
            reasoning_effort = self.reasoning_effort

        thinking: dict[str, Any] | None | Unset
        if isinstance(self.thinking, Unset):
            thinking = UNSET
        elif isinstance(self.thinking, AnthropicThinkingParam):
            thinking = self.thinking.to_dict()
        else:
            thinking = self.thinking

        response_format: dict[str, Any] | None | Unset
        if isinstance(self.response_format, Unset):
            response_format = UNSET
        elif isinstance(self.response_format, LLMResponseFormat):
            response_format = self.response_format.to_dict()
        else:
            response_format = self.response_format

        tool_choice: dict[str, Any] | None | str | Unset
        if isinstance(self.tool_choice, Unset):
            tool_choice = UNSET
        elif isinstance(self.tool_choice, ToolChoiceEnum):
            tool_choice = self.tool_choice.value
        elif isinstance(self.tool_choice, ToolChoice):
            tool_choice = self.tool_choice.to_dict()
        else:
            tool_choice = self.tool_choice

        stream_options: dict[str, Any] | None | Unset
        if isinstance(self.stream_options, Unset):
            stream_options = UNSET
        elif isinstance(self.stream_options, StreamOptions):
            stream_options = self.stream_options.to_dict()
        else:
            stream_options = self.stream_options


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if timeout is not UNSET:
            field_dict["timeout"] = timeout
        if temperature is not UNSET:
            field_dict["temperature"] = temperature
        if top_p is not UNSET:
            field_dict["top_p"] = top_p
        if max_tokens is not UNSET:
            field_dict["max_tokens"] = max_tokens
        if stop is not UNSET:
            field_dict["stop"] = stop
        if presence_penalty is not UNSET:
            field_dict["presence_penalty"] = presence_penalty
        if frequency_penalty is not UNSET:
            field_dict["frequency_penalty"] = frequency_penalty
        if seed is not UNSET:
            field_dict["seed"] = seed
        if logprobs is not UNSET:
            field_dict["logprobs"] = logprobs
        if top_logprobs is not UNSET:
            field_dict["top_logprobs"] = top_logprobs
        if logit_bias is not UNSET:
            field_dict["logit_bias"] = logit_bias
        if max_completion_tokens is not UNSET:
            field_dict["max_completion_tokens"] = max_completion_tokens
        if reasoning_effort is not UNSET:
            field_dict["reasoning_effort"] = reasoning_effort
        if thinking is not UNSET:
            field_dict["thinking"] = thinking
        if response_format is not UNSET:
            field_dict["response_format"] = response_format
        if tool_choice is not UNSET:
            field_dict["tool_choice"] = tool_choice
        if stream_options is not UNSET:
            field_dict["stream_options"] = stream_options

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.llm_response_format import LLMResponseFormat
        from ..models.logit_bias_item import LogitBiasItem
        from ..models.tool_choice import ToolChoice
        from ..models.anthropic_thinking_param import AnthropicThinkingParam
        from ..models.stream_options import StreamOptions
        d = dict(src_dict)
        def _parse_timeout(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        timeout = _parse_timeout(d.pop("timeout", UNSET))


        def _parse_temperature(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        temperature = _parse_temperature(d.pop("temperature", UNSET))


        def _parse_top_p(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        top_p = _parse_top_p(d.pop("top_p", UNSET))


        def _parse_max_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_tokens = _parse_max_tokens(d.pop("max_tokens", UNSET))


        def _parse_stop(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        stop = _parse_stop(d.pop("stop", UNSET))


        def _parse_presence_penalty(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        presence_penalty = _parse_presence_penalty(d.pop("presence_penalty", UNSET))


        def _parse_frequency_penalty(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        frequency_penalty = _parse_frequency_penalty(d.pop("frequency_penalty", UNSET))


        def _parse_seed(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        seed = _parse_seed(d.pop("seed", UNSET))


        def _parse_logprobs(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        logprobs = _parse_logprobs(d.pop("logprobs", UNSET))


        def _parse_top_logprobs(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        top_logprobs = _parse_top_logprobs(d.pop("top_logprobs", UNSET))


        def _parse_logit_bias(data: object) -> list[LogitBiasItem] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                logit_bias_type_0 = []
                _logit_bias_type_0 = data
                for logit_bias_type_0_item_data in (_logit_bias_type_0):
                    logit_bias_type_0_item = LogitBiasItem.from_dict(logit_bias_type_0_item_data)



                    logit_bias_type_0.append(logit_bias_type_0_item)

                return logit_bias_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[LogitBiasItem] | None | Unset, data)

        logit_bias = _parse_logit_bias(d.pop("logit_bias", UNSET))


        def _parse_max_completion_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        max_completion_tokens = _parse_max_completion_tokens(d.pop("max_completion_tokens", UNSET))


        def _parse_reasoning_effort(data: object) -> None | ReasoningEffortEnum | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                reasoning_effort_type_0 = ReasoningEffortEnum(data)



                return reasoning_effort_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ReasoningEffortEnum | Unset, data)

        reasoning_effort = _parse_reasoning_effort(d.pop("reasoning_effort", UNSET))


        def _parse_thinking(data: object) -> AnthropicThinkingParam | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                thinking_type_0 = AnthropicThinkingParam.from_dict(data)



                return thinking_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(AnthropicThinkingParam | None | Unset, data)

        thinking = _parse_thinking(d.pop("thinking", UNSET))


        def _parse_response_format(data: object) -> LLMResponseFormat | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                response_format_type_0 = LLMResponseFormat.from_dict(data)



                return response_format_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LLMResponseFormat | None | Unset, data)

        response_format = _parse_response_format(d.pop("response_format", UNSET))


        def _parse_tool_choice(data: object) -> None | ToolChoice | ToolChoiceEnum | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                tool_choice_type_0 = ToolChoiceEnum(data)



                return tool_choice_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                tool_choice_type_1 = ToolChoice.from_dict(data)



                return tool_choice_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ToolChoice | ToolChoiceEnum | Unset, data)

        tool_choice = _parse_tool_choice(d.pop("tool_choice", UNSET))


        def _parse_stream_options(data: object) -> None | StreamOptions | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                stream_options_type_0 = StreamOptions.from_dict(data)



                return stream_options_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | StreamOptions | Unset, data)

        stream_options = _parse_stream_options(d.pop("stream_options", UNSET))


        llm_prompt_request_config_settings = cls(
            timeout=timeout,
            temperature=temperature,
            top_p=top_p,
            max_tokens=max_tokens,
            stop=stop,
            presence_penalty=presence_penalty,
            frequency_penalty=frequency_penalty,
            seed=seed,
            logprobs=logprobs,
            top_logprobs=top_logprobs,
            logit_bias=logit_bias,
            max_completion_tokens=max_completion_tokens,
            reasoning_effort=reasoning_effort,
            thinking=thinking,
            response_format=response_format,
            tool_choice=tool_choice,
            stream_options=stream_options,
        )


        llm_prompt_request_config_settings.additional_properties = d
        return llm_prompt_request_config_settings

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
