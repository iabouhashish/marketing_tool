from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.connection_check_outcome import ConnectionCheckOutcome
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="ConnectionCheckResult")



@_attrs_define
class ConnectionCheckResult:
    """ 
        Attributes:
            connection_check_outcome (ConnectionCheckOutcome):
            failure_reason (None | str | Unset): Explainer of the connection check failure result.
     """

    connection_check_outcome: ConnectionCheckOutcome
    failure_reason: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        connection_check_outcome = self.connection_check_outcome.value

        failure_reason: None | str | Unset
        if isinstance(self.failure_reason, Unset):
            failure_reason = UNSET
        else:
            failure_reason = self.failure_reason


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "connection_check_outcome": connection_check_outcome,
        })
        if failure_reason is not UNSET:
            field_dict["failure_reason"] = failure_reason

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        connection_check_outcome = ConnectionCheckOutcome(d.pop("connection_check_outcome"))




        def _parse_failure_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        failure_reason = _parse_failure_reason(d.pop("failure_reason", UNSET))


        connection_check_result = cls(
            connection_check_outcome=connection_check_outcome,
            failure_reason=failure_reason,
        )


        connection_check_result.additional_properties = d
        return connection_check_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
