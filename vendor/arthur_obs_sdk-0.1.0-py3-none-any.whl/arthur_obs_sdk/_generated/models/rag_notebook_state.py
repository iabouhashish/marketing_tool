from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
  from ..models.unsaved_rag_config import UnsavedRagConfig
  from ..models.saved_rag_config import SavedRagConfig
  from ..models.eval_ref import EvalRef
  from ..models.dataset_ref_input import DatasetRefInput





T = TypeVar("T", bound="RagNotebookState")



@_attrs_define
class RagNotebookState:
    """ Draft state of a RAG notebook - mirrors RAG experiment config but all fields optional.
    Used for requests (input).

        Attributes:
            rag_configs (list[SavedRagConfig | UnsavedRagConfig] | None | Unset): List of RAG configurations
            dataset_ref (DatasetRefInput | None | Unset): Dataset reference (includes name)
            dataset_row_filter (list[NewDatasetVersionRowColumnItemRequest] | None | Unset): Optional list of column name
                and value filters. Only rows matching ALL specified column name-value pairs (AND condition) will be included.
            eval_list (list[EvalRef] | None | Unset): List of evaluations
     """

    rag_configs: list[SavedRagConfig | UnsavedRagConfig] | None | Unset = UNSET
    dataset_ref: DatasetRefInput | None | Unset = UNSET
    dataset_row_filter: list[NewDatasetVersionRowColumnItemRequest] | None | Unset = UNSET
    eval_list: list[EvalRef] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        from ..models.unsaved_rag_config import UnsavedRagConfig
        from ..models.saved_rag_config import SavedRagConfig
        from ..models.eval_ref import EvalRef
        from ..models.dataset_ref_input import DatasetRefInput
        rag_configs: list[dict[str, Any]] | None | Unset
        if isinstance(self.rag_configs, Unset):
            rag_configs = UNSET
        elif isinstance(self.rag_configs, list):
            rag_configs = []
            for rag_configs_type_0_item_data in self.rag_configs:
                rag_configs_type_0_item: dict[str, Any]
                if isinstance(rag_configs_type_0_item_data, SavedRagConfig):
                    rag_configs_type_0_item = rag_configs_type_0_item_data.to_dict()
                else:
                    rag_configs_type_0_item = rag_configs_type_0_item_data.to_dict()

                rag_configs.append(rag_configs_type_0_item)


        else:
            rag_configs = self.rag_configs

        dataset_ref: dict[str, Any] | None | Unset
        if isinstance(self.dataset_ref, Unset):
            dataset_ref = UNSET
        elif isinstance(self.dataset_ref, DatasetRefInput):
            dataset_ref = self.dataset_ref.to_dict()
        else:
            dataset_ref = self.dataset_ref

        dataset_row_filter: list[dict[str, Any]] | None | Unset
        if isinstance(self.dataset_row_filter, Unset):
            dataset_row_filter = UNSET
        elif isinstance(self.dataset_row_filter, list):
            dataset_row_filter = []
            for dataset_row_filter_type_0_item_data in self.dataset_row_filter:
                dataset_row_filter_type_0_item = dataset_row_filter_type_0_item_data.to_dict()
                dataset_row_filter.append(dataset_row_filter_type_0_item)


        else:
            dataset_row_filter = self.dataset_row_filter

        eval_list: list[dict[str, Any]] | None | Unset
        if isinstance(self.eval_list, Unset):
            eval_list = UNSET
        elif isinstance(self.eval_list, list):
            eval_list = []
            for eval_list_type_0_item_data in self.eval_list:
                eval_list_type_0_item = eval_list_type_0_item_data.to_dict()
                eval_list.append(eval_list_type_0_item)


        else:
            eval_list = self.eval_list


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if rag_configs is not UNSET:
            field_dict["rag_configs"] = rag_configs
        if dataset_ref is not UNSET:
            field_dict["dataset_ref"] = dataset_ref
        if dataset_row_filter is not UNSET:
            field_dict["dataset_row_filter"] = dataset_row_filter
        if eval_list is not UNSET:
            field_dict["eval_list"] = eval_list

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        from ..models.unsaved_rag_config import UnsavedRagConfig
        from ..models.saved_rag_config import SavedRagConfig
        from ..models.eval_ref import EvalRef
        from ..models.dataset_ref_input import DatasetRefInput
        d = dict(src_dict)
        def _parse_rag_configs(data: object) -> list[SavedRagConfig | UnsavedRagConfig] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                rag_configs_type_0 = []
                _rag_configs_type_0 = data
                for rag_configs_type_0_item_data in (_rag_configs_type_0):
                    def _parse_rag_configs_type_0_item(data: object) -> SavedRagConfig | UnsavedRagConfig:
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            rag_configs_type_0_item_type_0 = SavedRagConfig.from_dict(data)



                            return rag_configs_type_0_item_type_0
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        if not isinstance(data, dict):
                            raise TypeError()
                        rag_configs_type_0_item_type_1 = UnsavedRagConfig.from_dict(data)



                        return rag_configs_type_0_item_type_1

                    rag_configs_type_0_item = _parse_rag_configs_type_0_item(rag_configs_type_0_item_data)

                    rag_configs_type_0.append(rag_configs_type_0_item)

                return rag_configs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[SavedRagConfig | UnsavedRagConfig] | None | Unset, data)

        rag_configs = _parse_rag_configs(d.pop("rag_configs", UNSET))


        def _parse_dataset_ref(data: object) -> DatasetRefInput | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                dataset_ref_type_0 = DatasetRefInput.from_dict(data)



                return dataset_ref_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DatasetRefInput | None | Unset, data)

        dataset_ref = _parse_dataset_ref(d.pop("dataset_ref", UNSET))


        def _parse_dataset_row_filter(data: object) -> list[NewDatasetVersionRowColumnItemRequest] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                dataset_row_filter_type_0 = []
                _dataset_row_filter_type_0 = data
                for dataset_row_filter_type_0_item_data in (_dataset_row_filter_type_0):
                    dataset_row_filter_type_0_item = NewDatasetVersionRowColumnItemRequest.from_dict(dataset_row_filter_type_0_item_data)



                    dataset_row_filter_type_0.append(dataset_row_filter_type_0_item)

                return dataset_row_filter_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[NewDatasetVersionRowColumnItemRequest] | None | Unset, data)

        dataset_row_filter = _parse_dataset_row_filter(d.pop("dataset_row_filter", UNSET))


        def _parse_eval_list(data: object) -> list[EvalRef] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                eval_list_type_0 = []
                _eval_list_type_0 = data
                for eval_list_type_0_item_data in (_eval_list_type_0):
                    eval_list_type_0_item = EvalRef.from_dict(eval_list_type_0_item_data)



                    eval_list_type_0.append(eval_list_type_0_item)

                return eval_list_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[EvalRef] | None | Unset, data)

        eval_list = _parse_eval_list(d.pop("eval_list", UNSET))


        rag_notebook_state = cls(
            rag_configs=rag_configs,
            dataset_ref=dataset_ref,
            dataset_row_filter=dataset_row_filter,
            eval_list=eval_list,
        )


        rag_notebook_state.additional_properties = d
        return rag_notebook_state

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
