from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.prompt_eval_result_summaries import PromptEvalResultSummaries





T = TypeVar("T", bound="SummaryResults")



@_attrs_define
class SummaryResults:
    """ Summary results across all prompt versions and evaluations

        Attributes:
            prompt_eval_summaries (list[PromptEvalResultSummaries]): Summary for each prompt version tested
     """

    prompt_eval_summaries: list[PromptEvalResultSummaries]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.prompt_eval_result_summaries import PromptEvalResultSummaries
        prompt_eval_summaries = []
        for prompt_eval_summaries_item_data in self.prompt_eval_summaries:
            prompt_eval_summaries_item = prompt_eval_summaries_item_data.to_dict()
            prompt_eval_summaries.append(prompt_eval_summaries_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "prompt_eval_summaries": prompt_eval_summaries,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.prompt_eval_result_summaries import PromptEvalResultSummaries
        d = dict(src_dict)
        prompt_eval_summaries = []
        _prompt_eval_summaries = d.pop("prompt_eval_summaries")
        for prompt_eval_summaries_item_data in (_prompt_eval_summaries):
            prompt_eval_summaries_item = PromptEvalResultSummaries.from_dict(prompt_eval_summaries_item_data)



            prompt_eval_summaries.append(prompt_eval_summaries_item)


        summary_results = cls(
            prompt_eval_summaries=prompt_eval_summaries,
        )


        summary_results.additional_properties = d
        return summary_results

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
