from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.example_config import ExampleConfig





T = TypeVar("T", bound="ExamplesConfig")



@_attrs_define
class ExamplesConfig:
    """ 
        Example:
            {'examples': [{'example': 'John has O negative blood group', 'result': True}, {'example': 'Most of the people
                have A positive blood group', 'result': False}], 'hint': "specific individual's blood type"}

        Attributes:
            examples (list[ExampleConfig]): List of all the examples for Sensitive Data Rule
            hint (None | str | Unset): Optional. Hint added to describe what Sensitive Data Rule should be checking for
     """

    examples: list[ExampleConfig]
    hint: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.example_config import ExampleConfig
        examples = []
        for examples_item_data in self.examples:
            examples_item = examples_item_data.to_dict()
            examples.append(examples_item)



        hint: None | str | Unset
        if isinstance(self.hint, Unset):
            hint = UNSET
        else:
            hint = self.hint


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "examples": examples,
        })
        if hint is not UNSET:
            field_dict["hint"] = hint

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.example_config import ExampleConfig
        d = dict(src_dict)
        examples = []
        _examples = d.pop("examples")
        for examples_item_data in (_examples):
            examples_item = ExampleConfig.from_dict(examples_item_data)



            examples.append(examples_item)


        def _parse_hint(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        hint = _parse_hint(d.pop("hint", UNSET))


        examples_config = cls(
            examples=examples,
            hint=hint,
        )


        examples_config.additional_properties = d
        return examples_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
