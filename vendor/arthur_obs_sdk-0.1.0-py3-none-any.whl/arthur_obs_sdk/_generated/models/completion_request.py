from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.model_provider import ModelProvider
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.llm_tool import LLMTool
  from ..models.llm_prompt_request_config_settings import LLMPromptRequestConfigSettings
  from ..models.prompt_completion_request import PromptCompletionRequest
  from ..models.open_ai_message import OpenAIMessage





T = TypeVar("T", bound="CompletionRequest")



@_attrs_define
class CompletionRequest:
    """ Request schema for running an unsaved agentic prompt

        Attributes:
            messages (list[OpenAIMessage]): List of chat messages in OpenAI format (e.g., [{'role': 'user', 'content':
                'Hello'}])
            model_name (str): Name of the LLM model (e.g., 'gpt-4o', 'claude-3-sonnet')
            model_provider (ModelProvider):
            tools (list[LLMTool] | None | Unset): Available tools/functions for the model to call, in OpenAI function
                calling format
            config (LLMPromptRequestConfigSettings | None | Unset): LLM configurations for this prompt (e.g. temperature,
                max_tokens, etc.)
            completion_request (PromptCompletionRequest | Unset): Request schema for running an agentic prompt
     """

    messages: list[OpenAIMessage]
    model_name: str
    model_provider: ModelProvider
    tools: list[LLMTool] | None | Unset = UNSET
    config: LLMPromptRequestConfigSettings | None | Unset = UNSET
    completion_request: PromptCompletionRequest | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.llm_tool import LLMTool
        from ..models.llm_prompt_request_config_settings import LLMPromptRequestConfigSettings
        from ..models.prompt_completion_request import PromptCompletionRequest
        from ..models.open_ai_message import OpenAIMessage
        messages = []
        for messages_item_data in self.messages:
            messages_item = messages_item_data.to_dict()
            messages.append(messages_item)



        model_name = self.model_name

        model_provider = self.model_provider.value

        tools: list[dict[str, Any]] | None | Unset
        if isinstance(self.tools, Unset):
            tools = UNSET
        elif isinstance(self.tools, list):
            tools = []
            for tools_type_0_item_data in self.tools:
                tools_type_0_item = tools_type_0_item_data.to_dict()
                tools.append(tools_type_0_item)


        else:
            tools = self.tools

        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, LLMPromptRequestConfigSettings):
            config = self.config.to_dict()
        else:
            config = self.config

        completion_request: dict[str, Any] | Unset = UNSET
        if not isinstance(self.completion_request, Unset):
            completion_request = self.completion_request.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "messages": messages,
            "model_name": model_name,
            "model_provider": model_provider,
        })
        if tools is not UNSET:
            field_dict["tools"] = tools
        if config is not UNSET:
            field_dict["config"] = config
        if completion_request is not UNSET:
            field_dict["completion_request"] = completion_request

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.llm_tool import LLMTool
        from ..models.llm_prompt_request_config_settings import LLMPromptRequestConfigSettings
        from ..models.prompt_completion_request import PromptCompletionRequest
        from ..models.open_ai_message import OpenAIMessage
        d = dict(src_dict)
        messages = []
        _messages = d.pop("messages")
        for messages_item_data in (_messages):
            messages_item = OpenAIMessage.from_dict(messages_item_data)



            messages.append(messages_item)


        model_name = d.pop("model_name")

        model_provider = ModelProvider(d.pop("model_provider"))




        def _parse_tools(data: object) -> list[LLMTool] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tools_type_0 = []
                _tools_type_0 = data
                for tools_type_0_item_data in (_tools_type_0):
                    tools_type_0_item = LLMTool.from_dict(tools_type_0_item_data)



                    tools_type_0.append(tools_type_0_item)

                return tools_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[LLMTool] | None | Unset, data)

        tools = _parse_tools(d.pop("tools", UNSET))


        def _parse_config(data: object) -> LLMPromptRequestConfigSettings | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0 = LLMPromptRequestConfigSettings.from_dict(data)



                return config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LLMPromptRequestConfigSettings | None | Unset, data)

        config = _parse_config(d.pop("config", UNSET))


        _completion_request = d.pop("completion_request", UNSET)
        completion_request: PromptCompletionRequest | Unset
        if isinstance(_completion_request,  Unset):
            completion_request = UNSET
        else:
            completion_request = PromptCompletionRequest.from_dict(_completion_request)




        completion_request = cls(
            messages=messages,
            model_name=model_name,
            model_provider=model_provider,
            tools=tools,
            config=config,
            completion_request=completion_request,
        )


        completion_request.additional_properties = d
        return completion_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
