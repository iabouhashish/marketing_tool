from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.rule_response import RuleResponse
  from ..models.metric_response import MetricResponse





T = TypeVar("T", bound="TaskResponse")



@_attrs_define
class TaskResponse:
    """ 
        Attributes:
            id (str):  ID of the task
            name (str): Name of the task
            created_at (int): Time the task was created in unix milliseconds
            updated_at (int): Time the task was created in unix milliseconds
            rules (list[RuleResponse]): List of all the rules for the task.
            is_agentic (bool | None | Unset): Whether the task is agentic or not
            metrics (list[MetricResponse] | None | Unset): List of all the metrics for the task.
     """

    id: str
    name: str
    created_at: int
    updated_at: int
    rules: list[RuleResponse]
    is_agentic: bool | None | Unset = UNSET
    metrics: list[MetricResponse] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rule_response import RuleResponse
        from ..models.metric_response import MetricResponse
        id = self.id

        name = self.name

        created_at = self.created_at

        updated_at = self.updated_at

        rules = []
        for rules_item_data in self.rules:
            rules_item = rules_item_data.to_dict()
            rules.append(rules_item)



        is_agentic: bool | None | Unset
        if isinstance(self.is_agentic, Unset):
            is_agentic = UNSET
        else:
            is_agentic = self.is_agentic

        metrics: list[dict[str, Any]] | None | Unset
        if isinstance(self.metrics, Unset):
            metrics = UNSET
        elif isinstance(self.metrics, list):
            metrics = []
            for metrics_type_0_item_data in self.metrics:
                metrics_type_0_item = metrics_type_0_item_data.to_dict()
                metrics.append(metrics_type_0_item)


        else:
            metrics = self.metrics


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "created_at": created_at,
            "updated_at": updated_at,
            "rules": rules,
        })
        if is_agentic is not UNSET:
            field_dict["is_agentic"] = is_agentic
        if metrics is not UNSET:
            field_dict["metrics"] = metrics

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rule_response import RuleResponse
        from ..models.metric_response import MetricResponse
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        rules = []
        _rules = d.pop("rules")
        for rules_item_data in (_rules):
            rules_item = RuleResponse.from_dict(rules_item_data)



            rules.append(rules_item)


        def _parse_is_agentic(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_agentic = _parse_is_agentic(d.pop("is_agentic", UNSET))


        def _parse_metrics(data: object) -> list[MetricResponse] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                metrics_type_0 = []
                _metrics_type_0 = data
                for metrics_type_0_item_data in (_metrics_type_0):
                    metrics_type_0_item = MetricResponse.from_dict(metrics_type_0_item_data)



                    metrics_type_0.append(metrics_type_0_item)

                return metrics_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[MetricResponse] | None | Unset, data)

        metrics = _parse_metrics(d.pop("metrics", UNSET))


        task_response = cls(
            id=id,
            name=name,
            created_at=created_at,
            updated_at=updated_at,
            rules=rules,
            is_agentic=is_agentic,
            metrics=metrics,
        )


        task_response.additional_properties = d
        return task_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
