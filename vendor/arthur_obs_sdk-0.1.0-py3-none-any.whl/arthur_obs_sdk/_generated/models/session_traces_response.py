from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.trace_response import TraceResponse





T = TypeVar("T", bound="SessionTracesResponse")



@_attrs_define
class SessionTracesResponse:
    """ Response for session traces endpoint

        Attributes:
            session_id (str): Session identifier
            count (int): Number of traces in this session
            traces (list[TraceResponse]): List of full trace trees
     """

    session_id: str
    count: int
    traces: list[TraceResponse]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.trace_response import TraceResponse
        session_id = self.session_id

        count = self.count

        traces = []
        for traces_item_data in self.traces:
            traces_item = traces_item_data.to_dict()
            traces.append(traces_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "session_id": session_id,
            "count": count,
            "traces": traces,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.trace_response import TraceResponse
        d = dict(src_dict)
        session_id = d.pop("session_id")

        count = d.pop("count")

        traces = []
        _traces = d.pop("traces")
        for traces_item_data in (_traces):
            traces_item = TraceResponse.from_dict(traces_item_data)



            traces.append(traces_item)


        session_traces_response = cls(
            session_id=session_id,
            count=count,
            traces=traces,
        )


        session_traces_response.additional_properties = d
        return session_traces_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
