from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.dataset_version_row_response import DatasetVersionRowResponse





T = TypeVar("T", bound="DatasetVersionResponse")



@_attrs_define
class DatasetVersionResponse:
    """ 
        Attributes:
            version_number (int): Version number of the dataset version.
            created_at (int): Timestamp representing the time of dataset version creation in unix milliseconds.
            dataset_id (UUID): ID of the dataset.
            column_names (list[str]): Names of all columns in the dataset version.
            rows (list[DatasetVersionRowResponse]): list of rows in the dataset version.
            page (int): The current page number for the included rows.
            page_size (int): The number of rows per page.
            total_pages (int): The total number of pages.
            total_count (int): The total number of rows in the dataset version.
     """

    version_number: int
    created_at: int
    dataset_id: UUID
    column_names: list[str]
    rows: list[DatasetVersionRowResponse]
    page: int
    page_size: int
    total_pages: int
    total_count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.dataset_version_row_response import DatasetVersionRowResponse
        version_number = self.version_number

        created_at = self.created_at

        dataset_id = str(self.dataset_id)

        column_names = self.column_names



        rows = []
        for rows_item_data in self.rows:
            rows_item = rows_item_data.to_dict()
            rows.append(rows_item)



        page = self.page

        page_size = self.page_size

        total_pages = self.total_pages

        total_count = self.total_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "version_number": version_number,
            "created_at": created_at,
            "dataset_id": dataset_id,
            "column_names": column_names,
            "rows": rows,
            "page": page,
            "page_size": page_size,
            "total_pages": total_pages,
            "total_count": total_count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dataset_version_row_response import DatasetVersionRowResponse
        d = dict(src_dict)
        version_number = d.pop("version_number")

        created_at = d.pop("created_at")

        dataset_id = UUID(d.pop("dataset_id"))




        column_names = cast(list[str], d.pop("column_names"))


        rows = []
        _rows = d.pop("rows")
        for rows_item_data in (_rows):
            rows_item = DatasetVersionRowResponse.from_dict(rows_item_data)



            rows.append(rows_item)


        page = d.pop("page")

        page_size = d.pop("page_size")

        total_pages = d.pop("total_pages")

        total_count = d.pop("total_count")

        dataset_version_response = cls(
            version_number=version_number,
            created_at=created_at,
            dataset_id=dataset_id,
            column_names=column_names,
            rows=rows,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
            total_count=total_count,
        )


        dataset_version_response.additional_properties = d
        return dataset_version_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
