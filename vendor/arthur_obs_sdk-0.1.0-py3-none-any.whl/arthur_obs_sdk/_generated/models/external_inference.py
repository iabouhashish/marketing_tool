from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.rule_result_enum import RuleResultEnum
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.inference_feedback_response import InferenceFeedbackResponse
  from ..models.external_inference_prompt import ExternalInferencePrompt
  from ..models.external_inference_response import ExternalInferenceResponse





T = TypeVar("T", bound="ExternalInference")



@_attrs_define
class ExternalInference:
    """ 
        Attributes:
            id (str):
            result (RuleResultEnum):
            created_at (int):
            updated_at (int):
            inference_prompt (ExternalInferencePrompt):
            inference_feedback (list[InferenceFeedbackResponse]):
            task_id (None | str | Unset):
            task_name (None | str | Unset):
            conversation_id (None | str | Unset):
            inference_response (ExternalInferenceResponse | None | Unset):
            user_id (None | str | Unset):
            model_name (None | str | Unset): The model name and version used for this inference (e.g., 'gpt-4',
                'gpt-3.5-turbo', 'claude-3-opus', 'gemini-pro').
     """

    id: str
    result: RuleResultEnum
    created_at: int
    updated_at: int
    inference_prompt: ExternalInferencePrompt
    inference_feedback: list[InferenceFeedbackResponse]
    task_id: None | str | Unset = UNSET
    task_name: None | str | Unset = UNSET
    conversation_id: None | str | Unset = UNSET
    inference_response: ExternalInferenceResponse | None | Unset = UNSET
    user_id: None | str | Unset = UNSET
    model_name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.inference_feedback_response import InferenceFeedbackResponse
        from ..models.external_inference_prompt import ExternalInferencePrompt
        from ..models.external_inference_response import ExternalInferenceResponse
        id = self.id

        result = self.result.value

        created_at = self.created_at

        updated_at = self.updated_at

        inference_prompt = self.inference_prompt.to_dict()

        inference_feedback = []
        for inference_feedback_item_data in self.inference_feedback:
            inference_feedback_item = inference_feedback_item_data.to_dict()
            inference_feedback.append(inference_feedback_item)



        task_id: None | str | Unset
        if isinstance(self.task_id, Unset):
            task_id = UNSET
        else:
            task_id = self.task_id

        task_name: None | str | Unset
        if isinstance(self.task_name, Unset):
            task_name = UNSET
        else:
            task_name = self.task_name

        conversation_id: None | str | Unset
        if isinstance(self.conversation_id, Unset):
            conversation_id = UNSET
        else:
            conversation_id = self.conversation_id

        inference_response: dict[str, Any] | None | Unset
        if isinstance(self.inference_response, Unset):
            inference_response = UNSET
        elif isinstance(self.inference_response, ExternalInferenceResponse):
            inference_response = self.inference_response.to_dict()
        else:
            inference_response = self.inference_response

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id

        model_name: None | str | Unset
        if isinstance(self.model_name, Unset):
            model_name = UNSET
        else:
            model_name = self.model_name


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "result": result,
            "created_at": created_at,
            "updated_at": updated_at,
            "inference_prompt": inference_prompt,
            "inference_feedback": inference_feedback,
        })
        if task_id is not UNSET:
            field_dict["task_id"] = task_id
        if task_name is not UNSET:
            field_dict["task_name"] = task_name
        if conversation_id is not UNSET:
            field_dict["conversation_id"] = conversation_id
        if inference_response is not UNSET:
            field_dict["inference_response"] = inference_response
        if user_id is not UNSET:
            field_dict["user_id"] = user_id
        if model_name is not UNSET:
            field_dict["model_name"] = model_name

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.inference_feedback_response import InferenceFeedbackResponse
        from ..models.external_inference_prompt import ExternalInferencePrompt
        from ..models.external_inference_response import ExternalInferenceResponse
        d = dict(src_dict)
        id = d.pop("id")

        result = RuleResultEnum(d.pop("result"))




        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        inference_prompt = ExternalInferencePrompt.from_dict(d.pop("inference_prompt"))




        inference_feedback = []
        _inference_feedback = d.pop("inference_feedback")
        for inference_feedback_item_data in (_inference_feedback):
            inference_feedback_item = InferenceFeedbackResponse.from_dict(inference_feedback_item_data)



            inference_feedback.append(inference_feedback_item)


        def _parse_task_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        task_id = _parse_task_id(d.pop("task_id", UNSET))


        def _parse_task_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        task_name = _parse_task_name(d.pop("task_name", UNSET))


        def _parse_conversation_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        conversation_id = _parse_conversation_id(d.pop("conversation_id", UNSET))


        def _parse_inference_response(data: object) -> ExternalInferenceResponse | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                inference_response_type_0 = ExternalInferenceResponse.from_dict(data)



                return inference_response_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ExternalInferenceResponse | None | Unset, data)

        inference_response = _parse_inference_response(d.pop("inference_response", UNSET))


        def _parse_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_id = _parse_user_id(d.pop("user_id", UNSET))


        def _parse_model_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model_name = _parse_model_name(d.pop("model_name", UNSET))


        external_inference = cls(
            id=id,
            result=result,
            created_at=created_at,
            updated_at=updated_at,
            inference_prompt=inference_prompt,
            inference_feedback=inference_feedback,
            task_id=task_id,
            task_name=task_name,
            conversation_id=conversation_id,
            inference_response=inference_response,
            user_id=user_id,
            model_name=model_name,
        )


        external_inference.additional_properties = d
        return external_inference

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
