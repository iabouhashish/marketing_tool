from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.trace_transform_definition import TraceTransformDefinition





T = TypeVar("T", bound="NewTraceTransformRequest")



@_attrs_define
class NewTraceTransformRequest:
    """ 
        Attributes:
            name (str): Name of the transform.
            definition (TraceTransformDefinition):
            description (None | str | Unset): Description of the transform.
     """

    name: str
    definition: TraceTransformDefinition
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.trace_transform_definition import TraceTransformDefinition
        name = self.name

        definition = self.definition.to_dict()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "definition": definition,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.trace_transform_definition import TraceTransformDefinition
        d = dict(src_dict)
        name = d.pop("name")

        definition = TraceTransformDefinition.from_dict(d.pop("definition"))




        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        new_trace_transform_request = cls(
            name=name,
            definition=definition,
            description=description,
        )


        new_trace_transform_request.additional_properties = d
        return new_trace_transform_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
