from enum import Enum

class ToxicityViolationType(str, Enum):
    BENIGN = "benign"
    HARMFUL_REQUEST = "harmful_request"
    PROFANITY = "profanity"
    TOXIC_CONTENT = "toxic_content"
    UNKNOWN = "unknown"

    def __str__(self) -> str:
        return str(self.value)
