from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.rag_api_key_authentication_provider_enum import RagAPIKeyAuthenticationProviderEnum
from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="ApiKeyRagAuthenticationConfigRequest")



@_attrs_define
class ApiKeyRagAuthenticationConfigRequest:
    """ 
        Attributes:
            api_key (str): API key to use for authentication.
            host_url (str): URL of host instance to authenticate with.
            rag_provider (RagAPIKeyAuthenticationProviderEnum):
            authentication_method (Literal['api_key'] | Unset):  Default: 'api_key'.
     """

    api_key: str
    host_url: str
    rag_provider: RagAPIKeyAuthenticationProviderEnum
    authentication_method: Literal['api_key'] | Unset = 'api_key'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        api_key = self.api_key

        host_url = self.host_url

        rag_provider = self.rag_provider.value

        authentication_method = self.authentication_method


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "api_key": api_key,
            "host_url": host_url,
            "rag_provider": rag_provider,
        })
        if authentication_method is not UNSET:
            field_dict["authentication_method"] = authentication_method

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        api_key = d.pop("api_key")

        host_url = d.pop("host_url")

        rag_provider = RagAPIKeyAuthenticationProviderEnum(d.pop("rag_provider"))




        authentication_method = cast(Literal['api_key'] | Unset , d.pop("authentication_method", UNSET))
        if authentication_method != 'api_key'and not isinstance(authentication_method, Unset):
            raise ValueError(f"authentication_method must match const 'api_key', got '{authentication_method}'")

        api_key_rag_authentication_config_request = cls(
            api_key=api_key,
            host_url=host_url,
            rag_provider=rag_provider,
            authentication_method=authentication_method,
        )


        api_key_rag_authentication_config_request.additional_properties = d
        return api_key_rag_authentication_config_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
