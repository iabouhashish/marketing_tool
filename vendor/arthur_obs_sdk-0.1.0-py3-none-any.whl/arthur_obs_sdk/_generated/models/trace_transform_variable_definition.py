from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="TraceTransformVariableDefinition")



@_attrs_define
class TraceTransformVariableDefinition:
    """ 
        Attributes:
            variable_name (str): Name of the variable to extract.
            span_name (str): Name of the span to extract data from.
            attribute_path (str): Dot-notation path to the attribute within the span (e.g.,
                'attributes.input.value.sqlQuery').
            fallback (None | str | Unset): Fallback value to use if the attribute is not found.
     """

    variable_name: str
    span_name: str
    attribute_path: str
    fallback: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        variable_name = self.variable_name

        span_name = self.span_name

        attribute_path = self.attribute_path

        fallback: None | str | Unset
        if isinstance(self.fallback, Unset):
            fallback = UNSET
        else:
            fallback = self.fallback


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "variable_name": variable_name,
            "span_name": span_name,
            "attribute_path": attribute_path,
        })
        if fallback is not UNSET:
            field_dict["fallback"] = fallback

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        variable_name = d.pop("variable_name")

        span_name = d.pop("span_name")

        attribute_path = d.pop("attribute_path")

        def _parse_fallback(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        fallback = _parse_fallback(d.pop("fallback", UNSET))


        trace_transform_variable_definition = cls(
            variable_name=variable_name,
            span_name=span_name,
            attribute_path=attribute_path,
            fallback=fallback,
        )


        trace_transform_variable_definition.additional_properties = d
        return trace_transform_variable_definition

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
