from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.weaviate_vector_similarity_text_search_settings_configuration_response_return_metadata_type_0_item import WeaviateVectorSimilarityTextSearchSettingsConfigurationResponseReturnMetadataType0Item
from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.multi_target_vector_join import MultiTargetVectorJoin
  from ..models.metadata_query import MetadataQuery





T = TypeVar("T", bound="WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse")



@_attrs_define
class WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse:
    """ 
        Attributes:
            collection_name (str): Name of the vector collection used for the search.
            limit (int | None | Unset): Maximum number of objects to return.
            include_vector (bool | list[str] | None | str | Unset): Boolean value whether to include vector embeddings in
                the response or can be used to specify the names of the vectors to include in the response if your collection
                uses named vectors. Will be included as a dictionary in the vector property in the response. Default: False.
            offset (int | None | Unset): Skips first N results in similarity response. Useful for pagination.
            auto_limit (int | None | Unset): Automatically limit search results to groups of objects with similar distances,
                stopping after auto_limit number of significant jumps.
            return_metadata (list[WeaviateVectorSimilarityTextSearchSettingsConfigurationResponseReturnMetadataType0Item] |
                MetadataQuery | None | Unset): Specify metadata fields to return.
            return_properties (list[str] | None | Unset): Specify which properties to return for each object.
            rag_provider (Literal['weaviate'] | Unset):  Default: 'weaviate'.
            search_kind (Literal['vector_similarity_text_search'] | Unset):  Default: 'vector_similarity_text_search'.
            certainty (float | None | Unset): Minimum similarity score to return. Higher values correspond to more similar
                results. Only one of distance and certainty can be specified.
            distance (float | None | Unset): Maximum allowed distance between the query and result vectors. Lower values
                corresponds to more similar results. Only one of distance and certainty can be specified.
            target_vector (list[str] | MultiTargetVectorJoin | None | str | Unset): Specifies vector to use for similarity
                search when using named vectors.
     """

    collection_name: str
    limit: int | None | Unset = UNSET
    include_vector: bool | list[str] | None | str | Unset = False
    offset: int | None | Unset = UNSET
    auto_limit: int | None | Unset = UNSET
    return_metadata: list[WeaviateVectorSimilarityTextSearchSettingsConfigurationResponseReturnMetadataType0Item] | MetadataQuery | None | Unset = UNSET
    return_properties: list[str] | None | Unset = UNSET
    rag_provider: Literal['weaviate'] | Unset = 'weaviate'
    search_kind: Literal['vector_similarity_text_search'] | Unset = 'vector_similarity_text_search'
    certainty: float | None | Unset = UNSET
    distance: float | None | Unset = UNSET
    target_vector: list[str] | MultiTargetVectorJoin | None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.multi_target_vector_join import MultiTargetVectorJoin
        from ..models.metadata_query import MetadataQuery
        collection_name = self.collection_name

        limit: int | None | Unset
        if isinstance(self.limit, Unset):
            limit = UNSET
        else:
            limit = self.limit

        include_vector: bool | list[str] | None | str | Unset
        if isinstance(self.include_vector, Unset):
            include_vector = UNSET
        elif isinstance(self.include_vector, list):
            include_vector = self.include_vector


        else:
            include_vector = self.include_vector

        offset: int | None | Unset
        if isinstance(self.offset, Unset):
            offset = UNSET
        else:
            offset = self.offset

        auto_limit: int | None | Unset
        if isinstance(self.auto_limit, Unset):
            auto_limit = UNSET
        else:
            auto_limit = self.auto_limit

        return_metadata: dict[str, Any] | list[str] | None | Unset
        if isinstance(self.return_metadata, Unset):
            return_metadata = UNSET
        elif isinstance(self.return_metadata, list):
            return_metadata = []
            for return_metadata_type_0_item_data in self.return_metadata:
                return_metadata_type_0_item = return_metadata_type_0_item_data.value
                return_metadata.append(return_metadata_type_0_item)


        elif isinstance(self.return_metadata, MetadataQuery):
            return_metadata = self.return_metadata.to_dict()
        else:
            return_metadata = self.return_metadata

        return_properties: list[str] | None | Unset
        if isinstance(self.return_properties, Unset):
            return_properties = UNSET
        elif isinstance(self.return_properties, list):
            return_properties = self.return_properties


        else:
            return_properties = self.return_properties

        rag_provider = self.rag_provider

        search_kind = self.search_kind

        certainty: float | None | Unset
        if isinstance(self.certainty, Unset):
            certainty = UNSET
        else:
            certainty = self.certainty

        distance: float | None | Unset
        if isinstance(self.distance, Unset):
            distance = UNSET
        else:
            distance = self.distance

        target_vector: dict[str, Any] | list[str] | None | str | Unset
        if isinstance(self.target_vector, Unset):
            target_vector = UNSET
        elif isinstance(self.target_vector, list):
            target_vector = self.target_vector


        elif isinstance(self.target_vector, MultiTargetVectorJoin):
            target_vector = self.target_vector.to_dict()
        else:
            target_vector = self.target_vector


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "collection_name": collection_name,
        })
        if limit is not UNSET:
            field_dict["limit"] = limit
        if include_vector is not UNSET:
            field_dict["include_vector"] = include_vector
        if offset is not UNSET:
            field_dict["offset"] = offset
        if auto_limit is not UNSET:
            field_dict["auto_limit"] = auto_limit
        if return_metadata is not UNSET:
            field_dict["return_metadata"] = return_metadata
        if return_properties is not UNSET:
            field_dict["return_properties"] = return_properties
        if rag_provider is not UNSET:
            field_dict["rag_provider"] = rag_provider
        if search_kind is not UNSET:
            field_dict["search_kind"] = search_kind
        if certainty is not UNSET:
            field_dict["certainty"] = certainty
        if distance is not UNSET:
            field_dict["distance"] = distance
        if target_vector is not UNSET:
            field_dict["target_vector"] = target_vector

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.multi_target_vector_join import MultiTargetVectorJoin
        from ..models.metadata_query import MetadataQuery
        d = dict(src_dict)
        collection_name = d.pop("collection_name")

        def _parse_limit(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        limit = _parse_limit(d.pop("limit", UNSET))


        def _parse_include_vector(data: object) -> bool | list[str] | None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                include_vector_type_2 = cast(list[str], data)

                return include_vector_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(bool | list[str] | None | str | Unset, data)

        include_vector = _parse_include_vector(d.pop("include_vector", UNSET))


        def _parse_offset(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        offset = _parse_offset(d.pop("offset", UNSET))


        def _parse_auto_limit(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        auto_limit = _parse_auto_limit(d.pop("auto_limit", UNSET))


        def _parse_return_metadata(data: object) -> list[WeaviateVectorSimilarityTextSearchSettingsConfigurationResponseReturnMetadataType0Item] | MetadataQuery | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                return_metadata_type_0 = []
                _return_metadata_type_0 = data
                for return_metadata_type_0_item_data in (_return_metadata_type_0):
                    return_metadata_type_0_item = WeaviateVectorSimilarityTextSearchSettingsConfigurationResponseReturnMetadataType0Item(return_metadata_type_0_item_data)



                    return_metadata_type_0.append(return_metadata_type_0_item)

                return return_metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                return_metadata_type_1 = MetadataQuery.from_dict(data)



                return return_metadata_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[WeaviateVectorSimilarityTextSearchSettingsConfigurationResponseReturnMetadataType0Item] | MetadataQuery | None | Unset, data)

        return_metadata = _parse_return_metadata(d.pop("return_metadata", UNSET))


        def _parse_return_properties(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                return_properties_type_0 = cast(list[str], data)

                return return_properties_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        return_properties = _parse_return_properties(d.pop("return_properties", UNSET))


        rag_provider = cast(Literal['weaviate'] | Unset , d.pop("rag_provider", UNSET))
        if rag_provider != 'weaviate'and not isinstance(rag_provider, Unset):
            raise ValueError(f"rag_provider must match const 'weaviate', got '{rag_provider}'")

        search_kind = cast(Literal['vector_similarity_text_search'] | Unset , d.pop("search_kind", UNSET))
        if search_kind != 'vector_similarity_text_search'and not isinstance(search_kind, Unset):
            raise ValueError(f"search_kind must match const 'vector_similarity_text_search', got '{search_kind}'")

        def _parse_certainty(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        certainty = _parse_certainty(d.pop("certainty", UNSET))


        def _parse_distance(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        distance = _parse_distance(d.pop("distance", UNSET))


        def _parse_target_vector(data: object) -> list[str] | MultiTargetVectorJoin | None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                target_vector_type_1 = cast(list[str], data)

                return target_vector_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                target_vector_type_2 = MultiTargetVectorJoin.from_dict(data)



                return target_vector_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | MultiTargetVectorJoin | None | str | Unset, data)

        target_vector = _parse_target_vector(d.pop("target_vector", UNSET))


        weaviate_vector_similarity_text_search_settings_configuration_response = cls(
            collection_name=collection_name,
            limit=limit,
            include_vector=include_vector,
            offset=offset,
            auto_limit=auto_limit,
            return_metadata=return_metadata,
            return_properties=return_properties,
            rag_provider=rag_provider,
            search_kind=search_kind,
            certainty=certainty,
            distance=distance,
            target_vector=target_vector,
        )


        weaviate_vector_similarity_text_search_settings_configuration_response.additional_properties = d
        return weaviate_vector_similarity_text_search_settings_configuration_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
