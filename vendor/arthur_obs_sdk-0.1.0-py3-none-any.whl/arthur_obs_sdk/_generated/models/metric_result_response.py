from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.metric_type import MetricType
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="MetricResultResponse")



@_attrs_define
class MetricResultResponse:
    """ 
        Attributes:
            id (str): ID of the metric result
            metric_type (MetricType):
            prompt_tokens (int): Number of prompt tokens used
            completion_tokens (int): Number of completion tokens used
            latency_ms (int): Latency in milliseconds
            span_id (str): ID of the span this result belongs to
            metric_id (str): ID of the metric that generated this result
            created_at (datetime.datetime): Time the result was created
            updated_at (datetime.datetime): Time the result was last updated
            details (None | str | Unset): JSON-serialized metric details
     """

    id: str
    metric_type: MetricType
    prompt_tokens: int
    completion_tokens: int
    latency_ms: int
    span_id: str
    metric_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    details: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        metric_type = self.metric_type.value

        prompt_tokens = self.prompt_tokens

        completion_tokens = self.completion_tokens

        latency_ms = self.latency_ms

        span_id = self.span_id

        metric_id = self.metric_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        details: None | str | Unset
        if isinstance(self.details, Unset):
            details = UNSET
        else:
            details = self.details


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "metric_type": metric_type,
            "prompt_tokens": prompt_tokens,
            "completion_tokens": completion_tokens,
            "latency_ms": latency_ms,
            "span_id": span_id,
            "metric_id": metric_id,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if details is not UNSET:
            field_dict["details"] = details

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        metric_type = MetricType(d.pop("metric_type"))




        prompt_tokens = d.pop("prompt_tokens")

        completion_tokens = d.pop("completion_tokens")

        latency_ms = d.pop("latency_ms")

        span_id = d.pop("span_id")

        metric_id = d.pop("metric_id")

        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        def _parse_details(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        details = _parse_details(d.pop("details", UNSET))


        metric_result_response = cls(
            id=id,
            metric_type=metric_type,
            prompt_tokens=prompt_tokens,
            completion_tokens=completion_tokens,
            latency_ms=latency_ms,
            span_id=span_id,
            metric_id=metric_id,
            created_at=created_at,
            updated_at=updated_at,
            details=details,
        )


        metric_result_response.additional_properties = d
        return metric_result_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
