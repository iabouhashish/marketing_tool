from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.tool_choice_function import ToolChoiceFunction





T = TypeVar("T", bound="ToolChoice")



@_attrs_define
class ToolChoice:
    """ 
        Attributes:
            type_ (str | Unset): The type of tool choice. Should always be 'function' Default: 'function'.
            function (None | ToolChoiceFunction | Unset): The tool choice fucntion name
     """

    type_: str | Unset = 'function'
    function: None | ToolChoiceFunction | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.tool_choice_function import ToolChoiceFunction
        type_ = self.type_

        function: dict[str, Any] | None | Unset
        if isinstance(self.function, Unset):
            function = UNSET
        elif isinstance(self.function, ToolChoiceFunction):
            function = self.function.to_dict()
        else:
            function = self.function


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if function is not UNSET:
            field_dict["function"] = function

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tool_choice_function import ToolChoiceFunction
        d = dict(src_dict)
        type_ = d.pop("type", UNSET)

        def _parse_function(data: object) -> None | ToolChoiceFunction | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                function_type_0 = ToolChoiceFunction.from_dict(data)



                return function_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | ToolChoiceFunction | Unset, data)

        function = _parse_function(d.pop("function", UNSET))


        tool_choice = cls(
            type_=type_,
            function=function,
        )


        tool_choice.additional_properties = d
        return tool_choice

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
