from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.rule_scope import RuleScope
from ..models.rule_type import RuleType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.pii_config import PIIConfig
  from ..models.keywords_config import KeywordsConfig
  from ..models.toxicity_config import ToxicityConfig
  from ..models.examples_config import ExamplesConfig
  from ..models.regex_config import RegexConfig





T = TypeVar("T", bound="RuleResponse")



@_attrs_define
class RuleResponse:
    """ 
        Attributes:
            id (str): ID of the Rule
            name (str): Name of the Rule
            type_ (RuleType):
            apply_to_prompt (bool): Rule applies to prompt
            apply_to_response (bool): Rule applies to response
            scope (RuleScope):
            created_at (int): Time the rule was created in unix milliseconds
            updated_at (int): Time the rule was updated in unix milliseconds
            enabled (bool | None | Unset): Rule is enabled for the task
            config (ExamplesConfig | KeywordsConfig | None | PIIConfig | RegexConfig | ToxicityConfig | Unset): Config of
                the rule
     """

    id: str
    name: str
    type_: RuleType
    apply_to_prompt: bool
    apply_to_response: bool
    scope: RuleScope
    created_at: int
    updated_at: int
    enabled: bool | None | Unset = UNSET
    config: ExamplesConfig | KeywordsConfig | None | PIIConfig | RegexConfig | ToxicityConfig | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.pii_config import PIIConfig
        from ..models.keywords_config import KeywordsConfig
        from ..models.toxicity_config import ToxicityConfig
        from ..models.examples_config import ExamplesConfig
        from ..models.regex_config import RegexConfig
        id = self.id

        name = self.name

        type_ = self.type_.value

        apply_to_prompt = self.apply_to_prompt

        apply_to_response = self.apply_to_response

        scope = self.scope.value

        created_at = self.created_at

        updated_at = self.updated_at

        enabled: bool | None | Unset
        if isinstance(self.enabled, Unset):
            enabled = UNSET
        else:
            enabled = self.enabled

        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, KeywordsConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, RegexConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, ExamplesConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, ToxicityConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, PIIConfig):
            config = self.config.to_dict()
        else:
            config = self.config


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "type": type_,
            "apply_to_prompt": apply_to_prompt,
            "apply_to_response": apply_to_response,
            "scope": scope,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if enabled is not UNSET:
            field_dict["enabled"] = enabled
        if config is not UNSET:
            field_dict["config"] = config

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.pii_config import PIIConfig
        from ..models.keywords_config import KeywordsConfig
        from ..models.toxicity_config import ToxicityConfig
        from ..models.examples_config import ExamplesConfig
        from ..models.regex_config import RegexConfig
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        type_ = RuleType(d.pop("type"))




        apply_to_prompt = d.pop("apply_to_prompt")

        apply_to_response = d.pop("apply_to_response")

        scope = RuleScope(d.pop("scope"))




        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        def _parse_enabled(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        enabled = _parse_enabled(d.pop("enabled", UNSET))


        def _parse_config(data: object) -> ExamplesConfig | KeywordsConfig | None | PIIConfig | RegexConfig | ToxicityConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0 = KeywordsConfig.from_dict(data)



                return config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_1 = RegexConfig.from_dict(data)



                return config_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_2 = ExamplesConfig.from_dict(data)



                return config_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_3 = ToxicityConfig.from_dict(data)



                return config_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_4 = PIIConfig.from_dict(data)



                return config_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ExamplesConfig | KeywordsConfig | None | PIIConfig | RegexConfig | ToxicityConfig | Unset, data)

        config = _parse_config(d.pop("config", UNSET))


        rule_response = cls(
            id=id,
            name=name,
            type_=type_,
            apply_to_prompt=apply_to_prompt,
            apply_to_response=apply_to_response,
            scope=scope,
            created_at=created_at,
            updated_at=updated_at,
            enabled=enabled,
            config=config,
        )


        rule_response.additional_properties = d
        return rule_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
