from enum import Enum

class HybridFusion(str, Enum):
    FUSION_TYPE_RANKED = "FUSION_TYPE_RANKED"
    FUSION_TYPE_RELATIVE_SCORE = "FUSION_TYPE_RELATIVE_SCORE"

    def __str__(self) -> str:
        return str(self.value)
