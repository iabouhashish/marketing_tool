from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.conversation_base_response import ConversationBaseResponse





T = TypeVar("T", bound="PageConversationBaseResponse")



@_attrs_define
class PageConversationBaseResponse:
    """ 
        Attributes:
            items (list[ConversationBaseResponse]):
            total (int):
            page (int):
            size (int):
            pages (int):
     """

    items: list[ConversationBaseResponse]
    total: int
    page: int
    size: int
    pages: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.conversation_base_response import ConversationBaseResponse
        items = []
        for items_item_data in self.items:
            items_item = items_item_data.to_dict()
            items.append(items_item)



        total = self.total

        page = self.page

        size = self.size

        pages = self.pages


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "items": items,
            "total": total,
            "page": page,
            "size": size,
            "pages": pages,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.conversation_base_response import ConversationBaseResponse
        d = dict(src_dict)
        items = []
        _items = d.pop("items")
        for items_item_data in (_items):
            items_item = ConversationBaseResponse.from_dict(items_item_data)



            items.append(items_item)


        total = d.pop("total")

        page = d.pop("page")

        size = d.pop("size")

        pages = d.pop("pages")

        page_conversation_base_response = cls(
            items=items,
            total=total,
            page=page,
            size=size,
            pages=pages,
        )


        page_conversation_base_response.additional_properties = d
        return page_conversation_base_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
