from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.experiment_status import ExperimentStatus
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="NotebookSummary")



@_attrs_define
class NotebookSummary:
    """ Summary of a notebook

        Attributes:
            id (str): Notebook ID
            task_id (str): Associated task ID
            name (str): Notebook name
            created_at (str): ISO timestamp when created
            updated_at (str): ISO timestamp when last updated
            run_count (int): Number of experiments run from this notebook
            description (None | str | Unset): Description
            latest_run_id (None | str | Unset): ID of most recent experiment run
            latest_run_status (ExperimentStatus | None | Unset): Status of most recent experiment
     """

    id: str
    task_id: str
    name: str
    created_at: str
    updated_at: str
    run_count: int
    description: None | str | Unset = UNSET
    latest_run_id: None | str | Unset = UNSET
    latest_run_status: ExperimentStatus | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        task_id = self.task_id

        name = self.name

        created_at = self.created_at

        updated_at = self.updated_at

        run_count = self.run_count

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        latest_run_id: None | str | Unset
        if isinstance(self.latest_run_id, Unset):
            latest_run_id = UNSET
        else:
            latest_run_id = self.latest_run_id

        latest_run_status: None | str | Unset
        if isinstance(self.latest_run_status, Unset):
            latest_run_status = UNSET
        elif isinstance(self.latest_run_status, ExperimentStatus):
            latest_run_status = self.latest_run_status.value
        else:
            latest_run_status = self.latest_run_status


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "task_id": task_id,
            "name": name,
            "created_at": created_at,
            "updated_at": updated_at,
            "run_count": run_count,
        })
        if description is not UNSET:
            field_dict["description"] = description
        if latest_run_id is not UNSET:
            field_dict["latest_run_id"] = latest_run_id
        if latest_run_status is not UNSET:
            field_dict["latest_run_status"] = latest_run_status

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        task_id = d.pop("task_id")

        name = d.pop("name")

        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        run_count = d.pop("run_count")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_latest_run_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        latest_run_id = _parse_latest_run_id(d.pop("latest_run_id", UNSET))


        def _parse_latest_run_status(data: object) -> ExperimentStatus | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                latest_run_status_type_0 = ExperimentStatus(data)



                return latest_run_status_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ExperimentStatus | None | Unset, data)

        latest_run_status = _parse_latest_run_status(d.pop("latest_run_status", UNSET))


        notebook_summary = cls(
            id=id,
            task_id=task_id,
            name=name,
            created_at=created_at,
            updated_at=updated_at,
            run_count=run_count,
            description=description,
            latest_run_id=latest_run_id,
            latest_run_status=latest_run_status,
        )


        notebook_summary.additional_properties = d
        return notebook_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
