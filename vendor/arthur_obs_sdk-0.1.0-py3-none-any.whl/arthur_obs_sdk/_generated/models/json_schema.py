from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.json_schema_properties import JsonSchemaProperties





T = TypeVar("T", bound="JsonSchema")



@_attrs_define
class JsonSchema:
    """ 
        Attributes:
            properties (JsonSchemaProperties): The name of the property and the property schema (e.g. {'topic': {'type':
                'string', 'description': 'the topic to generate a joke for'})
            type_ (str | Unset):  Default: 'object'.
            required (list[str] | Unset): The required properties of the function
            additional_properties (bool | None | Unset): Whether the function definition should allow additional properties
     """

    properties: JsonSchemaProperties
    type_: str | Unset = 'object'
    required: list[str] | Unset = UNSET
    additional_properties: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.json_schema_properties import JsonSchemaProperties
        properties = self.properties.to_dict()

        type_ = self.type_

        required: list[str] | Unset = UNSET
        if not isinstance(self.required, Unset):
            required = self.required



        additional_properties: bool | None | Unset
        if isinstance(self.additional_properties, Unset):
            additional_properties = UNSET
        else:
            additional_properties = self.additional_properties


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "properties": properties,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if required is not UNSET:
            field_dict["required"] = required
        if additional_properties is not UNSET:
            field_dict["additionalProperties"] = additional_properties

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.json_schema_properties import JsonSchemaProperties
        d = dict(src_dict)
        properties = JsonSchemaProperties.from_dict(d.pop("properties"))




        type_ = d.pop("type", UNSET)

        required = cast(list[str], d.pop("required", UNSET))


        def _parse_additional_properties(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        additional_properties = _parse_additional_properties(d.pop("additionalProperties", UNSET))


        json_schema = cls(
            properties=properties,
            type_=type_,
            required=required,
            additional_properties=additional_properties,
        )


        json_schema.additional_properties = d
        return json_schema

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
