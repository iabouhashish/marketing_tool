from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="UnregisteredRootSpanGroup")



@_attrs_define
class UnregisteredRootSpanGroup:
    """ Group of root spans with the same span_name for unregistered traces

        Attributes:
            span_name (str): Name of the root span
            count (int): Number of root spans (and traces) in this group
     """

    span_name: str
    count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        span_name = self.span_name

        count = self.count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "span_name": span_name,
            "count": count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        span_name = d.pop("span_name")

        count = d.pop("count")

        unregistered_root_span_group = cls(
            span_name=span_name,
            count=count,
        )


        unregistered_root_span_group.additional_properties = d
        return unregistered_root_span_group

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
