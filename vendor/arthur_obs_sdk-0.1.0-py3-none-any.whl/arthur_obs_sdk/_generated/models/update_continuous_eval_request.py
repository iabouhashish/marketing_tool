from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID






T = TypeVar("T", bound="UpdateContinuousEvalRequest")



@_attrs_define
class UpdateContinuousEvalRequest:
    """ Request schema for creating a continuous eval

        Attributes:
            name (None | str | Unset): Name of the continuous eval
            description (None | str | Unset): Description of the continuous eval
            llm_eval_name (None | str | Unset): Name of the llm eval to create the continuous eval for
            llm_eval_version (int | None | str | Unset): Version of the llm eval to create the continuous eval for. Can be
                'latest', a version number (e.g. '1', '2', etc.), an ISO datetime string (e.g. '2025-01-01T00:00:00'), or a tag.
            transform_id (None | Unset | UUID): ID of the transform to create the continuous eval for
     """

    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    llm_eval_name: None | str | Unset = UNSET
    llm_eval_version: int | None | str | Unset = UNSET
    transform_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        llm_eval_name: None | str | Unset
        if isinstance(self.llm_eval_name, Unset):
            llm_eval_name = UNSET
        else:
            llm_eval_name = self.llm_eval_name

        llm_eval_version: int | None | str | Unset
        if isinstance(self.llm_eval_version, Unset):
            llm_eval_version = UNSET
        else:
            llm_eval_version = self.llm_eval_version

        transform_id: None | str | Unset
        if isinstance(self.transform_id, Unset):
            transform_id = UNSET
        elif isinstance(self.transform_id, UUID):
            transform_id = str(self.transform_id)
        else:
            transform_id = self.transform_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if llm_eval_name is not UNSET:
            field_dict["llm_eval_name"] = llm_eval_name
        if llm_eval_version is not UNSET:
            field_dict["llm_eval_version"] = llm_eval_version
        if transform_id is not UNSET:
            field_dict["transform_id"] = transform_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_llm_eval_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        llm_eval_name = _parse_llm_eval_name(d.pop("llm_eval_name", UNSET))


        def _parse_llm_eval_version(data: object) -> int | None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | str | Unset, data)

        llm_eval_version = _parse_llm_eval_version(d.pop("llm_eval_version", UNSET))


        def _parse_transform_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                transform_id_type_0 = UUID(data)



                return transform_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        transform_id = _parse_transform_id(d.pop("transform_id", UNSET))


        update_continuous_eval_request = cls(
            name=name,
            description=description,
            llm_eval_name=llm_eval_name,
            llm_eval_version=llm_eval_version,
            transform_id=transform_id,
        )


        update_continuous_eval_request.additional_properties = d
        return update_continuous_eval_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
