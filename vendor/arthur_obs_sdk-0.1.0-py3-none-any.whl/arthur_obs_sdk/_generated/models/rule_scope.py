from enum import Enum

class RuleScope(str, Enum):
    DEFAULT = "default"
    TASK = "task"

    def __str__(self) -> str:
        return str(self.value)
