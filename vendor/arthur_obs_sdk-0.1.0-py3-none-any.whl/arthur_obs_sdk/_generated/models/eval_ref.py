from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.eval_variable_mapping import EvalVariableMapping





T = TypeVar("T", bound="EvalRef")



@_attrs_define
class EvalRef:
    """ Reference to an evaluation configuration

        Attributes:
            name (str): Name of the evaluation
            version (int): Version of the evaluation
            variable_mapping (list[EvalVariableMapping]): Mapping of eval variables to data sources
     """

    name: str
    version: int
    variable_mapping: list[EvalVariableMapping]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.eval_variable_mapping import EvalVariableMapping
        name = self.name

        version = self.version

        variable_mapping = []
        for variable_mapping_item_data in self.variable_mapping:
            variable_mapping_item = variable_mapping_item_data.to_dict()
            variable_mapping.append(variable_mapping_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "version": version,
            "variable_mapping": variable_mapping,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.eval_variable_mapping import EvalVariableMapping
        d = dict(src_dict)
        name = d.pop("name")

        version = d.pop("version")

        variable_mapping = []
        _variable_mapping = d.pop("variable_mapping")
        for variable_mapping_item_data in (_variable_mapping):
            variable_mapping_item = EvalVariableMapping.from_dict(variable_mapping_item_data)



            variable_mapping.append(variable_mapping_item)


        eval_ref = cls(
            name=name,
            version=version,
            variable_mapping=variable_mapping,
        )


        eval_ref.additional_properties = d
        return eval_ref

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
