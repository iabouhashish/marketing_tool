from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.model_provider import ModelProvider
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.llm_request_config_settings import LLMRequestConfigSettings





T = TypeVar("T", bound="CreateEvalRequest")



@_attrs_define
class CreateEvalRequest:
    """ 
        Attributes:
            model_name (str): Name of the LLM model (e.g., 'gpt-4o', 'claude-3-sonnet')
            model_provider (ModelProvider):
            instructions (str): Instructions for the llm eval
            config (LLMRequestConfigSettings | None | Unset): LLM configurations for this eval (e.g. temperature,
                max_tokens, etc.)
     """

    model_name: str
    model_provider: ModelProvider
    instructions: str
    config: LLMRequestConfigSettings | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.llm_request_config_settings import LLMRequestConfigSettings
        model_name = self.model_name

        model_provider = self.model_provider.value

        instructions = self.instructions

        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, LLMRequestConfigSettings):
            config = self.config.to_dict()
        else:
            config = self.config


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "model_name": model_name,
            "model_provider": model_provider,
            "instructions": instructions,
        })
        if config is not UNSET:
            field_dict["config"] = config

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.llm_request_config_settings import LLMRequestConfigSettings
        d = dict(src_dict)
        model_name = d.pop("model_name")

        model_provider = ModelProvider(d.pop("model_provider"))




        instructions = d.pop("instructions")

        def _parse_config(data: object) -> LLMRequestConfigSettings | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0 = LLMRequestConfigSettings.from_dict(data)



                return config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LLMRequestConfigSettings | None | Unset, data)

        config = _parse_config(d.pop("config", UNSET))


        create_eval_request = cls(
            model_name=model_name,
            model_provider=model_provider,
            instructions=instructions,
            config=config,
        )


        create_eval_request.additional_properties = d
        return create_eval_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
