from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.api_key_rag_authentication_config_update_request import ApiKeyRagAuthenticationConfigUpdateRequest





T = TypeVar("T", bound="RagProviderConfigurationUpdateRequest")



@_attrs_define
class RagProviderConfigurationUpdateRequest:
    """ 
        Attributes:
            authentication_config (ApiKeyRagAuthenticationConfigUpdateRequest | None | Unset): Configuration of the
                authentication strategy.
            name (None | str | Unset): Name of RAG provider configuration.
            description (None | str | Unset): Description of RAG provider configuration.
     """

    authentication_config: ApiKeyRagAuthenticationConfigUpdateRequest | None | Unset = UNSET
    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.api_key_rag_authentication_config_update_request import ApiKeyRagAuthenticationConfigUpdateRequest
        authentication_config: dict[str, Any] | None | Unset
        if isinstance(self.authentication_config, Unset):
            authentication_config = UNSET
        elif isinstance(self.authentication_config, ApiKeyRagAuthenticationConfigUpdateRequest):
            authentication_config = self.authentication_config.to_dict()
        else:
            authentication_config = self.authentication_config

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if authentication_config is not UNSET:
            field_dict["authentication_config"] = authentication_config
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key_rag_authentication_config_update_request import ApiKeyRagAuthenticationConfigUpdateRequest
        d = dict(src_dict)
        def _parse_authentication_config(data: object) -> ApiKeyRagAuthenticationConfigUpdateRequest | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                authentication_config_type_0 = ApiKeyRagAuthenticationConfigUpdateRequest.from_dict(data)



                return authentication_config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ApiKeyRagAuthenticationConfigUpdateRequest | None | Unset, data)

        authentication_config = _parse_authentication_config(d.pop("authentication_config", UNSET))


        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        rag_provider_configuration_update_request = cls(
            authentication_config=authentication_config,
            name=name,
            description=description,
        )


        rag_provider_configuration_update_request.additional_properties = d
        return rag_provider_configuration_update_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
