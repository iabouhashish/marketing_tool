from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.message_role import MessageRole
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.open_ai_message_item import OpenAIMessageItem
  from ..models.tool_call import ToolCall





T = TypeVar("T", bound="OpenAIMessage")



@_attrs_define
class OpenAIMessage:
    """ The message schema class for the prompts playground.
    This class adheres to OpenAI's message schema.

        Attributes:
            role (MessageRole):
            name (None | str | Unset): An optional name for the participant. Provides the model information to differentiate
                between participants of the same role.
            content (list[OpenAIMessageItem] | None | str | Unset): Content of the message
            tool_calls (list[ToolCall] | None | Unset): Tool calls made by assistant
            tool_call_id (None | str | Unset): ID of the tool call this message is responding to
     """

    role: MessageRole
    name: None | str | Unset = UNSET
    content: list[OpenAIMessageItem] | None | str | Unset = UNSET
    tool_calls: list[ToolCall] | None | Unset = UNSET
    tool_call_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.open_ai_message_item import OpenAIMessageItem
        from ..models.tool_call import ToolCall
        role = self.role.value

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        content: list[dict[str, Any]] | None | str | Unset
        if isinstance(self.content, Unset):
            content = UNSET
        elif isinstance(self.content, list):
            content = []
            for content_type_1_item_data in self.content:
                content_type_1_item = content_type_1_item_data.to_dict()
                content.append(content_type_1_item)


        else:
            content = self.content

        tool_calls: list[dict[str, Any]] | None | Unset
        if isinstance(self.tool_calls, Unset):
            tool_calls = UNSET
        elif isinstance(self.tool_calls, list):
            tool_calls = []
            for tool_calls_type_0_item_data in self.tool_calls:
                tool_calls_type_0_item = tool_calls_type_0_item_data.to_dict()
                tool_calls.append(tool_calls_type_0_item)


        else:
            tool_calls = self.tool_calls

        tool_call_id: None | str | Unset
        if isinstance(self.tool_call_id, Unset):
            tool_call_id = UNSET
        else:
            tool_call_id = self.tool_call_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "role": role,
        })
        if name is not UNSET:
            field_dict["name"] = name
        if content is not UNSET:
            field_dict["content"] = content
        if tool_calls is not UNSET:
            field_dict["tool_calls"] = tool_calls
        if tool_call_id is not UNSET:
            field_dict["tool_call_id"] = tool_call_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.open_ai_message_item import OpenAIMessageItem
        from ..models.tool_call import ToolCall
        d = dict(src_dict)
        role = MessageRole(d.pop("role"))




        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))


        def _parse_content(data: object) -> list[OpenAIMessageItem] | None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                content_type_1 = []
                _content_type_1 = data
                for content_type_1_item_data in (_content_type_1):
                    content_type_1_item = OpenAIMessageItem.from_dict(content_type_1_item_data)



                    content_type_1.append(content_type_1_item)

                return content_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[OpenAIMessageItem] | None | str | Unset, data)

        content = _parse_content(d.pop("content", UNSET))


        def _parse_tool_calls(data: object) -> list[ToolCall] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tool_calls_type_0 = []
                _tool_calls_type_0 = data
                for tool_calls_type_0_item_data in (_tool_calls_type_0):
                    tool_calls_type_0_item = ToolCall.from_dict(tool_calls_type_0_item_data)



                    tool_calls_type_0.append(tool_calls_type_0_item)

                return tool_calls_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ToolCall] | None | Unset, data)

        tool_calls = _parse_tool_calls(d.pop("tool_calls", UNSET))


        def _parse_tool_call_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        tool_call_id = _parse_tool_call_id(d.pop("tool_call_id", UNSET))


        open_ai_message = cls(
            role=role,
            name=name,
            content=content,
            tool_calls=tool_calls,
            tool_call_id=tool_call_id,
        )


        open_ai_message.additional_properties = d
        return open_ai_message

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
