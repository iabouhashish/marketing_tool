from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.rag_notebook_state import RagNotebookState





T = TypeVar("T", bound="SetRagNotebookStateRequest")



@_attrs_define
class SetRagNotebookStateRequest:
    """ Request to set the RAG notebook state

        Attributes:
            state (RagNotebookState): Draft state of a RAG notebook - mirrors RAG experiment config but all fields optional.
                Used for requests (input).
     """

    state: RagNotebookState
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rag_notebook_state import RagNotebookState
        state = self.state.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "state": state,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rag_notebook_state import RagNotebookState
        d = dict(src_dict)
        state = RagNotebookState.from_dict(d.pop("state"))




        set_rag_notebook_state_request = cls(
            state=state,
        )


        set_rag_notebook_state_request.additional_properties = d
        return set_rag_notebook_state_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
