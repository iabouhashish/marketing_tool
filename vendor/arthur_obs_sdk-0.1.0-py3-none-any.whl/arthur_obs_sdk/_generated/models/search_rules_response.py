from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.rule_response import RuleResponse





T = TypeVar("T", bound="SearchRulesResponse")



@_attrs_define
class SearchRulesResponse:
    """ 
        Attributes:
            count (int): The total number of rules matching the parameters
            rules (list[RuleResponse]): List of rules matching the search filters. Length is less than or equal to page_size
                parameter
     """

    count: int
    rules: list[RuleResponse]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rule_response import RuleResponse
        count = self.count

        rules = []
        for rules_item_data in self.rules:
            rules_item = rules_item_data.to_dict()
            rules.append(rules_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "count": count,
            "rules": rules,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rule_response import RuleResponse
        d = dict(src_dict)
        count = d.pop("count")

        rules = []
        _rules = d.pop("rules")
        for rules_item_data in (_rules):
            rules_item = RuleResponse.from_dict(rules_item_data)



            rules.append(rules_item)


        search_rules_response = cls(
            count=count,
            rules=rules,
        )


        search_rules_response.additional_properties = d
        return search_rules_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
