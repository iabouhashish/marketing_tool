from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.test_case_status import TestCaseStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.rag_result import RagResult





T = TypeVar("T", bound="RagTestCase")



@_attrs_define
class RagTestCase:
    """ Individual test case result for RAG experiment

        Attributes:
            status (TestCaseStatus): Status of a test case
            dataset_row_id (str): ID of the dataset row
            rag_results (list[RagResult]): Results for each RAG configuration tested
            total_cost (None | str | Unset): Total cost for this test case
     """

    status: TestCaseStatus
    dataset_row_id: str
    rag_results: list[RagResult]
    total_cost: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rag_result import RagResult
        status = self.status.value

        dataset_row_id = self.dataset_row_id

        rag_results = []
        for rag_results_item_data in self.rag_results:
            rag_results_item = rag_results_item_data.to_dict()
            rag_results.append(rag_results_item)



        total_cost: None | str | Unset
        if isinstance(self.total_cost, Unset):
            total_cost = UNSET
        else:
            total_cost = self.total_cost


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
            "dataset_row_id": dataset_row_id,
            "rag_results": rag_results,
        })
        if total_cost is not UNSET:
            field_dict["total_cost"] = total_cost

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rag_result import RagResult
        d = dict(src_dict)
        status = TestCaseStatus(d.pop("status"))




        dataset_row_id = d.pop("dataset_row_id")

        rag_results = []
        _rag_results = d.pop("rag_results")
        for rag_results_item_data in (_rag_results):
            rag_results_item = RagResult.from_dict(rag_results_item_data)



            rag_results.append(rag_results_item)


        def _parse_total_cost(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        total_cost = _parse_total_cost(d.pop("total_cost", UNSET))


        rag_test_case = cls(
            status=status,
            dataset_row_id=dataset_row_id,
            rag_results=rag_results,
            total_cost=total_cost,
        )


        rag_test_case.additional_properties = d
        return rag_test_case

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
