from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.pii_entity_types import PIIEntityTypes
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="PIIEntitySpanResponse")



@_attrs_define
class PIIEntitySpanResponse:
    """ 
        Attributes:
            entity (PIIEntityTypes):
            span (str): The subtext within the input string that was identified as PII.
            confidence (float | None | Unset): Float value representing the confidence score of a given PII identification.
     """

    entity: PIIEntityTypes
    span: str
    confidence: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        entity = self.entity.value

        span = self.span

        confidence: float | None | Unset
        if isinstance(self.confidence, Unset):
            confidence = UNSET
        else:
            confidence = self.confidence


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "entity": entity,
            "span": span,
        })
        if confidence is not UNSET:
            field_dict["confidence"] = confidence

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        entity = PIIEntityTypes(d.pop("entity"))




        span = d.pop("span")

        def _parse_confidence(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        confidence = _parse_confidence(d.pop("confidence", UNSET))


        pii_entity_span_response = cls(
            entity=entity,
            span=span,
            confidence=confidence,
        )


        pii_entity_span_response.additional_properties = d
        return pii_entity_span_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
