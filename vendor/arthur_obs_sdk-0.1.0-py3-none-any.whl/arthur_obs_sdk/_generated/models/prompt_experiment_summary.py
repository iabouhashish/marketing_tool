from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.experiment_status import ExperimentStatus
from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.unsaved_prompt_config import UnsavedPromptConfig
  from ..models.saved_prompt_config import SavedPromptConfig





T = TypeVar("T", bound="PromptExperimentSummary")



@_attrs_define
class PromptExperimentSummary:
    """ Summary of a prompt experiment

        Attributes:
            id (str): Unique identifier for the experiment
            name (str): Name of the experiment
            created_at (str): ISO timestamp when experiment was created
            status (ExperimentStatus): Status of an experiment
            dataset_id (UUID): ID of the dataset used
            dataset_name (str): Name of the dataset used
            dataset_version (int): Version of the dataset used
            total_rows (int): Total number of test rows in the experiment
            completed_rows (int): Number of test rows completed successfully
            failed_rows (int): Number of test rows that failed
            prompt_configs (list[SavedPromptConfig | UnsavedPromptConfig]): List of prompts being tested
            description (None | str | Unset): Description of the experiment
            finished_at (None | str | Unset): ISO timestamp when experiment finished
            total_cost (None | str | Unset): Total cost of running the experiment
     """

    id: str
    name: str
    created_at: str
    status: ExperimentStatus
    dataset_id: UUID
    dataset_name: str
    dataset_version: int
    total_rows: int
    completed_rows: int
    failed_rows: int
    prompt_configs: list[SavedPromptConfig | UnsavedPromptConfig]
    description: None | str | Unset = UNSET
    finished_at: None | str | Unset = UNSET
    total_cost: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.unsaved_prompt_config import UnsavedPromptConfig
        from ..models.saved_prompt_config import SavedPromptConfig
        id = self.id

        name = self.name

        created_at = self.created_at

        status = self.status.value

        dataset_id = str(self.dataset_id)

        dataset_name = self.dataset_name

        dataset_version = self.dataset_version

        total_rows = self.total_rows

        completed_rows = self.completed_rows

        failed_rows = self.failed_rows

        prompt_configs = []
        for prompt_configs_item_data in self.prompt_configs:
            prompt_configs_item: dict[str, Any]
            if isinstance(prompt_configs_item_data, SavedPromptConfig):
                prompt_configs_item = prompt_configs_item_data.to_dict()
            else:
                prompt_configs_item = prompt_configs_item_data.to_dict()

            prompt_configs.append(prompt_configs_item)



        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        finished_at: None | str | Unset
        if isinstance(self.finished_at, Unset):
            finished_at = UNSET
        else:
            finished_at = self.finished_at

        total_cost: None | str | Unset
        if isinstance(self.total_cost, Unset):
            total_cost = UNSET
        else:
            total_cost = self.total_cost


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "created_at": created_at,
            "status": status,
            "dataset_id": dataset_id,
            "dataset_name": dataset_name,
            "dataset_version": dataset_version,
            "total_rows": total_rows,
            "completed_rows": completed_rows,
            "failed_rows": failed_rows,
            "prompt_configs": prompt_configs,
        })
        if description is not UNSET:
            field_dict["description"] = description
        if finished_at is not UNSET:
            field_dict["finished_at"] = finished_at
        if total_cost is not UNSET:
            field_dict["total_cost"] = total_cost

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.unsaved_prompt_config import UnsavedPromptConfig
        from ..models.saved_prompt_config import SavedPromptConfig
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        created_at = d.pop("created_at")

        status = ExperimentStatus(d.pop("status"))




        dataset_id = UUID(d.pop("dataset_id"))




        dataset_name = d.pop("dataset_name")

        dataset_version = d.pop("dataset_version")

        total_rows = d.pop("total_rows")

        completed_rows = d.pop("completed_rows")

        failed_rows = d.pop("failed_rows")

        prompt_configs = []
        _prompt_configs = d.pop("prompt_configs")
        for prompt_configs_item_data in (_prompt_configs):
            def _parse_prompt_configs_item(data: object) -> SavedPromptConfig | UnsavedPromptConfig:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    prompt_configs_item_type_0 = SavedPromptConfig.from_dict(data)



                    return prompt_configs_item_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                prompt_configs_item_type_1 = UnsavedPromptConfig.from_dict(data)



                return prompt_configs_item_type_1

            prompt_configs_item = _parse_prompt_configs_item(prompt_configs_item_data)

            prompt_configs.append(prompt_configs_item)


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_finished_at(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        finished_at = _parse_finished_at(d.pop("finished_at", UNSET))


        def _parse_total_cost(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        total_cost = _parse_total_cost(d.pop("total_cost", UNSET))


        prompt_experiment_summary = cls(
            id=id,
            name=name,
            created_at=created_at,
            status=status,
            dataset_id=dataset_id,
            dataset_name=dataset_name,
            dataset_version=dataset_version,
            total_rows=total_rows,
            completed_rows=completed_rows,
            failed_rows=failed_rows,
            prompt_configs=prompt_configs,
            description=description,
            finished_at=finished_at,
            total_cost=total_cost,
        )


        prompt_experiment_summary.additional_properties = d
        return prompt_experiment_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
