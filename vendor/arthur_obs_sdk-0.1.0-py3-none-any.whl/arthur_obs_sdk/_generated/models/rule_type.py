from enum import Enum

class RuleType(str, Enum):
    KEYWORDRULE = "KeywordRule"
    MODELHALLUCINATIONRULEV2 = "ModelHallucinationRuleV2"
    MODELSENSITIVEDATARULE = "ModelSensitiveDataRule"
    PIIDATARULE = "PIIDataRule"
    PROMPTINJECTIONRULE = "PromptInjectionRule"
    REGEXRULE = "RegexRule"
    TOXICITYRULE = "ToxicityRule"

    def __str__(self) -> str:
        return str(self.value)
