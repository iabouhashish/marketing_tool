from enum import Enum

class UserPermissionResource(str, Enum):
    PROMPTS = "prompts"
    RESPONSES = "responses"
    RULES = "rules"
    TASKS = "tasks"

    def __str__(self) -> str:
        return str(self.value)
