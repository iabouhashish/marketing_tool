from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from uuid import UUID






T = TypeVar("T", bound="DatasetVersionMetadataResponse")



@_attrs_define
class DatasetVersionMetadataResponse:
    """ 
        Attributes:
            version_number (int): Version number of the dataset version.
            created_at (int): Timestamp representing the time of dataset version creation in unix milliseconds.
            dataset_id (UUID): ID of the dataset.
            column_names (list[str]): Names of all columns in the dataset version.
     """

    version_number: int
    created_at: int
    dataset_id: UUID
    column_names: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        version_number = self.version_number

        created_at = self.created_at

        dataset_id = str(self.dataset_id)

        column_names = self.column_names




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "version_number": version_number,
            "created_at": created_at,
            "dataset_id": dataset_id,
            "column_names": column_names,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        version_number = d.pop("version_number")

        created_at = d.pop("created_at")

        dataset_id = UUID(d.pop("dataset_id"))




        column_names = cast(list[str], d.pop("column_names"))


        dataset_version_metadata_response = cls(
            version_number=version_number,
            created_at=created_at,
            dataset_id=dataset_id,
            column_names=column_names,
        )


        dataset_version_metadata_response.additional_properties = d
        return dataset_version_metadata_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
