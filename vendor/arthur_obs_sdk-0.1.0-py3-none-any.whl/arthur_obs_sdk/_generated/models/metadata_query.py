from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="MetadataQuery")



@_attrs_define
class MetadataQuery:
    """ Define which metadata should be returned in the query's results.

        Attributes:
            creation_time (bool | Unset):  Default: False.
            last_update_time (bool | Unset):  Default: False.
            distance (bool | Unset):  Default: False.
            certainty (bool | Unset):  Default: False.
            score (bool | Unset):  Default: False.
            explain_score (bool | Unset):  Default: False.
            is_consistent (bool | Unset):  Default: False.
     """

    creation_time: bool | Unset = False
    last_update_time: bool | Unset = False
    distance: bool | Unset = False
    certainty: bool | Unset = False
    score: bool | Unset = False
    explain_score: bool | Unset = False
    is_consistent: bool | Unset = False





    def to_dict(self) -> dict[str, Any]:
        creation_time = self.creation_time

        last_update_time = self.last_update_time

        distance = self.distance

        certainty = self.certainty

        score = self.score

        explain_score = self.explain_score

        is_consistent = self.is_consistent


        field_dict: dict[str, Any] = {}

        field_dict.update({
        })
        if creation_time is not UNSET:
            field_dict["creation_time"] = creation_time
        if last_update_time is not UNSET:
            field_dict["last_update_time"] = last_update_time
        if distance is not UNSET:
            field_dict["distance"] = distance
        if certainty is not UNSET:
            field_dict["certainty"] = certainty
        if score is not UNSET:
            field_dict["score"] = score
        if explain_score is not UNSET:
            field_dict["explain_score"] = explain_score
        if is_consistent is not UNSET:
            field_dict["is_consistent"] = is_consistent

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        creation_time = d.pop("creation_time", UNSET)

        last_update_time = d.pop("last_update_time", UNSET)

        distance = d.pop("distance", UNSET)

        certainty = d.pop("certainty", UNSET)

        score = d.pop("score", UNSET)

        explain_score = d.pop("explain_score", UNSET)

        is_consistent = d.pop("is_consistent", UNSET)

        metadata_query = cls(
            creation_time=creation_time,
            last_update_time=last_update_time,
            distance=distance,
            certainty=certainty,
            score=score,
            explain_score=explain_score,
            is_consistent=is_consistent,
        )

        return metadata_query

