from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.eval_result_summary import EvalResultSummary





T = TypeVar("T", bound="PromptEvalResultSummaries")



@_attrs_define
class PromptEvalResultSummaries:
    """ Summary of evaluation results for a prompt version

        Attributes:
            eval_results (list[EvalResultSummary]): Results for each evaluation run on this prompt version
            prompt_key (None | str | Unset): Prompt key: 'saved:name:version' or 'unsaved:auto_name'
            prompt_type (None | str | Unset): Type: 'saved' or 'unsaved'
            prompt_name (None | str | Unset): Name of the prompt (for saved prompts, or auto_name for unsaved)
            prompt_version (None | str | Unset): Version of the prompt (for saved prompts only)
     """

    eval_results: list[EvalResultSummary]
    prompt_key: None | str | Unset = UNSET
    prompt_type: None | str | Unset = UNSET
    prompt_name: None | str | Unset = UNSET
    prompt_version: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.eval_result_summary import EvalResultSummary
        eval_results = []
        for eval_results_item_data in self.eval_results:
            eval_results_item = eval_results_item_data.to_dict()
            eval_results.append(eval_results_item)



        prompt_key: None | str | Unset
        if isinstance(self.prompt_key, Unset):
            prompt_key = UNSET
        else:
            prompt_key = self.prompt_key

        prompt_type: None | str | Unset
        if isinstance(self.prompt_type, Unset):
            prompt_type = UNSET
        else:
            prompt_type = self.prompt_type

        prompt_name: None | str | Unset
        if isinstance(self.prompt_name, Unset):
            prompt_name = UNSET
        else:
            prompt_name = self.prompt_name

        prompt_version: None | str | Unset
        if isinstance(self.prompt_version, Unset):
            prompt_version = UNSET
        else:
            prompt_version = self.prompt_version


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "eval_results": eval_results,
        })
        if prompt_key is not UNSET:
            field_dict["prompt_key"] = prompt_key
        if prompt_type is not UNSET:
            field_dict["prompt_type"] = prompt_type
        if prompt_name is not UNSET:
            field_dict["prompt_name"] = prompt_name
        if prompt_version is not UNSET:
            field_dict["prompt_version"] = prompt_version

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.eval_result_summary import EvalResultSummary
        d = dict(src_dict)
        eval_results = []
        _eval_results = d.pop("eval_results")
        for eval_results_item_data in (_eval_results):
            eval_results_item = EvalResultSummary.from_dict(eval_results_item_data)



            eval_results.append(eval_results_item)


        def _parse_prompt_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        prompt_key = _parse_prompt_key(d.pop("prompt_key", UNSET))


        def _parse_prompt_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        prompt_type = _parse_prompt_type(d.pop("prompt_type", UNSET))


        def _parse_prompt_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        prompt_name = _parse_prompt_name(d.pop("prompt_name", UNSET))


        def _parse_prompt_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        prompt_version = _parse_prompt_version(d.pop("prompt_version", UNSET))


        prompt_eval_result_summaries = cls(
            eval_results=eval_results,
            prompt_key=prompt_key,
            prompt_type=prompt_type,
            prompt_name=prompt_name,
            prompt_version=prompt_version,
        )


        prompt_eval_result_summaries.additional_properties = d
        return prompt_eval_result_summaries

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
