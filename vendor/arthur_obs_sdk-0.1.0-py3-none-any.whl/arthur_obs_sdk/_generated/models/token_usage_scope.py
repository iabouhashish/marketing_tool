from enum import Enum

class TokenUsageScope(str, Enum):
    RULE_TYPE = "rule_type"
    TASK = "task"

    def __str__(self) -> str:
        return str(self.value)
