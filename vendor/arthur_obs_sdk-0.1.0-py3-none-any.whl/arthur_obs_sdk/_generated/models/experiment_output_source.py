from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="ExperimentOutputSource")



@_attrs_define
class ExperimentOutputSource:
    """ Reference to experiment output

        Attributes:
            json_path (None | str | Unset): Optional JSON path to extract from experiment output. Should use dot notation
                for array indexing (eg. response.objects.0.properties.category)
     """

    json_path: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        json_path: None | str | Unset
        if isinstance(self.json_path, Unset):
            json_path = UNSET
        else:
            json_path = self.json_path


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if json_path is not UNSET:
            field_dict["json_path"] = json_path

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_json_path(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        json_path = _parse_json_path(d.pop("json_path", UNSET))


        experiment_output_source = cls(
            json_path=json_path,
        )


        experiment_output_source.additional_properties = d
        return experiment_output_source

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
