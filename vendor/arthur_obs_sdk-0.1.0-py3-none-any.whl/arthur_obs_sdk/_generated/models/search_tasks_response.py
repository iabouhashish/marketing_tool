from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.task_response import TaskResponse





T = TypeVar("T", bound="SearchTasksResponse")



@_attrs_define
class SearchTasksResponse:
    """ 
        Attributes:
            count (int): The total number of tasks matching the parameters
            tasks (list[TaskResponse]): List of tasks matching the search filters. Length is less than or equal to page_size
                parameter
     """

    count: int
    tasks: list[TaskResponse]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.task_response import TaskResponse
        count = self.count

        tasks = []
        for tasks_item_data in self.tasks:
            tasks_item = tasks_item_data.to_dict()
            tasks.append(tasks_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "count": count,
            "tasks": tasks,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.task_response import TaskResponse
        d = dict(src_dict)
        count = d.pop("count")

        tasks = []
        _tasks = d.pop("tasks")
        for tasks_item_data in (_tasks):
            tasks_item = TaskResponse.from_dict(tasks_item_data)



            tasks.append(tasks_item)


        search_tasks_response = cls(
            count=count,
            tasks=tasks,
        )


        search_tasks_response.additional_properties = d
        return search_tasks_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
