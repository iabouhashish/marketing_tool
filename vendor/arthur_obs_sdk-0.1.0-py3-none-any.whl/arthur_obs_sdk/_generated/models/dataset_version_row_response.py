from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.dataset_version_row_column_item_response import DatasetVersionRowColumnItemResponse





T = TypeVar("T", bound="DatasetVersionRowResponse")



@_attrs_define
class DatasetVersionRowResponse:
    """ 
        Attributes:
            id (UUID): ID of the version field.
            data (list[DatasetVersionRowColumnItemResponse]): List of column names and values in the row.
            created_at (int): Timestamp representing the time of dataset row creation in unix milliseconds. May differ
                within a version if a row already existed in a past version of the dataset.
     """

    id: UUID
    data: list[DatasetVersionRowColumnItemResponse]
    created_at: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.dataset_version_row_column_item_response import DatasetVersionRowColumnItemResponse
        id = str(self.id)

        data = []
        for data_item_data in self.data:
            data_item = data_item_data.to_dict()
            data.append(data_item)



        created_at = self.created_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "data": data,
            "created_at": created_at,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dataset_version_row_column_item_response import DatasetVersionRowColumnItemResponse
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        data = []
        _data = d.pop("data")
        for data_item_data in (_data):
            data_item = DatasetVersionRowColumnItemResponse.from_dict(data_item_data)



            data.append(data_item)


        created_at = d.pop("created_at")

        dataset_version_row_response = cls(
            id=id,
            data=data,
            created_at=created_at,
        )


        dataset_version_row_response.additional_properties = d
        return dataset_version_row_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
