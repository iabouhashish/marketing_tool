from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.eval_result_summary import EvalResultSummary





T = TypeVar("T", bound="RagEvalResultSummaries")



@_attrs_define
class RagEvalResultSummaries:
    """ Summary of evaluation results for a RAG configuration

        Attributes:
            eval_results (list[EvalResultSummary]): Results for each evaluation run on this RAG configuration
            rag_config_key (None | str | Unset): RAG config key: 'saved:setting_config_id:version' for saved, 'unsaved:uuid'
                for unsaved
            rag_config_type (None | str | Unset): Type: 'saved' or 'unsaved'
            setting_configuration_id (None | Unset | UUID): ID of the RAG search setting configuration (for saved configs
                only)
            setting_configuration_version (int | None | Unset): Version of the RAG search setting configuration (for saved
                configs only)
     """

    eval_results: list[EvalResultSummary]
    rag_config_key: None | str | Unset = UNSET
    rag_config_type: None | str | Unset = UNSET
    setting_configuration_id: None | Unset | UUID = UNSET
    setting_configuration_version: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.eval_result_summary import EvalResultSummary
        eval_results = []
        for eval_results_item_data in self.eval_results:
            eval_results_item = eval_results_item_data.to_dict()
            eval_results.append(eval_results_item)



        rag_config_key: None | str | Unset
        if isinstance(self.rag_config_key, Unset):
            rag_config_key = UNSET
        else:
            rag_config_key = self.rag_config_key

        rag_config_type: None | str | Unset
        if isinstance(self.rag_config_type, Unset):
            rag_config_type = UNSET
        else:
            rag_config_type = self.rag_config_type

        setting_configuration_id: None | str | Unset
        if isinstance(self.setting_configuration_id, Unset):
            setting_configuration_id = UNSET
        elif isinstance(self.setting_configuration_id, UUID):
            setting_configuration_id = str(self.setting_configuration_id)
        else:
            setting_configuration_id = self.setting_configuration_id

        setting_configuration_version: int | None | Unset
        if isinstance(self.setting_configuration_version, Unset):
            setting_configuration_version = UNSET
        else:
            setting_configuration_version = self.setting_configuration_version


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "eval_results": eval_results,
        })
        if rag_config_key is not UNSET:
            field_dict["rag_config_key"] = rag_config_key
        if rag_config_type is not UNSET:
            field_dict["rag_config_type"] = rag_config_type
        if setting_configuration_id is not UNSET:
            field_dict["setting_configuration_id"] = setting_configuration_id
        if setting_configuration_version is not UNSET:
            field_dict["setting_configuration_version"] = setting_configuration_version

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.eval_result_summary import EvalResultSummary
        d = dict(src_dict)
        eval_results = []
        _eval_results = d.pop("eval_results")
        for eval_results_item_data in (_eval_results):
            eval_results_item = EvalResultSummary.from_dict(eval_results_item_data)



            eval_results.append(eval_results_item)


        def _parse_rag_config_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        rag_config_key = _parse_rag_config_key(d.pop("rag_config_key", UNSET))


        def _parse_rag_config_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        rag_config_type = _parse_rag_config_type(d.pop("rag_config_type", UNSET))


        def _parse_setting_configuration_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                setting_configuration_id_type_0 = UUID(data)



                return setting_configuration_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        setting_configuration_id = _parse_setting_configuration_id(d.pop("setting_configuration_id", UNSET))


        def _parse_setting_configuration_version(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        setting_configuration_version = _parse_setting_configuration_version(d.pop("setting_configuration_version", UNSET))


        rag_eval_result_summaries = cls(
            eval_results=eval_results,
            rag_config_key=rag_config_key,
            rag_config_type=rag_config_type,
            setting_configuration_id=setting_configuration_id,
            setting_configuration_version=setting_configuration_version,
        )


        rag_eval_result_summaries.additional_properties = d
        return rag_eval_result_summaries

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
