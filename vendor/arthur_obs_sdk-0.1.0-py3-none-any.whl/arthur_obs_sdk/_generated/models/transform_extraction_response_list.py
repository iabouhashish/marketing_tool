from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.variable_template_value import VariableTemplateValue





T = TypeVar("T", bound="TransformExtractionResponseList")



@_attrs_define
class TransformExtractionResponseList:
    """ 
        Attributes:
            variables (list[VariableTemplateValue]): List of extracted variables.
     """

    variables: list[VariableTemplateValue]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.variable_template_value import VariableTemplateValue
        variables = []
        for variables_item_data in self.variables:
            variables_item = variables_item_data.to_dict()
            variables.append(variables_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "variables": variables,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.variable_template_value import VariableTemplateValue
        d = dict(src_dict)
        variables = []
        _variables = d.pop("variables")
        for variables_item_data in (_variables):
            variables_item = VariableTemplateValue.from_dict(variables_item_data)



            variables.append(variables_item)


        transform_extraction_response_list = cls(
            variables=variables,
        )


        transform_extraction_response_list.additional_properties = d
        return transform_extraction_response_list

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
