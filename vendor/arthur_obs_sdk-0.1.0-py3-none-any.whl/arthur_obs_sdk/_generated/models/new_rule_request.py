from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.pii_config import PIIConfig
  from ..models.keywords_config import KeywordsConfig
  from ..models.toxicity_config import ToxicityConfig
  from ..models.examples_config import ExamplesConfig
  from ..models.regex_config import RegexConfig





T = TypeVar("T", bound="NewRuleRequest")



@_attrs_define
class NewRuleRequest:
    """ 
        Attributes:
            name (str): Name of the rule
            type_ (str): Type of the rule. It can only be one of KeywordRule, RegexRule, ModelSensitiveDataRule,
                ModelHallucinationRule, ModelHallucinationRuleV2, PromptInjectionRule, PIIDataRule
            apply_to_prompt (bool): Boolean value to enable or disable the rule for llm prompt
            apply_to_response (bool): Boolean value to enable or disable the rule for llm response
            config (ExamplesConfig | KeywordsConfig | None | PIIConfig | RegexConfig | ToxicityConfig | Unset): Config of
                the rule
     """

    name: str
    type_: str
    apply_to_prompt: bool
    apply_to_response: bool
    config: ExamplesConfig | KeywordsConfig | None | PIIConfig | RegexConfig | ToxicityConfig | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.pii_config import PIIConfig
        from ..models.keywords_config import KeywordsConfig
        from ..models.toxicity_config import ToxicityConfig
        from ..models.examples_config import ExamplesConfig
        from ..models.regex_config import RegexConfig
        name = self.name

        type_ = self.type_

        apply_to_prompt = self.apply_to_prompt

        apply_to_response = self.apply_to_response

        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, KeywordsConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, RegexConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, ExamplesConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, ToxicityConfig):
            config = self.config.to_dict()
        elif isinstance(self.config, PIIConfig):
            config = self.config.to_dict()
        else:
            config = self.config


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "type": type_,
            "apply_to_prompt": apply_to_prompt,
            "apply_to_response": apply_to_response,
        })
        if config is not UNSET:
            field_dict["config"] = config

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.pii_config import PIIConfig
        from ..models.keywords_config import KeywordsConfig
        from ..models.toxicity_config import ToxicityConfig
        from ..models.examples_config import ExamplesConfig
        from ..models.regex_config import RegexConfig
        d = dict(src_dict)
        name = d.pop("name")

        type_ = d.pop("type")

        apply_to_prompt = d.pop("apply_to_prompt")

        apply_to_response = d.pop("apply_to_response")

        def _parse_config(data: object) -> ExamplesConfig | KeywordsConfig | None | PIIConfig | RegexConfig | ToxicityConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0 = KeywordsConfig.from_dict(data)



                return config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_1 = RegexConfig.from_dict(data)



                return config_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_2 = ExamplesConfig.from_dict(data)



                return config_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_3 = ToxicityConfig.from_dict(data)



                return config_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_4 = PIIConfig.from_dict(data)



                return config_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ExamplesConfig | KeywordsConfig | None | PIIConfig | RegexConfig | ToxicityConfig | Unset, data)

        config = _parse_config(d.pop("config", UNSET))


        new_rule_request = cls(
            name=name,
            type_=type_,
            apply_to_prompt=apply_to_prompt,
            apply_to_response=apply_to_response,
            config=config,
        )


        new_rule_request.additional_properties = d
        return new_rule_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
