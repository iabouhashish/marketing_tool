from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.dataset_column_source import DatasetColumnSource





T = TypeVar("T", bound="DatasetColumnVariableSource")



@_attrs_define
class DatasetColumnVariableSource:
    """ Variable source from a dataset column

        Attributes:
            type_ (Literal['dataset_column']): Type of source: 'dataset_column'
            dataset_column (DatasetColumnSource): Reference to a dataset column
     """

    type_: Literal['dataset_column']
    dataset_column: DatasetColumnSource
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.dataset_column_source import DatasetColumnSource
        type_ = self.type_

        dataset_column = self.dataset_column.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "type": type_,
            "dataset_column": dataset_column,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dataset_column_source import DatasetColumnSource
        d = dict(src_dict)
        type_ = cast(Literal['dataset_column'] , d.pop("type"))
        if type_ != 'dataset_column':
            raise ValueError(f"type must match const 'dataset_column', got '{type_}'")

        dataset_column = DatasetColumnSource.from_dict(d.pop("dataset_column"))




        dataset_column_variable_source = cls(
            type_=type_,
            dataset_column=dataset_column,
        )


        dataset_column_variable_source.additional_properties = d
        return dataset_column_variable_source

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
