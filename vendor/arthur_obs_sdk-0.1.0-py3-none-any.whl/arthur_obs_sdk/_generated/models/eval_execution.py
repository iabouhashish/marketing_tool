from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.eval_execution_result import EvalExecutionResult
  from ..models.input_variable import InputVariable





T = TypeVar("T", bound="EvalExecution")



@_attrs_define
class EvalExecution:
    """ Details of an eval execution

        Attributes:
            eval_name (str): Name of the evaluation
            eval_version (str): Version of the evaluation
            eval_input_variables (list[InputVariable]): Input variables used for the eval
            eval_results (EvalExecutionResult | None | Unset): Results from the eval (None if not yet executed)
     """

    eval_name: str
    eval_version: str
    eval_input_variables: list[InputVariable]
    eval_results: EvalExecutionResult | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.eval_execution_result import EvalExecutionResult
        from ..models.input_variable import InputVariable
        eval_name = self.eval_name

        eval_version = self.eval_version

        eval_input_variables = []
        for eval_input_variables_item_data in self.eval_input_variables:
            eval_input_variables_item = eval_input_variables_item_data.to_dict()
            eval_input_variables.append(eval_input_variables_item)



        eval_results: dict[str, Any] | None | Unset
        if isinstance(self.eval_results, Unset):
            eval_results = UNSET
        elif isinstance(self.eval_results, EvalExecutionResult):
            eval_results = self.eval_results.to_dict()
        else:
            eval_results = self.eval_results


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "eval_name": eval_name,
            "eval_version": eval_version,
            "eval_input_variables": eval_input_variables,
        })
        if eval_results is not UNSET:
            field_dict["eval_results"] = eval_results

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.eval_execution_result import EvalExecutionResult
        from ..models.input_variable import InputVariable
        d = dict(src_dict)
        eval_name = d.pop("eval_name")

        eval_version = d.pop("eval_version")

        eval_input_variables = []
        _eval_input_variables = d.pop("eval_input_variables")
        for eval_input_variables_item_data in (_eval_input_variables):
            eval_input_variables_item = InputVariable.from_dict(eval_input_variables_item_data)



            eval_input_variables.append(eval_input_variables_item)


        def _parse_eval_results(data: object) -> EvalExecutionResult | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                eval_results_type_0 = EvalExecutionResult.from_dict(data)



                return eval_results_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(EvalExecutionResult | None | Unset, data)

        eval_results = _parse_eval_results(d.pop("eval_results", UNSET))


        eval_execution = cls(
            eval_name=eval_name,
            eval_version=eval_version,
            eval_input_variables=eval_input_variables,
            eval_results=eval_results,
        )


        eval_execution.additional_properties = d
        return eval_execution

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
