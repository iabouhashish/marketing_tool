from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.metric_type import MetricType
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="MetricResponse")



@_attrs_define
class MetricResponse:
    """ 
        Attributes:
            id (str): ID of the Metric
            name (str): Name of the Metric
            type_ (MetricType):
            metric_metadata (str): Metadata of the Metric
            created_at (datetime.datetime): Time the Metric was created in unix milliseconds
            updated_at (datetime.datetime): Time the Metric was updated in unix milliseconds
            config (None | str | Unset): JSON-serialized configuration for the Metric
            enabled (bool | None | Unset): Whether the Metric is enabled
     """

    id: str
    name: str
    type_: MetricType
    metric_metadata: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    config: None | str | Unset = UNSET
    enabled: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        name = self.name

        type_ = self.type_.value

        metric_metadata = self.metric_metadata

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        config: None | str | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        else:
            config = self.config

        enabled: bool | None | Unset
        if isinstance(self.enabled, Unset):
            enabled = UNSET
        else:
            enabled = self.enabled


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "type": type_,
            "metric_metadata": metric_metadata,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if config is not UNSET:
            field_dict["config"] = config
        if enabled is not UNSET:
            field_dict["enabled"] = enabled

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        type_ = MetricType(d.pop("type"))




        metric_metadata = d.pop("metric_metadata")

        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        def _parse_config(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        config = _parse_config(d.pop("config", UNSET))


        def _parse_enabled(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        enabled = _parse_enabled(d.pop("enabled", UNSET))


        metric_response = cls(
            id=id,
            name=name,
            type_=type_,
            metric_metadata=metric_metadata,
            created_at=created_at,
            updated_at=updated_at,
            config=config,
            enabled=enabled,
        )


        metric_response.additional_properties = d
        return metric_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
