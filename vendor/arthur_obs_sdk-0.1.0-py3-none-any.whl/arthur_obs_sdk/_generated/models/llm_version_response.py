from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.model_provider import ModelProvider
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="LLMVersionResponse")



@_attrs_define
class LLMVersionResponse:
    """ 
        Attributes:
            version (int): Version number of the llm eval
            created_at (datetime.datetime): Timestamp when the llm eval version was created
            deleted_at (datetime.datetime | None): Timestamp when the llm eval version was deleted (None if not deleted)
            model_provider (ModelProvider):
            model_name (str): Model name chosen for this version of the llm eval
            tags (list[str] | Unset): List of tags for the llm asset
     """

    version: int
    created_at: datetime.datetime
    deleted_at: datetime.datetime | None
    model_provider: ModelProvider
    model_name: str
    tags: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        version = self.version

        created_at = self.created_at.isoformat()

        deleted_at: None | str
        if isinstance(self.deleted_at, datetime.datetime):
            deleted_at = self.deleted_at.isoformat()
        else:
            deleted_at = self.deleted_at

        model_provider = self.model_provider.value

        model_name = self.model_name

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "version": version,
            "created_at": created_at,
            "deleted_at": deleted_at,
            "model_provider": model_provider,
            "model_name": model_name,
        })
        if tags is not UNSET:
            field_dict["tags"] = tags

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        version = d.pop("version")

        created_at = isoparse(d.pop("created_at"))




        def _parse_deleted_at(data: object) -> datetime.datetime | None:
            if data is None:
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                deleted_at_type_0 = isoparse(data)



                return deleted_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None, data)

        deleted_at = _parse_deleted_at(d.pop("deleted_at"))


        model_provider = ModelProvider(d.pop("model_provider"))




        model_name = d.pop("model_name")

        tags = cast(list[str], d.pop("tags", UNSET))


        llm_version_response = cls(
            version=version,
            created_at=created_at,
            deleted_at=deleted_at,
            model_provider=model_provider,
            model_name=model_name,
            tags=tags,
        )


        llm_version_response.additional_properties = d
        return llm_version_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
