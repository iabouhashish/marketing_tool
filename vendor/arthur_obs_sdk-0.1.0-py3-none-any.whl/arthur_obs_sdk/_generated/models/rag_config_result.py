from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.test_case_status import TestCaseStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.eval_execution import EvalExecution
  from ..models.rag_search_output import RagSearchOutput





T = TypeVar("T", bound="RagConfigResult")



@_attrs_define
class RagConfigResult:
    """ Result for a specific RAG configuration within a test case

        Attributes:
            status (TestCaseStatus): Status of a test case
            dataset_row_id (str): ID of the dataset row
            evals (list[EvalExecution]): Evaluation results for this specific config
            query_text (str): Query text used for the search
            total_cost (None | str | Unset): Total cost for this config test case execution
            output (None | RagSearchOutput | Unset): Output from the RAG search (None if not yet executed)
     """

    status: TestCaseStatus
    dataset_row_id: str
    evals: list[EvalExecution]
    query_text: str
    total_cost: None | str | Unset = UNSET
    output: None | RagSearchOutput | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.eval_execution import EvalExecution
        from ..models.rag_search_output import RagSearchOutput
        status = self.status.value

        dataset_row_id = self.dataset_row_id

        evals = []
        for evals_item_data in self.evals:
            evals_item = evals_item_data.to_dict()
            evals.append(evals_item)



        query_text = self.query_text

        total_cost: None | str | Unset
        if isinstance(self.total_cost, Unset):
            total_cost = UNSET
        else:
            total_cost = self.total_cost

        output: dict[str, Any] | None | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        elif isinstance(self.output, RagSearchOutput):
            output = self.output.to_dict()
        else:
            output = self.output


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
            "dataset_row_id": dataset_row_id,
            "evals": evals,
            "query_text": query_text,
        })
        if total_cost is not UNSET:
            field_dict["total_cost"] = total_cost
        if output is not UNSET:
            field_dict["output"] = output

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.eval_execution import EvalExecution
        from ..models.rag_search_output import RagSearchOutput
        d = dict(src_dict)
        status = TestCaseStatus(d.pop("status"))




        dataset_row_id = d.pop("dataset_row_id")

        evals = []
        _evals = d.pop("evals")
        for evals_item_data in (_evals):
            evals_item = EvalExecution.from_dict(evals_item_data)



            evals.append(evals_item)


        query_text = d.pop("query_text")

        def _parse_total_cost(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        total_cost = _parse_total_cost(d.pop("total_cost", UNSET))


        def _parse_output(data: object) -> None | RagSearchOutput | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                output_type_0 = RagSearchOutput.from_dict(data)



                return output_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RagSearchOutput | Unset, data)

        output = _parse_output(d.pop("output", UNSET))


        rag_config_result = cls(
            status=status,
            dataset_row_id=dataset_row_id,
            evals=evals,
            query_text=query_text,
            total_cost=total_cost,
            output=output,
        )


        rag_config_result.additional_properties = d
        return rag_config_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
