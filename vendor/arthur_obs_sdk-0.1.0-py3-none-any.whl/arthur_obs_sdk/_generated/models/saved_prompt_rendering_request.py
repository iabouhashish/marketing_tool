from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.variable_rendering_request import VariableRenderingRequest





T = TypeVar("T", bound="SavedPromptRenderingRequest")



@_attrs_define
class SavedPromptRenderingRequest:
    """ Request schema for rendering an unsaved agentic prompt with variables

        Attributes:
            completion_request (VariableRenderingRequest | Unset):
     """

    completion_request: VariableRenderingRequest | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.variable_rendering_request import VariableRenderingRequest
        completion_request: dict[str, Any] | Unset = UNSET
        if not isinstance(self.completion_request, Unset):
            completion_request = self.completion_request.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if completion_request is not UNSET:
            field_dict["completion_request"] = completion_request

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.variable_rendering_request import VariableRenderingRequest
        d = dict(src_dict)
        _completion_request = d.pop("completion_request", UNSET)
        completion_request: VariableRenderingRequest | Unset
        if isinstance(_completion_request,  Unset):
            completion_request = UNSET
        else:
            completion_request = VariableRenderingRequest.from_dict(_completion_request)




        saved_prompt_rendering_request = cls(
            completion_request=completion_request,
        )


        saved_prompt_rendering_request.additional_properties = d
        return saved_prompt_rendering_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
