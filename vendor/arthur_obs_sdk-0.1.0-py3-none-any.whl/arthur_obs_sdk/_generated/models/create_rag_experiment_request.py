from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
  from ..models.unsaved_rag_config import UnsavedRagConfig
  from ..models.saved_rag_config import SavedRagConfig
  from ..models.eval_ref import EvalRef
  from ..models.dataset_ref_input import DatasetRefInput





T = TypeVar("T", bound="CreateRagExperimentRequest")



@_attrs_define
class CreateRagExperimentRequest:
    """ Request to create a new RAG experiment

        Attributes:
            name (str): Name for the experiment
            dataset_ref (DatasetRefInput): Reference to a dataset and version for input (without name)
            eval_list (list[EvalRef]): List of evaluations to run
            rag_configs (list[SavedRagConfig | UnsavedRagConfig]): List of RAG configurations to test. Each config specifies
                which dataset column to use as the query.
            description (None | str | Unset): Description of the experiment
            dataset_row_filter (list[NewDatasetVersionRowColumnItemRequest] | None | Unset): Optional list of column name
                and value filters. Only rows matching ALL specified column name-value pairs (AND condition) will be included in
                the experiment. If not specified, all rows from the dataset will be used.
     """

    name: str
    dataset_ref: DatasetRefInput
    eval_list: list[EvalRef]
    rag_configs: list[SavedRagConfig | UnsavedRagConfig]
    description: None | str | Unset = UNSET
    dataset_row_filter: list[NewDatasetVersionRowColumnItemRequest] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        from ..models.unsaved_rag_config import UnsavedRagConfig
        from ..models.saved_rag_config import SavedRagConfig
        from ..models.eval_ref import EvalRef
        from ..models.dataset_ref_input import DatasetRefInput
        name = self.name

        dataset_ref = self.dataset_ref.to_dict()

        eval_list = []
        for eval_list_item_data in self.eval_list:
            eval_list_item = eval_list_item_data.to_dict()
            eval_list.append(eval_list_item)



        rag_configs = []
        for rag_configs_item_data in self.rag_configs:
            rag_configs_item: dict[str, Any]
            if isinstance(rag_configs_item_data, SavedRagConfig):
                rag_configs_item = rag_configs_item_data.to_dict()
            else:
                rag_configs_item = rag_configs_item_data.to_dict()

            rag_configs.append(rag_configs_item)



        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        dataset_row_filter: list[dict[str, Any]] | None | Unset
        if isinstance(self.dataset_row_filter, Unset):
            dataset_row_filter = UNSET
        elif isinstance(self.dataset_row_filter, list):
            dataset_row_filter = []
            for dataset_row_filter_type_0_item_data in self.dataset_row_filter:
                dataset_row_filter_type_0_item = dataset_row_filter_type_0_item_data.to_dict()
                dataset_row_filter.append(dataset_row_filter_type_0_item)


        else:
            dataset_row_filter = self.dataset_row_filter


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "dataset_ref": dataset_ref,
            "eval_list": eval_list,
            "rag_configs": rag_configs,
        })
        if description is not UNSET:
            field_dict["description"] = description
        if dataset_row_filter is not UNSET:
            field_dict["dataset_row_filter"] = dataset_row_filter

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        from ..models.unsaved_rag_config import UnsavedRagConfig
        from ..models.saved_rag_config import SavedRagConfig
        from ..models.eval_ref import EvalRef
        from ..models.dataset_ref_input import DatasetRefInput
        d = dict(src_dict)
        name = d.pop("name")

        dataset_ref = DatasetRefInput.from_dict(d.pop("dataset_ref"))




        eval_list = []
        _eval_list = d.pop("eval_list")
        for eval_list_item_data in (_eval_list):
            eval_list_item = EvalRef.from_dict(eval_list_item_data)



            eval_list.append(eval_list_item)


        rag_configs = []
        _rag_configs = d.pop("rag_configs")
        for rag_configs_item_data in (_rag_configs):
            def _parse_rag_configs_item(data: object) -> SavedRagConfig | UnsavedRagConfig:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    rag_configs_item_type_0 = SavedRagConfig.from_dict(data)



                    return rag_configs_item_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                rag_configs_item_type_1 = UnsavedRagConfig.from_dict(data)



                return rag_configs_item_type_1

            rag_configs_item = _parse_rag_configs_item(rag_configs_item_data)

            rag_configs.append(rag_configs_item)


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_dataset_row_filter(data: object) -> list[NewDatasetVersionRowColumnItemRequest] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                dataset_row_filter_type_0 = []
                _dataset_row_filter_type_0 = data
                for dataset_row_filter_type_0_item_data in (_dataset_row_filter_type_0):
                    dataset_row_filter_type_0_item = NewDatasetVersionRowColumnItemRequest.from_dict(dataset_row_filter_type_0_item_data)



                    dataset_row_filter_type_0.append(dataset_row_filter_type_0_item)

                return dataset_row_filter_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[NewDatasetVersionRowColumnItemRequest] | None | Unset, data)

        dataset_row_filter = _parse_dataset_row_filter(d.pop("dataset_row_filter", UNSET))


        create_rag_experiment_request = cls(
            name=name,
            dataset_ref=dataset_ref,
            eval_list=eval_list,
            rag_configs=rag_configs,
            description=description,
            dataset_row_filter=dataset_row_filter,
        )


        create_rag_experiment_request.additional_properties = d
        return create_rag_experiment_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
