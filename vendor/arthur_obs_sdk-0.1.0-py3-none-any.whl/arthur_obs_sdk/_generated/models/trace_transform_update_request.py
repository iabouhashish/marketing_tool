from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.trace_transform_definition import TraceTransformDefinition





T = TypeVar("T", bound="TraceTransformUpdateRequest")



@_attrs_define
class TraceTransformUpdateRequest:
    """ 
        Attributes:
            name (None | str | Unset): Name of the transform.
            description (None | str | Unset): Description of the transform.
            definition (None | TraceTransformDefinition | Unset): Transform definition specifying extraction rules.
     """

    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    definition: None | TraceTransformDefinition | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.trace_transform_definition import TraceTransformDefinition
        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        definition: dict[str, Any] | None | Unset
        if isinstance(self.definition, Unset):
            definition = UNSET
        elif isinstance(self.definition, TraceTransformDefinition):
            definition = self.definition.to_dict()
        else:
            definition = self.definition


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if definition is not UNSET:
            field_dict["definition"] = definition

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.trace_transform_definition import TraceTransformDefinition
        d = dict(src_dict)
        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_definition(data: object) -> None | TraceTransformDefinition | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                definition_type_0 = TraceTransformDefinition.from_dict(data)



                return definition_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | TraceTransformDefinition | Unset, data)

        definition = _parse_definition(d.pop("definition", UNSET))


        trace_transform_update_request = cls(
            name=name,
            description=description,
            definition=definition,
        )


        trace_transform_update_request.additional_properties = d
        return trace_transform_update_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
