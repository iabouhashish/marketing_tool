from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.span_with_metrics_response import SpanWithMetricsResponse





T = TypeVar("T", bound="QuerySpansResponse")



@_attrs_define
class QuerySpansResponse:
    """ 
        Attributes:
            count (int): The total number of spans matching the query parameters
            spans (list[SpanWithMetricsResponse]): List of spans with metrics matching the search filters
     """

    count: int
    spans: list[SpanWithMetricsResponse]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.span_with_metrics_response import SpanWithMetricsResponse
        count = self.count

        spans = []
        for spans_item_data in self.spans:
            spans_item = spans_item_data.to_dict()
            spans.append(spans_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "count": count,
            "spans": spans,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.span_with_metrics_response import SpanWithMetricsResponse
        d = dict(src_dict)
        count = d.pop("count")

        spans = []
        _spans = d.pop("spans")
        for spans_item_data in (_spans):
            spans_item = SpanWithMetricsResponse.from_dict(spans_item_data)



            spans.append(spans_item)


        query_spans_response = cls(
            count=count,
            spans=spans,
        )


        query_spans_response.additional_properties = d
        return query_spans_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
