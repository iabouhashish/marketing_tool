from enum import Enum

class ConnectionCheckOutcome(str, Enum):
    FAILED = "failed"
    PASSED = "passed"

    def __str__(self) -> str:
        return str(self.value)
