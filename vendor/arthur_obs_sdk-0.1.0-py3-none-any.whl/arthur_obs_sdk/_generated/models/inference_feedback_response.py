from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.inference_feedback_target import InferenceFeedbackTarget
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="InferenceFeedbackResponse")



@_attrs_define
class InferenceFeedbackResponse:
    """ 
        Attributes:
            id (str):
            inference_id (str):
            target (InferenceFeedbackTarget):
            score (int):
            created_at (datetime.datetime):
            updated_at (datetime.datetime):
            reason (None | str | Unset):
            user_id (None | str | Unset):
     """

    id: str
    inference_id: str
    target: InferenceFeedbackTarget
    score: int
    created_at: datetime.datetime
    updated_at: datetime.datetime
    reason: None | str | Unset = UNSET
    user_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = self.id

        inference_id = self.inference_id

        target = self.target.value

        score = self.score

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        reason: None | str | Unset
        if isinstance(self.reason, Unset):
            reason = UNSET
        else:
            reason = self.reason

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "inference_id": inference_id,
            "target": target,
            "score": score,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if reason is not UNSET:
            field_dict["reason"] = reason
        if user_id is not UNSET:
            field_dict["user_id"] = user_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = d.pop("id")

        inference_id = d.pop("inference_id")

        target = InferenceFeedbackTarget(d.pop("target"))




        score = d.pop("score")

        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        def _parse_reason(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        reason = _parse_reason(d.pop("reason", UNSET))


        def _parse_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_id = _parse_user_id(d.pop("user_id", UNSET))


        inference_feedback_response = cls(
            id=id,
            inference_id=inference_id,
            target=target,
            score=score,
            created_at=created_at,
            updated_at=updated_at,
            reason=reason,
            user_id=user_id,
        )


        inference_feedback_response.additional_properties = d
        return inference_feedback_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
