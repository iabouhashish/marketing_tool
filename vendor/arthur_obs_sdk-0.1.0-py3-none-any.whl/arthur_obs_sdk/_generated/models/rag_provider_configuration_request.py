from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.api_key_rag_authentication_config_request import ApiKeyRagAuthenticationConfigRequest





T = TypeVar("T", bound="RagProviderConfigurationRequest")



@_attrs_define
class RagProviderConfigurationRequest:
    """ 
        Attributes:
            authentication_config (ApiKeyRagAuthenticationConfigRequest):
            name (str): Name of RAG provider configuration.
            description (None | str | Unset): Description of RAG provider configuration.
     """

    authentication_config: ApiKeyRagAuthenticationConfigRequest
    name: str
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.api_key_rag_authentication_config_request import ApiKeyRagAuthenticationConfigRequest
        authentication_config = self.authentication_config.to_dict()

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "authentication_config": authentication_config,
            "name": name,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key_rag_authentication_config_request import ApiKeyRagAuthenticationConfigRequest
        d = dict(src_dict)
        authentication_config = ApiKeyRagAuthenticationConfigRequest.from_dict(d.pop("authentication_config"))




        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        rag_provider_configuration_request = cls(
            authentication_config=authentication_config,
            name=name,
            description=description,
        )


        rag_provider_configuration_request.additional_properties = d
        return rag_provider_configuration_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
