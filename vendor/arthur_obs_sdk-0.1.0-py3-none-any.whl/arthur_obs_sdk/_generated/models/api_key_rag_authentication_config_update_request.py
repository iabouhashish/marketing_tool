from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.rag_api_key_authentication_provider_enum import RagAPIKeyAuthenticationProviderEnum
from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast






T = TypeVar("T", bound="ApiKeyRagAuthenticationConfigUpdateRequest")



@_attrs_define
class ApiKeyRagAuthenticationConfigUpdateRequest:
    """ 
        Attributes:
            authentication_method (Literal['api_key'] | Unset):  Default: 'api_key'.
            api_key (None | str | Unset): API key to use for authentication.
            host_url (None | str | Unset): URL of host instance to authenticate with.
            rag_provider (None | RagAPIKeyAuthenticationProviderEnum | Unset): Name of RAG provider to authenticate with.
     """

    authentication_method: Literal['api_key'] | Unset = 'api_key'
    api_key: None | str | Unset = UNSET
    host_url: None | str | Unset = UNSET
    rag_provider: None | RagAPIKeyAuthenticationProviderEnum | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        authentication_method = self.authentication_method

        api_key: None | str | Unset
        if isinstance(self.api_key, Unset):
            api_key = UNSET
        else:
            api_key = self.api_key

        host_url: None | str | Unset
        if isinstance(self.host_url, Unset):
            host_url = UNSET
        else:
            host_url = self.host_url

        rag_provider: None | str | Unset
        if isinstance(self.rag_provider, Unset):
            rag_provider = UNSET
        elif isinstance(self.rag_provider, RagAPIKeyAuthenticationProviderEnum):
            rag_provider = self.rag_provider.value
        else:
            rag_provider = self.rag_provider


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if authentication_method is not UNSET:
            field_dict["authentication_method"] = authentication_method
        if api_key is not UNSET:
            field_dict["api_key"] = api_key
        if host_url is not UNSET:
            field_dict["host_url"] = host_url
        if rag_provider is not UNSET:
            field_dict["rag_provider"] = rag_provider

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        authentication_method = cast(Literal['api_key'] | Unset , d.pop("authentication_method", UNSET))
        if authentication_method != 'api_key'and not isinstance(authentication_method, Unset):
            raise ValueError(f"authentication_method must match const 'api_key', got '{authentication_method}'")

        def _parse_api_key(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        api_key = _parse_api_key(d.pop("api_key", UNSET))


        def _parse_host_url(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        host_url = _parse_host_url(d.pop("host_url", UNSET))


        def _parse_rag_provider(data: object) -> None | RagAPIKeyAuthenticationProviderEnum | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                rag_provider_type_0 = RagAPIKeyAuthenticationProviderEnum(data)



                return rag_provider_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RagAPIKeyAuthenticationProviderEnum | Unset, data)

        rag_provider = _parse_rag_provider(d.pop("rag_provider", UNSET))


        api_key_rag_authentication_config_update_request = cls(
            authentication_method=authentication_method,
            api_key=api_key,
            host_url=host_url,
            rag_provider=rag_provider,
        )


        api_key_rag_authentication_config_update_request.additional_properties = d
        return api_key_rag_authentication_config_update_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
