from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="LLMGetAllMetadataResponse")



@_attrs_define
class LLMGetAllMetadataResponse:
    """ 
        Attributes:
            name (str): Name of the llm asset
            versions (int): Number of versions of the llm asset
            created_at (datetime.datetime): Timestamp when the llm asset was created
            latest_version_created_at (datetime.datetime): Timestamp when the last version of the llm asset was created
            deleted_versions (list[int]): List of deleted versions of the llm asset
            tags (list[str] | Unset): List of tags for the llm asset
     """

    name: str
    versions: int
    created_at: datetime.datetime
    latest_version_created_at: datetime.datetime
    deleted_versions: list[int]
    tags: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        versions = self.versions

        created_at = self.created_at.isoformat()

        latest_version_created_at = self.latest_version_created_at.isoformat()

        deleted_versions = self.deleted_versions



        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "versions": versions,
            "created_at": created_at,
            "latest_version_created_at": latest_version_created_at,
            "deleted_versions": deleted_versions,
        })
        if tags is not UNSET:
            field_dict["tags"] = tags

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        versions = d.pop("versions")

        created_at = isoparse(d.pop("created_at"))




        latest_version_created_at = isoparse(d.pop("latest_version_created_at"))




        deleted_versions = cast(list[int], d.pop("deleted_versions"))


        tags = cast(list[str], d.pop("tags", UNSET))


        llm_get_all_metadata_response = cls(
            name=name,
            versions=versions,
            created_at=created_at,
            latest_version_created_at=latest_version_created_at,
            deleted_versions=deleted_versions,
            tags=tags,
        )


        llm_get_all_metadata_response.additional_properties = d
        return llm_get_all_metadata_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
