from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.trace_metadata_response import TraceMetadataResponse





T = TypeVar("T", bound="TraceListResponse")



@_attrs_define
class TraceListResponse:
    """ Response for trace list endpoint

        Attributes:
            count (int): Total number of traces matching filters
            traces (list[TraceMetadataResponse]): List of trace metadata
     """

    count: int
    traces: list[TraceMetadataResponse]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.trace_metadata_response import TraceMetadataResponse
        count = self.count

        traces = []
        for traces_item_data in self.traces:
            traces_item = traces_item_data.to_dict()
            traces.append(traces_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "count": count,
            "traces": traces,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.trace_metadata_response import TraceMetadataResponse
        d = dict(src_dict)
        count = d.pop("count")

        traces = []
        _traces = d.pop("traces")
        for traces_item_data in (_traces):
            traces_item = TraceMetadataResponse.from_dict(traces_item_data)



            traces.append(traces_item)


        trace_list_response = cls(
            count=count,
            traces=traces,
        )


        trace_list_response.additional_properties = d
        return trace_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
