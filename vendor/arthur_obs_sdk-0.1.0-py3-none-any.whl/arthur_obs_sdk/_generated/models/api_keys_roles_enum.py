from enum import Enum

class APIKeysRolesEnum(str, Enum):
    DEFAULT_RULE_ADMIN = "DEFAULT-RULE-ADMIN"
    ORG_ADMIN = "ORG-ADMIN"
    ORG_AUDITOR = "ORG-AUDITOR"
    TASK_ADMIN = "TASK-ADMIN"
    VALIDATION_USER = "VALIDATION-USER"

    def __str__(self) -> str:
        return str(self.value)
