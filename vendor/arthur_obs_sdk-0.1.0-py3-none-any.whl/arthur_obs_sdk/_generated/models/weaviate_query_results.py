from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.weaviate_query_result import WeaviateQueryResult





T = TypeVar("T", bound="WeaviateQueryResults")



@_attrs_define
class WeaviateQueryResults:
    """ Response from Weaviate similarity text search

        Attributes:
            objects (list[WeaviateQueryResult]): List of search result objects
            rag_provider (Literal['weaviate'] | Unset):  Default: 'weaviate'.
     """

    objects: list[WeaviateQueryResult]
    rag_provider: Literal['weaviate'] | Unset = 'weaviate'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.weaviate_query_result import WeaviateQueryResult
        objects = []
        for objects_item_data in self.objects:
            objects_item = objects_item_data.to_dict()
            objects.append(objects_item)



        rag_provider = self.rag_provider


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "objects": objects,
        })
        if rag_provider is not UNSET:
            field_dict["rag_provider"] = rag_provider

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.weaviate_query_result import WeaviateQueryResult
        d = dict(src_dict)
        objects = []
        _objects = d.pop("objects")
        for objects_item_data in (_objects):
            objects_item = WeaviateQueryResult.from_dict(objects_item_data)



            objects.append(objects_item)


        rag_provider = cast(Literal['weaviate'] | Unset , d.pop("rag_provider", UNSET))
        if rag_provider != 'weaviate'and not isinstance(rag_provider, Unset):
            raise ValueError(f"rag_provider must match const 'weaviate', got '{rag_provider}'")

        weaviate_query_results = cls(
            objects=objects,
            rag_provider=rag_provider,
        )


        weaviate_query_results.additional_properties = d
        return weaviate_query_results

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
