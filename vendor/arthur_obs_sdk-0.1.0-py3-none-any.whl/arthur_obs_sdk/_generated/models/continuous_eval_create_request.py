from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID






T = TypeVar("T", bound="ContinuousEvalCreateRequest")



@_attrs_define
class ContinuousEvalCreateRequest:
    """ Request schema for creating a continuous eval

        Attributes:
            name (str): Name of the continuous eval
            llm_eval_name (str): Name of the llm eval to create the continuous eval for
            llm_eval_version (int | str): Version of the llm eval to create the continuous eval for. Can be 'latest', a
                version number (e.g. '1', '2', etc.), an ISO datetime string (e.g. '2025-01-01T00:00:00'), or a tag.
            transform_id (UUID): ID of the transform to create the continuous eval for
            description (None | str | Unset): Description of the continuous eval
     """

    name: str
    llm_eval_name: str
    llm_eval_version: int | str
    transform_id: UUID
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name = self.name

        llm_eval_name = self.llm_eval_name

        llm_eval_version: int | str
        llm_eval_version = self.llm_eval_version

        transform_id = str(self.transform_id)

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "llm_eval_name": llm_eval_name,
            "llm_eval_version": llm_eval_version,
            "transform_id": transform_id,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        name = d.pop("name")

        llm_eval_name = d.pop("llm_eval_name")

        def _parse_llm_eval_version(data: object) -> int | str:
            return cast(int | str, data)

        llm_eval_version = _parse_llm_eval_version(d.pop("llm_eval_version"))


        transform_id = UUID(d.pop("transform_id"))




        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        continuous_eval_create_request = cls(
            name=name,
            llm_eval_name=llm_eval_name,
            llm_eval_version=llm_eval_version,
            transform_id=transform_id,
            description=description,
        )


        continuous_eval_create_request.additional_properties = d
        return continuous_eval_create_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
