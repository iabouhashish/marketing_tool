from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="CreateUserRequest")



@_attrs_define
class CreateUserRequest:
    """ 
        Attributes:
            email (str):
            password (str):
            roles (list[str]):
            first_name (str):
            last_name (str):
            temporary (bool | Unset):  Default: True.
     """

    email: str
    password: str
    roles: list[str]
    first_name: str
    last_name: str
    temporary: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        email = self.email

        password = self.password

        roles = self.roles



        first_name = self.first_name

        last_name = self.last_name

        temporary = self.temporary


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "email": email,
            "password": password,
            "roles": roles,
            "firstName": first_name,
            "lastName": last_name,
        })
        if temporary is not UNSET:
            field_dict["temporary"] = temporary

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        email = d.pop("email")

        password = d.pop("password")

        roles = cast(list[str], d.pop("roles"))


        first_name = d.pop("firstName")

        last_name = d.pop("lastName")

        temporary = d.pop("temporary", UNSET)

        create_user_request = cls(
            email=email,
            password=password,
            roles=roles,
            first_name=first_name,
            last_name=last_name,
            temporary=temporary,
        )


        create_user_request.additional_properties = d
        return create_user_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
