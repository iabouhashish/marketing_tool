from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.trace_response import TraceResponse





T = TypeVar("T", bound="QueryTracesWithMetricsResponse")



@_attrs_define
class QueryTracesWithMetricsResponse:
    """ New response format that groups spans into traces with nested structure

        Attributes:
            count (int): The total number of spans matching the query parameters
            traces (list[TraceResponse]): List of traces containing nested spans matching the search filters
     """

    count: int
    traces: list[TraceResponse]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.trace_response import TraceResponse
        count = self.count

        traces = []
        for traces_item_data in self.traces:
            traces_item = traces_item_data.to_dict()
            traces.append(traces_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "count": count,
            "traces": traces,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.trace_response import TraceResponse
        d = dict(src_dict)
        count = d.pop("count")

        traces = []
        _traces = d.pop("traces")
        for traces_item_data in (_traces):
            traces_item = TraceResponse.from_dict(traces_item_data)



            traces.append(traces_item)


        query_traces_with_metrics_response = cls(
            count=count,
            traces=traces,
        )


        query_traces_with_metrics_response.additional_properties = d
        return query_traces_with_metrics_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
