from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.model_provider import ModelProvider
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.llm_base_config_settings import LLMBaseConfigSettings





T = TypeVar("T", bound="LLMEval")



@_attrs_define
class LLMEval:
    """ 
        Attributes:
            name (str): Name of the llm eval
            model_name (str): Name of the LLM model (e.g., 'gpt-4o', 'claude-3-sonnet')
            model_provider (ModelProvider):
            instructions (str): Instructions for the llm eval
            created_at (datetime.datetime): Timestamp when the llm eval was created.
            variables (list[str] | Unset): List of variable names for the llm eval
            tags (list[str] | Unset): List of tags for this llm eval version
            config (LLMBaseConfigSettings | None | Unset): LLM configurations for this eval (e.g. temperature, max_tokens,
                etc.)
            deleted_at (datetime.datetime | None | Unset): Time that this llm eval was deleted
            version (int | Unset): Version of the llm eval Default: 1.
     """

    name: str
    model_name: str
    model_provider: ModelProvider
    instructions: str
    created_at: datetime.datetime
    variables: list[str] | Unset = UNSET
    tags: list[str] | Unset = UNSET
    config: LLMBaseConfigSettings | None | Unset = UNSET
    deleted_at: datetime.datetime | None | Unset = UNSET
    version: int | Unset = 1
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.llm_base_config_settings import LLMBaseConfigSettings
        name = self.name

        model_name = self.model_name

        model_provider = self.model_provider.value

        instructions = self.instructions

        created_at = self.created_at.isoformat()

        variables: list[str] | Unset = UNSET
        if not isinstance(self.variables, Unset):
            variables = self.variables



        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags



        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, LLMBaseConfigSettings):
            config = self.config.to_dict()
        else:
            config = self.config

        deleted_at: None | str | Unset
        if isinstance(self.deleted_at, Unset):
            deleted_at = UNSET
        elif isinstance(self.deleted_at, datetime.datetime):
            deleted_at = self.deleted_at.isoformat()
        else:
            deleted_at = self.deleted_at

        version = self.version


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "model_name": model_name,
            "model_provider": model_provider,
            "instructions": instructions,
            "created_at": created_at,
        })
        if variables is not UNSET:
            field_dict["variables"] = variables
        if tags is not UNSET:
            field_dict["tags"] = tags
        if config is not UNSET:
            field_dict["config"] = config
        if deleted_at is not UNSET:
            field_dict["deleted_at"] = deleted_at
        if version is not UNSET:
            field_dict["version"] = version

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.llm_base_config_settings import LLMBaseConfigSettings
        d = dict(src_dict)
        name = d.pop("name")

        model_name = d.pop("model_name")

        model_provider = ModelProvider(d.pop("model_provider"))




        instructions = d.pop("instructions")

        created_at = isoparse(d.pop("created_at"))




        variables = cast(list[str], d.pop("variables", UNSET))


        tags = cast(list[str], d.pop("tags", UNSET))


        def _parse_config(data: object) -> LLMBaseConfigSettings | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0 = LLMBaseConfigSettings.from_dict(data)



                return config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LLMBaseConfigSettings | None | Unset, data)

        config = _parse_config(d.pop("config", UNSET))


        def _parse_deleted_at(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                deleted_at_type_0 = isoparse(data)



                return deleted_at_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        deleted_at = _parse_deleted_at(d.pop("deleted_at", UNSET))


        version = d.pop("version", UNSET)

        llm_eval = cls(
            name=name,
            model_name=model_name,
            model_provider=model_provider,
            instructions=instructions,
            created_at=created_at,
            variables=variables,
            tags=tags,
            config=config,
            deleted_at=deleted_at,
            version=version,
        )


        llm_eval.additional_properties = d
        return llm_eval

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
