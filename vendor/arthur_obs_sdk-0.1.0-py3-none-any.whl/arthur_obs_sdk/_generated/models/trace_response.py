from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.nested_span_with_metrics_response import NestedSpanWithMetricsResponse
  from ..models.agentic_annotation_response import AgenticAnnotationResponse





T = TypeVar("T", bound="TraceResponse")



@_attrs_define
class TraceResponse:
    """ Response model for a single trace containing nested spans

        Attributes:
            trace_id (str): ID of the trace
            start_time (datetime.datetime): Start time of the earliest span in this trace
            end_time (datetime.datetime): End time of the latest span in this trace
            prompt_token_count (int | None | Unset): Number of prompt tokens
            completion_token_count (int | None | Unset): Number of completion tokens
            total_token_count (int | None | Unset): Total number of tokens
            prompt_token_cost (float | None | Unset): Cost of prompt tokens in USD
            completion_token_cost (float | None | Unset): Cost of completion tokens in USD
            total_token_cost (float | None | Unset): Total cost in USD
            input_content (None | str | Unset): Root span input value from trace metadata
            output_content (None | str | Unset): Root span output value from trace metadata
            root_spans (list[NestedSpanWithMetricsResponse] | Unset): Root spans (spans with no parent) in this trace, with
                children nested
            annotations (list[AgenticAnnotationResponse] | None | Unset): Annotations for this trace.
     """

    trace_id: str
    start_time: datetime.datetime
    end_time: datetime.datetime
    prompt_token_count: int | None | Unset = UNSET
    completion_token_count: int | None | Unset = UNSET
    total_token_count: int | None | Unset = UNSET
    prompt_token_cost: float | None | Unset = UNSET
    completion_token_cost: float | None | Unset = UNSET
    total_token_cost: float | None | Unset = UNSET
    input_content: None | str | Unset = UNSET
    output_content: None | str | Unset = UNSET
    root_spans: list[NestedSpanWithMetricsResponse] | Unset = UNSET
    annotations: list[AgenticAnnotationResponse] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.nested_span_with_metrics_response import NestedSpanWithMetricsResponse
        from ..models.agentic_annotation_response import AgenticAnnotationResponse
        trace_id = self.trace_id

        start_time = self.start_time.isoformat()

        end_time = self.end_time.isoformat()

        prompt_token_count: int | None | Unset
        if isinstance(self.prompt_token_count, Unset):
            prompt_token_count = UNSET
        else:
            prompt_token_count = self.prompt_token_count

        completion_token_count: int | None | Unset
        if isinstance(self.completion_token_count, Unset):
            completion_token_count = UNSET
        else:
            completion_token_count = self.completion_token_count

        total_token_count: int | None | Unset
        if isinstance(self.total_token_count, Unset):
            total_token_count = UNSET
        else:
            total_token_count = self.total_token_count

        prompt_token_cost: float | None | Unset
        if isinstance(self.prompt_token_cost, Unset):
            prompt_token_cost = UNSET
        else:
            prompt_token_cost = self.prompt_token_cost

        completion_token_cost: float | None | Unset
        if isinstance(self.completion_token_cost, Unset):
            completion_token_cost = UNSET
        else:
            completion_token_cost = self.completion_token_cost

        total_token_cost: float | None | Unset
        if isinstance(self.total_token_cost, Unset):
            total_token_cost = UNSET
        else:
            total_token_cost = self.total_token_cost

        input_content: None | str | Unset
        if isinstance(self.input_content, Unset):
            input_content = UNSET
        else:
            input_content = self.input_content

        output_content: None | str | Unset
        if isinstance(self.output_content, Unset):
            output_content = UNSET
        else:
            output_content = self.output_content

        root_spans: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.root_spans, Unset):
            root_spans = []
            for root_spans_item_data in self.root_spans:
                root_spans_item = root_spans_item_data.to_dict()
                root_spans.append(root_spans_item)



        annotations: list[dict[str, Any]] | None | Unset
        if isinstance(self.annotations, Unset):
            annotations = UNSET
        elif isinstance(self.annotations, list):
            annotations = []
            for annotations_type_0_item_data in self.annotations:
                annotations_type_0_item = annotations_type_0_item_data.to_dict()
                annotations.append(annotations_type_0_item)


        else:
            annotations = self.annotations


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "trace_id": trace_id,
            "start_time": start_time,
            "end_time": end_time,
        })
        if prompt_token_count is not UNSET:
            field_dict["prompt_token_count"] = prompt_token_count
        if completion_token_count is not UNSET:
            field_dict["completion_token_count"] = completion_token_count
        if total_token_count is not UNSET:
            field_dict["total_token_count"] = total_token_count
        if prompt_token_cost is not UNSET:
            field_dict["prompt_token_cost"] = prompt_token_cost
        if completion_token_cost is not UNSET:
            field_dict["completion_token_cost"] = completion_token_cost
        if total_token_cost is not UNSET:
            field_dict["total_token_cost"] = total_token_cost
        if input_content is not UNSET:
            field_dict["input_content"] = input_content
        if output_content is not UNSET:
            field_dict["output_content"] = output_content
        if root_spans is not UNSET:
            field_dict["root_spans"] = root_spans
        if annotations is not UNSET:
            field_dict["annotations"] = annotations

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.nested_span_with_metrics_response import NestedSpanWithMetricsResponse
        from ..models.agentic_annotation_response import AgenticAnnotationResponse
        d = dict(src_dict)
        trace_id = d.pop("trace_id")

        start_time = isoparse(d.pop("start_time"))




        end_time = isoparse(d.pop("end_time"))




        def _parse_prompt_token_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        prompt_token_count = _parse_prompt_token_count(d.pop("prompt_token_count", UNSET))


        def _parse_completion_token_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        completion_token_count = _parse_completion_token_count(d.pop("completion_token_count", UNSET))


        def _parse_total_token_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_token_count = _parse_total_token_count(d.pop("total_token_count", UNSET))


        def _parse_prompt_token_cost(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        prompt_token_cost = _parse_prompt_token_cost(d.pop("prompt_token_cost", UNSET))


        def _parse_completion_token_cost(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        completion_token_cost = _parse_completion_token_cost(d.pop("completion_token_cost", UNSET))


        def _parse_total_token_cost(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        total_token_cost = _parse_total_token_cost(d.pop("total_token_cost", UNSET))


        def _parse_input_content(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        input_content = _parse_input_content(d.pop("input_content", UNSET))


        def _parse_output_content(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        output_content = _parse_output_content(d.pop("output_content", UNSET))


        _root_spans = d.pop("root_spans", UNSET)
        root_spans: list[NestedSpanWithMetricsResponse] | Unset = UNSET
        if _root_spans is not UNSET:
            root_spans = []
            for root_spans_item_data in _root_spans:
                root_spans_item = NestedSpanWithMetricsResponse.from_dict(root_spans_item_data)



                root_spans.append(root_spans_item)


        def _parse_annotations(data: object) -> list[AgenticAnnotationResponse] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                annotations_type_0 = []
                _annotations_type_0 = data
                for annotations_type_0_item_data in (_annotations_type_0):
                    annotations_type_0_item = AgenticAnnotationResponse.from_dict(annotations_type_0_item_data)



                    annotations_type_0.append(annotations_type_0_item)

                return annotations_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[AgenticAnnotationResponse] | None | Unset, data)

        annotations = _parse_annotations(d.pop("annotations", UNSET))


        trace_response = cls(
            trace_id=trace_id,
            start_time=start_time,
            end_time=end_time,
            prompt_token_count=prompt_token_count,
            completion_token_count=completion_token_count,
            total_token_count=total_token_count,
            prompt_token_cost=prompt_token_cost,
            completion_token_cost=completion_token_cost,
            total_token_cost=total_token_cost,
            input_content=input_content,
            output_content=output_content,
            root_spans=root_spans,
            annotations=annotations,
        )


        trace_response.additional_properties = d
        return trace_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
