from enum import Enum

class RagAPIKeyAuthenticationProviderEnum(str, Enum):
    WEAVIATE = "weaviate"

    def __str__(self) -> str:
        return str(self.value)
