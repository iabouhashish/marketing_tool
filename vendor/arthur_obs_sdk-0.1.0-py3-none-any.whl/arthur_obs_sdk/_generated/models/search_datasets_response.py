from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.dataset_response import DatasetResponse





T = TypeVar("T", bound="SearchDatasetsResponse")



@_attrs_define
class SearchDatasetsResponse:
    """ 
        Attributes:
            count (int): The total number of datasets matching the parameters.
            datasets (list[DatasetResponse]): List of datasets matching the search filters. Length is less than or equal to
                page_size parameter
     """

    count: int
    datasets: list[DatasetResponse]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.dataset_response import DatasetResponse
        count = self.count

        datasets = []
        for datasets_item_data in self.datasets:
            datasets_item = datasets_item_data.to_dict()
            datasets.append(datasets_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "count": count,
            "datasets": datasets,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dataset_response import DatasetResponse
        d = dict(src_dict)
        count = d.pop("count")

        datasets = []
        _datasets = d.pop("datasets")
        for datasets_item_data in (_datasets):
            datasets_item = DatasetResponse.from_dict(datasets_item_data)



            datasets.append(datasets_item)


        search_datasets_response = cls(
            count=count,
            datasets=datasets,
        )


        search_datasets_response.additional_properties = d
        return search_datasets_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
