from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.weaviate_query_result_metadata import WeaviateQueryResultMetadata
  from ..models.weaviate_query_result_properties import WeaviateQueryResultProperties
  from ..models.weaviate_query_result_vector_type_0 import WeaviateQueryResultVectorType0





T = TypeVar("T", bound="WeaviateQueryResult")



@_attrs_define
class WeaviateQueryResult:
    """ Individual search result from Weaviate

        Attributes:
            uuid (UUID): Unique identifier of the result
            properties (WeaviateQueryResultProperties): Properties of the result object
            metadata (None | Unset | WeaviateQueryResultMetadata): Search metadata including distance, score, etc.
            vector (None | Unset | WeaviateQueryResultVectorType0): Vector representation
     """

    uuid: UUID
    properties: WeaviateQueryResultProperties
    metadata: None | Unset | WeaviateQueryResultMetadata = UNSET
    vector: None | Unset | WeaviateQueryResultVectorType0 = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.weaviate_query_result_metadata import WeaviateQueryResultMetadata
        from ..models.weaviate_query_result_properties import WeaviateQueryResultProperties
        from ..models.weaviate_query_result_vector_type_0 import WeaviateQueryResultVectorType0
        uuid = str(self.uuid)

        properties = self.properties.to_dict()

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, WeaviateQueryResultMetadata):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        vector: dict[str, Any] | None | Unset
        if isinstance(self.vector, Unset):
            vector = UNSET
        elif isinstance(self.vector, WeaviateQueryResultVectorType0):
            vector = self.vector.to_dict()
        else:
            vector = self.vector


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "uuid": uuid,
            "properties": properties,
        })
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if vector is not UNSET:
            field_dict["vector"] = vector

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.weaviate_query_result_metadata import WeaviateQueryResultMetadata
        from ..models.weaviate_query_result_properties import WeaviateQueryResultProperties
        from ..models.weaviate_query_result_vector_type_0 import WeaviateQueryResultVectorType0
        d = dict(src_dict)
        uuid = UUID(d.pop("uuid"))




        properties = WeaviateQueryResultProperties.from_dict(d.pop("properties"))




        def _parse_metadata(data: object) -> None | Unset | WeaviateQueryResultMetadata:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = WeaviateQueryResultMetadata.from_dict(data)



                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | WeaviateQueryResultMetadata, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))


        def _parse_vector(data: object) -> None | Unset | WeaviateQueryResultVectorType0:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                vector_type_0 = WeaviateQueryResultVectorType0.from_dict(data)



                return vector_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | WeaviateQueryResultVectorType0, data)

        vector = _parse_vector(d.pop("vector", UNSET))


        weaviate_query_result = cls(
            uuid=uuid,
            properties=properties,
            metadata=metadata,
            vector=vector,
        )


        weaviate_query_result.additional_properties = d
        return weaviate_query_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
