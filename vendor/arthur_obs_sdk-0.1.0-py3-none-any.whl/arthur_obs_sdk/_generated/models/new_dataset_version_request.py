from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
  from ..models.new_dataset_version_row_request import NewDatasetVersionRowRequest
  from ..models.new_dataset_version_update_row_request import NewDatasetVersionUpdateRowRequest





T = TypeVar("T", bound="NewDatasetVersionRequest")



@_attrs_define
class NewDatasetVersionRequest:
    """ 
        Attributes:
            rows_to_add (list[NewDatasetVersionRowRequest]): List of rows to be added to the new dataset version.
            rows_to_delete (list[UUID]): List of IDs of rows to be deleted from the new dataset version.
            rows_to_update (list[NewDatasetVersionUpdateRowRequest]): List of IDs of rows to be updated in the new dataset
                version with their new values. Should include the value in the row for every column in the dataset, not just the
                updated column values.
            rows_to_delete_filter (list[NewDatasetVersionRowColumnItemRequest] | None | Unset): Optional list of column name
                and value filters. Rows matching ALL specified column name-value pairs (AND condition) will be deleted from the
                new dataset version. This filter is applied in addition to rows_to_delete.
     """

    rows_to_add: list[NewDatasetVersionRowRequest]
    rows_to_delete: list[UUID]
    rows_to_update: list[NewDatasetVersionUpdateRowRequest]
    rows_to_delete_filter: list[NewDatasetVersionRowColumnItemRequest] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        from ..models.new_dataset_version_row_request import NewDatasetVersionRowRequest
        from ..models.new_dataset_version_update_row_request import NewDatasetVersionUpdateRowRequest
        rows_to_add = []
        for rows_to_add_item_data in self.rows_to_add:
            rows_to_add_item = rows_to_add_item_data.to_dict()
            rows_to_add.append(rows_to_add_item)



        rows_to_delete = []
        for rows_to_delete_item_data in self.rows_to_delete:
            rows_to_delete_item = str(rows_to_delete_item_data)
            rows_to_delete.append(rows_to_delete_item)



        rows_to_update = []
        for rows_to_update_item_data in self.rows_to_update:
            rows_to_update_item = rows_to_update_item_data.to_dict()
            rows_to_update.append(rows_to_update_item)



        rows_to_delete_filter: list[dict[str, Any]] | None | Unset
        if isinstance(self.rows_to_delete_filter, Unset):
            rows_to_delete_filter = UNSET
        elif isinstance(self.rows_to_delete_filter, list):
            rows_to_delete_filter = []
            for rows_to_delete_filter_type_0_item_data in self.rows_to_delete_filter:
                rows_to_delete_filter_type_0_item = rows_to_delete_filter_type_0_item_data.to_dict()
                rows_to_delete_filter.append(rows_to_delete_filter_type_0_item)


        else:
            rows_to_delete_filter = self.rows_to_delete_filter


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "rows_to_add": rows_to_add,
            "rows_to_delete": rows_to_delete,
            "rows_to_update": rows_to_update,
        })
        if rows_to_delete_filter is not UNSET:
            field_dict["rows_to_delete_filter"] = rows_to_delete_filter

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        from ..models.new_dataset_version_row_request import NewDatasetVersionRowRequest
        from ..models.new_dataset_version_update_row_request import NewDatasetVersionUpdateRowRequest
        d = dict(src_dict)
        rows_to_add = []
        _rows_to_add = d.pop("rows_to_add")
        for rows_to_add_item_data in (_rows_to_add):
            rows_to_add_item = NewDatasetVersionRowRequest.from_dict(rows_to_add_item_data)



            rows_to_add.append(rows_to_add_item)


        rows_to_delete = []
        _rows_to_delete = d.pop("rows_to_delete")
        for rows_to_delete_item_data in (_rows_to_delete):
            rows_to_delete_item = UUID(rows_to_delete_item_data)



            rows_to_delete.append(rows_to_delete_item)


        rows_to_update = []
        _rows_to_update = d.pop("rows_to_update")
        for rows_to_update_item_data in (_rows_to_update):
            rows_to_update_item = NewDatasetVersionUpdateRowRequest.from_dict(rows_to_update_item_data)



            rows_to_update.append(rows_to_update_item)


        def _parse_rows_to_delete_filter(data: object) -> list[NewDatasetVersionRowColumnItemRequest] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                rows_to_delete_filter_type_0 = []
                _rows_to_delete_filter_type_0 = data
                for rows_to_delete_filter_type_0_item_data in (_rows_to_delete_filter_type_0):
                    rows_to_delete_filter_type_0_item = NewDatasetVersionRowColumnItemRequest.from_dict(rows_to_delete_filter_type_0_item_data)



                    rows_to_delete_filter_type_0.append(rows_to_delete_filter_type_0_item)

                return rows_to_delete_filter_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[NewDatasetVersionRowColumnItemRequest] | None | Unset, data)

        rows_to_delete_filter = _parse_rows_to_delete_filter(d.pop("rows_to_delete_filter", UNSET))


        new_dataset_version_request = cls(
            rows_to_add=rows_to_add,
            rows_to_delete=rows_to_delete,
            rows_to_update=rows_to_update,
            rows_to_delete_filter=rows_to_delete_filter,
        )


        new_dataset_version_request.additional_properties = d
        return new_dataset_version_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
