from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="PromptOutput")



@_attrs_define
class PromptOutput:
    """ Output from a prompt execution

        Attributes:
            content (str): Content of the prompt response
            cost (str): Cost of the prompt execution
            tool_calls (list[Any] | Unset): Tool calls made by the prompt
     """

    content: str
    cost: str
    tool_calls: list[Any] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        content = self.content

        cost = self.cost

        tool_calls: list[Any] | Unset = UNSET
        if not isinstance(self.tool_calls, Unset):
            tool_calls = self.tool_calls




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "content": content,
            "cost": cost,
        })
        if tool_calls is not UNSET:
            field_dict["tool_calls"] = tool_calls

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        content = d.pop("content")

        cost = d.pop("cost")

        tool_calls = cast(list[Any], d.pop("tool_calls", UNSET))


        prompt_output = cls(
            content=content,
            cost=cost,
            tool_calls=tool_calls,
        )


        prompt_output.additional_properties = d
        return prompt_output

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
