from enum import Enum

class RuleResultEnum(str, Enum):
    FAIL = "Fail"
    MODEL_NOT_AVAILABLE = "Model Not Available"
    PARTIALLY_UNAVAILABLE = "Partially Unavailable"
    PASS = "Pass"
    SKIPPED = "Skipped"
    UNAVAILABLE = "Unavailable"

    def __str__(self) -> str:
        return str(self.value)
