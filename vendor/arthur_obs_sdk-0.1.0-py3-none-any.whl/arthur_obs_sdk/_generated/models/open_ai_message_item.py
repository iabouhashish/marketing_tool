from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.open_ai_message_type import OpenAIMessageType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.input_audio import InputAudio
  from ..models.image_url import ImageURL





T = TypeVar("T", bound="OpenAIMessageItem")



@_attrs_define
class OpenAIMessageItem:
    """ 
        Attributes:
            type_ (OpenAIMessageType):
            text (None | str | Unset): Text content of the message if type is 'text'
            image_url (ImageURL | None | Unset): Image URL content of the message if type is 'image_url'
            input_audio (InputAudio | None | Unset): Input audio content of the message if type is 'input_audio'
     """

    type_: OpenAIMessageType
    text: None | str | Unset = UNSET
    image_url: ImageURL | None | Unset = UNSET
    input_audio: InputAudio | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.input_audio import InputAudio
        from ..models.image_url import ImageURL
        type_ = self.type_.value

        text: None | str | Unset
        if isinstance(self.text, Unset):
            text = UNSET
        else:
            text = self.text

        image_url: dict[str, Any] | None | Unset
        if isinstance(self.image_url, Unset):
            image_url = UNSET
        elif isinstance(self.image_url, ImageURL):
            image_url = self.image_url.to_dict()
        else:
            image_url = self.image_url

        input_audio: dict[str, Any] | None | Unset
        if isinstance(self.input_audio, Unset):
            input_audio = UNSET
        elif isinstance(self.input_audio, InputAudio):
            input_audio = self.input_audio.to_dict()
        else:
            input_audio = self.input_audio


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "type": type_,
        })
        if text is not UNSET:
            field_dict["text"] = text
        if image_url is not UNSET:
            field_dict["image_url"] = image_url
        if input_audio is not UNSET:
            field_dict["input_audio"] = input_audio

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.input_audio import InputAudio
        from ..models.image_url import ImageURL
        d = dict(src_dict)
        type_ = OpenAIMessageType(d.pop("type"))




        def _parse_text(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        text = _parse_text(d.pop("text", UNSET))


        def _parse_image_url(data: object) -> ImageURL | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                image_url_type_0 = ImageURL.from_dict(data)



                return image_url_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ImageURL | None | Unset, data)

        image_url = _parse_image_url(d.pop("image_url", UNSET))


        def _parse_input_audio(data: object) -> InputAudio | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                input_audio_type_0 = InputAudio.from_dict(data)



                return input_audio_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(InputAudio | None | Unset, data)

        input_audio = _parse_input_audio(d.pop("input_audio", UNSET))


        open_ai_message_item = cls(
            type_=type_,
            text=text,
            image_url=image_url,
            input_audio=input_audio,
        )


        open_ai_message_item.additional_properties = d
        return open_ai_message_item

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
