from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.keyword_span_response import KeywordSpanResponse





T = TypeVar("T", bound="KeywordDetailsResponse")



@_attrs_define
class KeywordDetailsResponse:
    """ 
        Attributes:
            score (bool | None | Unset):
            message (None | str | Unset):
            keyword_matches (list[KeywordSpanResponse] | Unset): Each keyword in this list corresponds to a keyword that was
                both configured in the rule that was run and found in the input text.
     """

    score: bool | None | Unset = UNSET
    message: None | str | Unset = UNSET
    keyword_matches: list[KeywordSpanResponse] | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.keyword_span_response import KeywordSpanResponse
        score: bool | None | Unset
        if isinstance(self.score, Unset):
            score = UNSET
        else:
            score = self.score

        message: None | str | Unset
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        keyword_matches: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.keyword_matches, Unset):
            keyword_matches = []
            for keyword_matches_item_data in self.keyword_matches:
                keyword_matches_item = keyword_matches_item_data.to_dict()
                keyword_matches.append(keyword_matches_item)




        field_dict: dict[str, Any] = {}

        field_dict.update({
        })
        if score is not UNSET:
            field_dict["score"] = score
        if message is not UNSET:
            field_dict["message"] = message
        if keyword_matches is not UNSET:
            field_dict["keyword_matches"] = keyword_matches

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.keyword_span_response import KeywordSpanResponse
        d = dict(src_dict)
        def _parse_score(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        score = _parse_score(d.pop("score", UNSET))


        def _parse_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        message = _parse_message(d.pop("message", UNSET))


        _keyword_matches = d.pop("keyword_matches", UNSET)
        keyword_matches: list[KeywordSpanResponse] | Unset = UNSET
        if _keyword_matches is not UNSET:
            keyword_matches = []
            for keyword_matches_item_data in _keyword_matches:
                keyword_matches_item = KeywordSpanResponse.from_dict(keyword_matches_item_data)



                keyword_matches.append(keyword_matches_item)


        keyword_details_response = cls(
            score=score,
            message=message,
            keyword_matches=keyword_matches,
        )

        return keyword_details_response

