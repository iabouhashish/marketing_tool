from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.external_rule_result import ExternalRuleResult
  from ..models.chat_document_context import ChatDocumentContext





T = TypeVar("T", bound="ChatResponse")



@_attrs_define
class ChatResponse:
    """ 
        Attributes:
            inference_id (str): ID of the inference sent to the chat
            conversation_id (str): ID of the conversation session
            timestamp (int): Time the inference was made in unix milliseconds
            retrieved_context (list[ChatDocumentContext]): related sections of documents that were most relevant to the
                inference prompt. Formatted as a list of retrieved context chunks which include document name, seq num, and
                context.
            llm_response (str): response from the LLM for the original user prompt
            prompt_results (list[ExternalRuleResult]): list of rule results for the user prompt
            response_results (list[ExternalRuleResult]): list of rule results for the llm response
            model_name (None | str | Unset): The model name and version used for this chat response (e.g., 'gpt-4',
                'gpt-3.5-turbo', 'claude-3-opus', 'gemini-pro').
     """

    inference_id: str
    conversation_id: str
    timestamp: int
    retrieved_context: list[ChatDocumentContext]
    llm_response: str
    prompt_results: list[ExternalRuleResult]
    response_results: list[ExternalRuleResult]
    model_name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.external_rule_result import ExternalRuleResult
        from ..models.chat_document_context import ChatDocumentContext
        inference_id = self.inference_id

        conversation_id = self.conversation_id

        timestamp = self.timestamp

        retrieved_context = []
        for retrieved_context_item_data in self.retrieved_context:
            retrieved_context_item = retrieved_context_item_data.to_dict()
            retrieved_context.append(retrieved_context_item)



        llm_response = self.llm_response

        prompt_results = []
        for prompt_results_item_data in self.prompt_results:
            prompt_results_item = prompt_results_item_data.to_dict()
            prompt_results.append(prompt_results_item)



        response_results = []
        for response_results_item_data in self.response_results:
            response_results_item = response_results_item_data.to_dict()
            response_results.append(response_results_item)



        model_name: None | str | Unset
        if isinstance(self.model_name, Unset):
            model_name = UNSET
        else:
            model_name = self.model_name


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "inference_id": inference_id,
            "conversation_id": conversation_id,
            "timestamp": timestamp,
            "retrieved_context": retrieved_context,
            "llm_response": llm_response,
            "prompt_results": prompt_results,
            "response_results": response_results,
        })
        if model_name is not UNSET:
            field_dict["model_name"] = model_name

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.external_rule_result import ExternalRuleResult
        from ..models.chat_document_context import ChatDocumentContext
        d = dict(src_dict)
        inference_id = d.pop("inference_id")

        conversation_id = d.pop("conversation_id")

        timestamp = d.pop("timestamp")

        retrieved_context = []
        _retrieved_context = d.pop("retrieved_context")
        for retrieved_context_item_data in (_retrieved_context):
            retrieved_context_item = ChatDocumentContext.from_dict(retrieved_context_item_data)



            retrieved_context.append(retrieved_context_item)


        llm_response = d.pop("llm_response")

        prompt_results = []
        _prompt_results = d.pop("prompt_results")
        for prompt_results_item_data in (_prompt_results):
            prompt_results_item = ExternalRuleResult.from_dict(prompt_results_item_data)



            prompt_results.append(prompt_results_item)


        response_results = []
        _response_results = d.pop("response_results")
        for response_results_item_data in (_response_results):
            response_results_item = ExternalRuleResult.from_dict(response_results_item_data)



            response_results.append(response_results_item)


        def _parse_model_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model_name = _parse_model_name(d.pop("model_name", UNSET))


        chat_response = cls(
            inference_id=inference_id,
            conversation_id=conversation_id,
            timestamp=timestamp,
            retrieved_context=retrieved_context,
            llm_response=llm_response,
            prompt_results=prompt_results,
            response_results=response_results,
            model_name=model_name,
        )


        chat_response.additional_properties = d
        return chat_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
