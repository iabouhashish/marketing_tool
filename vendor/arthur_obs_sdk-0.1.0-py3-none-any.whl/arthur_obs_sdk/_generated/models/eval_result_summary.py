from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="EvalResultSummary")



@_attrs_define
class EvalResultSummary:
    """ Results for a single eval

        Attributes:
            eval_name (str): Name of the evaluation
            eval_version (str): Version of the evaluation
            pass_count (int): Number of test cases that passed
            total_count (int): Total number of test cases evaluated
     """

    eval_name: str
    eval_version: str
    pass_count: int
    total_count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        eval_name = self.eval_name

        eval_version = self.eval_version

        pass_count = self.pass_count

        total_count = self.total_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "eval_name": eval_name,
            "eval_version": eval_version,
            "pass_count": pass_count,
            "total_count": total_count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        eval_name = d.pop("eval_name")

        eval_version = d.pop("eval_version")

        pass_count = d.pop("pass_count")

        total_count = d.pop("total_count")

        eval_result_summary = cls(
            eval_name=eval_name,
            eval_version=eval_version,
            pass_count=pass_count,
            total_count=total_count,
        )


        eval_result_summary.additional_properties = d
        return eval_result_summary

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
