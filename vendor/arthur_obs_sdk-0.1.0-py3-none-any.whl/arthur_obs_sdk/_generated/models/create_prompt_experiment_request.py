from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
  from ..models.saved_prompt_config import SavedPromptConfig
  from ..models.prompt_variable_mapping import PromptVariableMapping
  from ..models.unsaved_prompt_config import UnsavedPromptConfig
  from ..models.eval_ref import EvalRef
  from ..models.dataset_ref_input import DatasetRefInput





T = TypeVar("T", bound="CreatePromptExperimentRequest")



@_attrs_define
class CreatePromptExperimentRequest:
    """ Request to create a new prompt experiment

        Attributes:
            name (str): Name for the experiment
            dataset_ref (DatasetRefInput): Reference to a dataset and version for input (without name)
            eval_list (list[EvalRef]): List of evaluations to run
            prompt_configs (list[SavedPromptConfig | UnsavedPromptConfig]): List of prompt configurations (saved or unsaved)
            prompt_variable_mapping (list[PromptVariableMapping]): Shared variable mapping for all prompts
            description (None | str | Unset): Description of the experiment
            dataset_row_filter (list[NewDatasetVersionRowColumnItemRequest] | None | Unset): Optional list of column name
                and value filters. Only rows matching ALL specified column name-value pairs (AND condition) will be included in
                the experiment. If not specified, all rows from the dataset will be used.
     """

    name: str
    dataset_ref: DatasetRefInput
    eval_list: list[EvalRef]
    prompt_configs: list[SavedPromptConfig | UnsavedPromptConfig]
    prompt_variable_mapping: list[PromptVariableMapping]
    description: None | str | Unset = UNSET
    dataset_row_filter: list[NewDatasetVersionRowColumnItemRequest] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        from ..models.saved_prompt_config import SavedPromptConfig
        from ..models.prompt_variable_mapping import PromptVariableMapping
        from ..models.unsaved_prompt_config import UnsavedPromptConfig
        from ..models.eval_ref import EvalRef
        from ..models.dataset_ref_input import DatasetRefInput
        name = self.name

        dataset_ref = self.dataset_ref.to_dict()

        eval_list = []
        for eval_list_item_data in self.eval_list:
            eval_list_item = eval_list_item_data.to_dict()
            eval_list.append(eval_list_item)



        prompt_configs = []
        for prompt_configs_item_data in self.prompt_configs:
            prompt_configs_item: dict[str, Any]
            if isinstance(prompt_configs_item_data, SavedPromptConfig):
                prompt_configs_item = prompt_configs_item_data.to_dict()
            else:
                prompt_configs_item = prompt_configs_item_data.to_dict()

            prompt_configs.append(prompt_configs_item)



        prompt_variable_mapping = []
        for prompt_variable_mapping_item_data in self.prompt_variable_mapping:
            prompt_variable_mapping_item = prompt_variable_mapping_item_data.to_dict()
            prompt_variable_mapping.append(prompt_variable_mapping_item)



        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        dataset_row_filter: list[dict[str, Any]] | None | Unset
        if isinstance(self.dataset_row_filter, Unset):
            dataset_row_filter = UNSET
        elif isinstance(self.dataset_row_filter, list):
            dataset_row_filter = []
            for dataset_row_filter_type_0_item_data in self.dataset_row_filter:
                dataset_row_filter_type_0_item = dataset_row_filter_type_0_item_data.to_dict()
                dataset_row_filter.append(dataset_row_filter_type_0_item)


        else:
            dataset_row_filter = self.dataset_row_filter


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
            "dataset_ref": dataset_ref,
            "eval_list": eval_list,
            "prompt_configs": prompt_configs,
            "prompt_variable_mapping": prompt_variable_mapping,
        })
        if description is not UNSET:
            field_dict["description"] = description
        if dataset_row_filter is not UNSET:
            field_dict["dataset_row_filter"] = dataset_row_filter

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        from ..models.saved_prompt_config import SavedPromptConfig
        from ..models.prompt_variable_mapping import PromptVariableMapping
        from ..models.unsaved_prompt_config import UnsavedPromptConfig
        from ..models.eval_ref import EvalRef
        from ..models.dataset_ref_input import DatasetRefInput
        d = dict(src_dict)
        name = d.pop("name")

        dataset_ref = DatasetRefInput.from_dict(d.pop("dataset_ref"))




        eval_list = []
        _eval_list = d.pop("eval_list")
        for eval_list_item_data in (_eval_list):
            eval_list_item = EvalRef.from_dict(eval_list_item_data)



            eval_list.append(eval_list_item)


        prompt_configs = []
        _prompt_configs = d.pop("prompt_configs")
        for prompt_configs_item_data in (_prompt_configs):
            def _parse_prompt_configs_item(data: object) -> SavedPromptConfig | UnsavedPromptConfig:
                try:
                    if not isinstance(data, dict):
                        raise TypeError()
                    prompt_configs_item_type_0 = SavedPromptConfig.from_dict(data)



                    return prompt_configs_item_type_0
                except (TypeError, ValueError, AttributeError, KeyError):
                    pass
                if not isinstance(data, dict):
                    raise TypeError()
                prompt_configs_item_type_1 = UnsavedPromptConfig.from_dict(data)



                return prompt_configs_item_type_1

            prompt_configs_item = _parse_prompt_configs_item(prompt_configs_item_data)

            prompt_configs.append(prompt_configs_item)


        prompt_variable_mapping = []
        _prompt_variable_mapping = d.pop("prompt_variable_mapping")
        for prompt_variable_mapping_item_data in (_prompt_variable_mapping):
            prompt_variable_mapping_item = PromptVariableMapping.from_dict(prompt_variable_mapping_item_data)



            prompt_variable_mapping.append(prompt_variable_mapping_item)


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_dataset_row_filter(data: object) -> list[NewDatasetVersionRowColumnItemRequest] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                dataset_row_filter_type_0 = []
                _dataset_row_filter_type_0 = data
                for dataset_row_filter_type_0_item_data in (_dataset_row_filter_type_0):
                    dataset_row_filter_type_0_item = NewDatasetVersionRowColumnItemRequest.from_dict(dataset_row_filter_type_0_item_data)



                    dataset_row_filter_type_0.append(dataset_row_filter_type_0_item)

                return dataset_row_filter_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[NewDatasetVersionRowColumnItemRequest] | None | Unset, data)

        dataset_row_filter = _parse_dataset_row_filter(d.pop("dataset_row_filter", UNSET))


        create_prompt_experiment_request = cls(
            name=name,
            dataset_ref=dataset_ref,
            eval_list=eval_list,
            prompt_configs=prompt_configs,
            prompt_variable_mapping=prompt_variable_mapping,
            description=description,
            dataset_row_filter=dataset_row_filter,
        )


        create_prompt_experiment_request.additional_properties = d
        return create_prompt_experiment_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
