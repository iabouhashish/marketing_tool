from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.unregistered_root_span_group import UnregisteredRootSpanGroup





T = TypeVar("T", bound="UnregisteredRootSpansResponse")



@_attrs_define
class UnregisteredRootSpansResponse:
    """ Response for unregistered root spans endpoint

        Attributes:
            groups (list[UnregisteredRootSpanGroup]): List of grouped root spans, ordered by count descending
            total_count (int): Total number of root spans (and traces) across all groups
     """

    groups: list[UnregisteredRootSpanGroup]
    total_count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.unregistered_root_span_group import UnregisteredRootSpanGroup
        groups = []
        for groups_item_data in self.groups:
            groups_item = groups_item_data.to_dict()
            groups.append(groups_item)



        total_count = self.total_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "groups": groups,
            "total_count": total_count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.unregistered_root_span_group import UnregisteredRootSpanGroup
        d = dict(src_dict)
        groups = []
        _groups = d.pop("groups")
        for groups_item_data in (_groups):
            groups_item = UnregisteredRootSpanGroup.from_dict(groups_item_data)



            groups.append(groups_item)


        total_count = d.pop("total_count")

        unregistered_root_spans_response = cls(
            groups=groups,
            total_count=total_count,
        )


        unregistered_root_spans_response.additional_properties = d
        return unregistered_root_spans_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
