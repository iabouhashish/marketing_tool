from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.dataset_response_metadata_type_0 import DatasetResponseMetadataType0





T = TypeVar("T", bound="DatasetResponse")



@_attrs_define
class DatasetResponse:
    """ 
        Attributes:
            id (UUID): ID of the dataset.
            task_id (str): ID of the task the dataset belongs to.
            name (str): Name of the dataset.
            created_at (int): Timestamp representing the time of dataset creation in unix milliseconds.
            updated_at (int): Timestamp representing the time of the last dataset update in unix milliseconds.
            description (None | str | Unset): Description of the dataset.
            metadata (DatasetResponseMetadataType0 | None | Unset): Any metadata to include that describes additional
                information about the dataset.
            latest_version_number (int | None | Unset): Version number representing the latest version of the dataset. If
                unset, no versions exist for the dataset yet.
     """

    id: UUID
    task_id: str
    name: str
    created_at: int
    updated_at: int
    description: None | str | Unset = UNSET
    metadata: DatasetResponseMetadataType0 | None | Unset = UNSET
    latest_version_number: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.dataset_response_metadata_type_0 import DatasetResponseMetadataType0
        id = str(self.id)

        task_id = self.task_id

        name = self.name

        created_at = self.created_at

        updated_at = self.updated_at

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        metadata: dict[str, Any] | None | Unset
        if isinstance(self.metadata, Unset):
            metadata = UNSET
        elif isinstance(self.metadata, DatasetResponseMetadataType0):
            metadata = self.metadata.to_dict()
        else:
            metadata = self.metadata

        latest_version_number: int | None | Unset
        if isinstance(self.latest_version_number, Unset):
            latest_version_number = UNSET
        else:
            latest_version_number = self.latest_version_number


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "task_id": task_id,
            "name": name,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if description is not UNSET:
            field_dict["description"] = description
        if metadata is not UNSET:
            field_dict["metadata"] = metadata
        if latest_version_number is not UNSET:
            field_dict["latest_version_number"] = latest_version_number

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dataset_response_metadata_type_0 import DatasetResponseMetadataType0
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        task_id = d.pop("task_id")

        name = d.pop("name")

        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_metadata(data: object) -> DatasetResponseMetadataType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                metadata_type_0 = DatasetResponseMetadataType0.from_dict(data)



                return metadata_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DatasetResponseMetadataType0 | None | Unset, data)

        metadata = _parse_metadata(d.pop("metadata", UNSET))


        def _parse_latest_version_number(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        latest_version_number = _parse_latest_version_number(d.pop("latest_version_number", UNSET))


        dataset_response = cls(
            id=id,
            task_id=task_id,
            name=name,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
            metadata=metadata,
            latest_version_number=latest_version_number,
        )


        dataset_response.additional_properties = d
        return dataset_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
