from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest





T = TypeVar("T", bound="NewDatasetVersionUpdateRowRequest")



@_attrs_define
class NewDatasetVersionUpdateRowRequest:
    """ Represents a row to be updated in a dataset version.

        Attributes:
            id (UUID): UUID of row to be updated.
            data (list[NewDatasetVersionRowColumnItemRequest]): List of column-value pairs in the updated row.
     """

    id: UUID
    data: list[NewDatasetVersionRowColumnItemRequest]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        id = str(self.id)

        data = []
        for data_item_data in self.data:
            data_item = data_item_data.to_dict()
            data.append(data_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "data": data,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        data = []
        _data = d.pop("data")
        for data_item_data in (_data):
            data_item = NewDatasetVersionRowColumnItemRequest.from_dict(data_item_data)



            data.append(data_item)


        new_dataset_version_update_row_request = cls(
            id=id,
            data=data,
        )


        new_dataset_version_update_row_request.additional_properties = d
        return new_dataset_version_update_row_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
