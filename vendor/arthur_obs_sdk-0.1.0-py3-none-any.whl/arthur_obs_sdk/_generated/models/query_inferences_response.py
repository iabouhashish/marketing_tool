from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.external_inference import ExternalInference





T = TypeVar("T", bound="QueryInferencesResponse")



@_attrs_define
class QueryInferencesResponse:
    """ 
        Example:
            {'count': 1, 'inferences': [{'conversation_id': '957df309-c907-4b77-abe5-15dd00c08112', 'created_at':
                1723204737120, 'id': '957df309-c907-4b77-abe5-15dd00c081f7', 'inference_feedback': [{'created_at':
                '2024-08-09T12:08:34.847381', 'id': '0d602e5c-4ae6-4fc9-a610-68a1d8928ad7', 'inference_id':
                '957df309-c907-4b77-abe5-15dd00c081f7', 'reason': 'Perfect answer.', 'score': 100, 'target': 'context',
                'updated_at': '2024-08-09T12:08:34.847386', 'user_id': '957df309-2137-4b77-abe5-15dd00c081f8'}],
                'inference_prompt': {'created_at': 1723204737121, 'id': '834f7ebd-cd6b-4691-9473-8bc350f8922c', 'inference_id':
                '957df309-c907-4b77-abe5-15dd00c081f7', 'message': 'How many stars are in the solar system?',
                'prompt_rule_results': [{'id': 'bc599a56-2e31-4cb7-910d-9e5ed6455db2', 'latency_ms': 73, 'name': 'My_PII_Rule',
                'result': 'Pass', 'rule_type': 'PIIDataRule', 'scope': 'default'}], 'result': 'Pass', 'tokens': 100,
                'updated_at': 1723204737121}, 'inference_response': {'context': 'Solar system contains one star.', 'created_at':
                1723204786599, 'id': 'ec765a75-1479-4938-8e1c-6334b7deb8ce', 'inference_id':
                '957df309-c907-4b77-abe5-15dd00c081f7', 'message': 'There is one star in solar system.',
                'response_rule_results': [{'id': 'a45267c5-96d9-4de2-a871-debf2c8fdb86', 'latency_ms': 107, 'name':
                'My_another_PII_Rule', 'result': 'Pass', 'rule_type': 'PIIDataRule', 'scope': 'default'}, {'details': {'claims':
                [{'claim': 'There is one star in solar system.', 'order_number': 0, 'reason': 'No hallucination detected!',
                'valid': True}], 'message': 'All claims were supported by the context!', 'pii_entities': [], 'pii_results': [],
                'score': True}, 'id': '92b7b46e-eaf2-4226-82d4-be12ceb3e4b7', 'latency_ms': 700, 'name':
                'My_Hallucination_Rule', 'result': 'Pass', 'rule_type': 'ModelHallucinationRuleV2', 'scope': 'default'}],
                'result': 'Pass', 'tokens': 100, 'updated_at': 1723204786599}, 'result': 'Pass', 'task_id':
                '957df309-c907-4b77-abe5-15dd00c081f8', 'task_name': 'My task name', 'updated_at': 1723204787050, 'user_id':
                '957df309-2137-4b77-abe5-15dd00c081f8'}]}

        Attributes:
            count (int): The total number of inferences matching the query parameters
            inferences (list[ExternalInference]): List of inferences matching the search filters. Length is less than or
                equal to page_size parameter
     """

    count: int
    inferences: list[ExternalInference]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.external_inference import ExternalInference
        count = self.count

        inferences = []
        for inferences_item_data in self.inferences:
            inferences_item = inferences_item_data.to_dict()
            inferences.append(inferences_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "count": count,
            "inferences": inferences,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.external_inference import ExternalInference
        d = dict(src_dict)
        count = d.pop("count")

        inferences = []
        _inferences = d.pop("inferences")
        for inferences_item_data in (_inferences):
            inferences_item = ExternalInference.from_dict(inferences_item_data)



            inferences.append(inferences_item)


        query_inferences_response = cls(
            count=count,
            inferences=inferences,
        )


        query_inferences_response.additional_properties = d
        return query_inferences_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
