from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from uuid import UUID






T = TypeVar("T", bound="ContinuousEvalRerunResponse")



@_attrs_define
class ContinuousEvalRerunResponse:
    """ 
        Attributes:
            run_id (UUID): ID of the continuous eval run that was rerun.
            trace_id (str): ID of the trace that was rerun.
     """

    run_id: UUID
    trace_id: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        run_id = str(self.run_id)

        trace_id = self.trace_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "run_id": run_id,
            "trace_id": trace_id,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        run_id = UUID(d.pop("run_id"))




        trace_id = d.pop("trace_id")

        continuous_eval_rerun_response = cls(
            run_id=run_id,
            trace_id=trace_id,
        )


        continuous_eval_rerun_response.additional_properties = d
        return continuous_eval_rerun_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
