from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.api_key_rag_authentication_config_response import ApiKeyRagAuthenticationConfigResponse





T = TypeVar("T", bound="RagProviderConfigurationResponse")



@_attrs_define
class RagProviderConfigurationResponse:
    """ 
        Attributes:
            id (UUID): Unique identifier of the RAG provider configuration.
            task_id (str): ID of parent task.
            authentication_config (ApiKeyRagAuthenticationConfigResponse):
            name (str): Name of RAG provider configuration.
            created_at (int): Time the RAG provider configuration was created in unix milliseconds
            updated_at (int): Time the RAG provider configuration was updated in unix milliseconds
            description (None | str | Unset): Description of RAG provider configuration.
     """

    id: UUID
    task_id: str
    authentication_config: ApiKeyRagAuthenticationConfigResponse
    name: str
    created_at: int
    updated_at: int
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.api_key_rag_authentication_config_response import ApiKeyRagAuthenticationConfigResponse
        id = str(self.id)

        task_id = self.task_id

        authentication_config = self.authentication_config.to_dict()

        name = self.name

        created_at = self.created_at

        updated_at = self.updated_at

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "task_id": task_id,
            "authentication_config": authentication_config,
            "name": name,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.api_key_rag_authentication_config_response import ApiKeyRagAuthenticationConfigResponse
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        task_id = d.pop("task_id")

        authentication_config = ApiKeyRagAuthenticationConfigResponse.from_dict(d.pop("authentication_config"))




        name = d.pop("name")

        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        rag_provider_configuration_response = cls(
            id=id,
            task_id=task_id,
            authentication_config=authentication_config,
            name=name,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
        )


        rag_provider_configuration_response.additional_properties = d
        return rag_provider_configuration_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
