from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="EvalExecutionResult")



@_attrs_define
class EvalExecutionResult:
    """ Results from an eval execution

        Attributes:
            score (float): Score from the evaluation
            explanation (str): Explanation of the score
            cost (str): Cost of the evaluation
     """

    score: float
    explanation: str
    cost: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        score = self.score

        explanation = self.explanation

        cost = self.cost


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "score": score,
            "explanation": explanation,
            "cost": cost,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        score = d.pop("score")

        explanation = d.pop("explanation")

        cost = d.pop("cost")

        eval_execution_result = cls(
            score=score,
            explanation=explanation,
            cost=cost,
        )


        eval_execution_result.additional_properties = d
        return eval_execution_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
