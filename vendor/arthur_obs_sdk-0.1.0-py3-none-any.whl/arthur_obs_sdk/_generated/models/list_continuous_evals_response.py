from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.continuous_eval_response import ContinuousEvalResponse





T = TypeVar("T", bound="ListContinuousEvalsResponse")



@_attrs_define
class ListContinuousEvalsResponse:
    """ 
        Attributes:
            evals (list[ContinuousEvalResponse]): List of continuous evals.
            count (int): Total number of evals
     """

    evals: list[ContinuousEvalResponse]
    count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.continuous_eval_response import ContinuousEvalResponse
        evals = []
        for evals_item_data in self.evals:
            evals_item = evals_item_data.to_dict()
            evals.append(evals_item)



        count = self.count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "evals": evals,
            "count": count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.continuous_eval_response import ContinuousEvalResponse
        d = dict(src_dict)
        evals = []
        _evals = d.pop("evals")
        for evals_item_data in (_evals):
            evals_item = ContinuousEvalResponse.from_dict(evals_item_data)



            evals.append(evals_item)


        count = d.pop("count")

        list_continuous_evals_response = cls(
            evals=evals,
            count=count,
        )


        list_continuous_evals_response.additional_properties = d
        return list_continuous_evals_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
