from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.dataset_column_variable_source import DatasetColumnVariableSource





T = TypeVar("T", bound="SavedRagConfig")



@_attrs_define
class SavedRagConfig:
    """ Configuration for a saved RAG setting configuration version

        Attributes:
            setting_configuration_id (UUID): ID of the RAG search setting configuration
            version (int): Version of the RAG search setting configuration
            query_column (DatasetColumnVariableSource): Variable source from a dataset column
            type_ (Literal['saved'] | Unset):  Default: 'saved'.
     """

    setting_configuration_id: UUID
    version: int
    query_column: DatasetColumnVariableSource
    type_: Literal['saved'] | Unset = 'saved'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.dataset_column_variable_source import DatasetColumnVariableSource
        setting_configuration_id = str(self.setting_configuration_id)

        version = self.version

        query_column = self.query_column.to_dict()

        type_ = self.type_


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "setting_configuration_id": setting_configuration_id,
            "version": version,
            "query_column": query_column,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dataset_column_variable_source import DatasetColumnVariableSource
        d = dict(src_dict)
        setting_configuration_id = UUID(d.pop("setting_configuration_id"))




        version = d.pop("version")

        query_column = DatasetColumnVariableSource.from_dict(d.pop("query_column"))




        type_ = cast(Literal['saved'] | Unset , d.pop("type", UNSET))
        if type_ != 'saved'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'saved', got '{type_}'")

        saved_rag_config = cls(
            setting_configuration_id=setting_configuration_id,
            version=version,
            query_column=query_column,
            type_=type_,
        )


        saved_rag_config.additional_properties = d
        return saved_rag_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
