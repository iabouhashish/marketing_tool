from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.rule_result_enum import RuleResultEnum
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.external_rule_result import ExternalRuleResult





T = TypeVar("T", bound="ExternalInferenceResponse")



@_attrs_define
class ExternalInferenceResponse:
    """ 
        Attributes:
            id (str):
            inference_id (str):
            result (RuleResultEnum):
            created_at (int):
            updated_at (int):
            message (str):
            response_rule_results (list[ExternalRuleResult]):
            context (None | str | Unset):
            tokens (int | None | Unset):
            model_name (None | str | Unset): The model name and version used for this response (e.g., 'gpt-4',
                'gpt-3.5-turbo', 'claude-3-opus', 'gemini-pro').
     """

    id: str
    inference_id: str
    result: RuleResultEnum
    created_at: int
    updated_at: int
    message: str
    response_rule_results: list[ExternalRuleResult]
    context: None | str | Unset = UNSET
    tokens: int | None | Unset = UNSET
    model_name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.external_rule_result import ExternalRuleResult
        id = self.id

        inference_id = self.inference_id

        result = self.result.value

        created_at = self.created_at

        updated_at = self.updated_at

        message = self.message

        response_rule_results = []
        for response_rule_results_item_data in self.response_rule_results:
            response_rule_results_item = response_rule_results_item_data.to_dict()
            response_rule_results.append(response_rule_results_item)



        context: None | str | Unset
        if isinstance(self.context, Unset):
            context = UNSET
        else:
            context = self.context

        tokens: int | None | Unset
        if isinstance(self.tokens, Unset):
            tokens = UNSET
        else:
            tokens = self.tokens

        model_name: None | str | Unset
        if isinstance(self.model_name, Unset):
            model_name = UNSET
        else:
            model_name = self.model_name


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "inference_id": inference_id,
            "result": result,
            "created_at": created_at,
            "updated_at": updated_at,
            "message": message,
            "response_rule_results": response_rule_results,
        })
        if context is not UNSET:
            field_dict["context"] = context
        if tokens is not UNSET:
            field_dict["tokens"] = tokens
        if model_name is not UNSET:
            field_dict["model_name"] = model_name

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.external_rule_result import ExternalRuleResult
        d = dict(src_dict)
        id = d.pop("id")

        inference_id = d.pop("inference_id")

        result = RuleResultEnum(d.pop("result"))




        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        message = d.pop("message")

        response_rule_results = []
        _response_rule_results = d.pop("response_rule_results")
        for response_rule_results_item_data in (_response_rule_results):
            response_rule_results_item = ExternalRuleResult.from_dict(response_rule_results_item_data)



            response_rule_results.append(response_rule_results_item)


        def _parse_context(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        context = _parse_context(d.pop("context", UNSET))


        def _parse_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        tokens = _parse_tokens(d.pop("tokens", UNSET))


        def _parse_model_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model_name = _parse_model_name(d.pop("model_name", UNSET))


        external_inference_response = cls(
            id=id,
            inference_id=inference_id,
            result=result,
            created_at=created_at,
            updated_at=updated_at,
            message=message,
            response_rule_results=response_rule_results,
            context=context,
            tokens=tokens,
            model_name=model_name,
        )


        external_inference_response.additional_properties = d
        return external_inference_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
