from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.dataset_column_variable_source import DatasetColumnVariableSource
  from ..models.experiment_output_variable_source import ExperimentOutputVariableSource





T = TypeVar("T", bound="EvalVariableMapping")



@_attrs_define
class EvalVariableMapping:
    """ Mapping of an eval variable to its source (dataset column or experiment output)

        Attributes:
            variable_name (str): Name of the eval variable
            source (DatasetColumnVariableSource | ExperimentOutputVariableSource): Source of the variable value
     """

    variable_name: str
    source: DatasetColumnVariableSource | ExperimentOutputVariableSource
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.dataset_column_variable_source import DatasetColumnVariableSource
        from ..models.experiment_output_variable_source import ExperimentOutputVariableSource
        variable_name = self.variable_name

        source: dict[str, Any]
        if isinstance(self.source, DatasetColumnVariableSource):
            source = self.source.to_dict()
        else:
            source = self.source.to_dict()



        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "variable_name": variable_name,
            "source": source,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dataset_column_variable_source import DatasetColumnVariableSource
        from ..models.experiment_output_variable_source import ExperimentOutputVariableSource
        d = dict(src_dict)
        variable_name = d.pop("variable_name")

        def _parse_source(data: object) -> DatasetColumnVariableSource | ExperimentOutputVariableSource:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                source_type_0 = DatasetColumnVariableSource.from_dict(data)



                return source_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            source_type_1 = ExperimentOutputVariableSource.from_dict(data)



            return source_type_1

        source = _parse_source(d.pop("source"))


        eval_variable_mapping = cls(
            variable_name=variable_name,
            source=source,
        )


        eval_variable_mapping.additional_properties = d
        return eval_variable_mapping

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
