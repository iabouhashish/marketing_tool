from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.open_ai_message import OpenAIMessage





T = TypeVar("T", bound="UnsavedPromptVariablesRequest")



@_attrs_define
class UnsavedPromptVariablesRequest:
    """ Request schema for getting the list of variables needed from an unsaved prompt's messages

        Attributes:
            messages (list[OpenAIMessage]): List of chat messages in OpenAI format (e.g., [{'role': 'user', 'content':
                'Hello'}])
     """

    messages: list[OpenAIMessage]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.open_ai_message import OpenAIMessage
        messages = []
        for messages_item_data in self.messages:
            messages_item = messages_item_data.to_dict()
            messages.append(messages_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "messages": messages,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.open_ai_message import OpenAIMessage
        d = dict(src_dict)
        messages = []
        _messages = d.pop("messages")
        for messages_item_data in (_messages):
            messages_item = OpenAIMessage.from_dict(messages_item_data)



            messages.append(messages_item)


        unsaved_prompt_variables_request = cls(
            messages=messages,
        )


        unsaved_prompt_variables_request.additional_properties = d
        return unsaved_prompt_variables_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
