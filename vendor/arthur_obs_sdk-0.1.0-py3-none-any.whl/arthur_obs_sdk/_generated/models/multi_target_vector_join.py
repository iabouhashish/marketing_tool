from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.multi_target_vector_join_enum import MultiTargetVectorJoinEnum
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.multi_target_vector_join_weights_type_0 import MultiTargetVectorJoinWeightsType0





T = TypeVar("T", bound="MultiTargetVectorJoin")



@_attrs_define
class MultiTargetVectorJoin:
    """ 
        Attributes:
            combination (MultiTargetVectorJoinEnum): Define how multi target vector searches should be combined.
            target_vectors (list[str]):
            weights (MultiTargetVectorJoinWeightsType0 | None | Unset):
     """

    combination: MultiTargetVectorJoinEnum
    target_vectors: list[str]
    weights: MultiTargetVectorJoinWeightsType0 | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.multi_target_vector_join_weights_type_0 import MultiTargetVectorJoinWeightsType0
        combination = self.combination.value

        target_vectors = self.target_vectors



        weights: dict[str, Any] | None | Unset
        if isinstance(self.weights, Unset):
            weights = UNSET
        elif isinstance(self.weights, MultiTargetVectorJoinWeightsType0):
            weights = self.weights.to_dict()
        else:
            weights = self.weights


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "combination": combination,
            "target_vectors": target_vectors,
        })
        if weights is not UNSET:
            field_dict["weights"] = weights

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.multi_target_vector_join_weights_type_0 import MultiTargetVectorJoinWeightsType0
        d = dict(src_dict)
        combination = MultiTargetVectorJoinEnum(d.pop("combination"))




        target_vectors = cast(list[str], d.pop("target_vectors"))


        def _parse_weights(data: object) -> MultiTargetVectorJoinWeightsType0 | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                weights_type_0 = MultiTargetVectorJoinWeightsType0.from_dict(data)



                return weights_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(MultiTargetVectorJoinWeightsType0 | None | Unset, data)

        weights = _parse_weights(d.pop("weights", UNSET))


        multi_target_vector_join = cls(
            combination=combination,
            target_vectors=target_vectors,
            weights=weights,
        )


        multi_target_vector_join.additional_properties = d
        return multi_target_vector_join

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
