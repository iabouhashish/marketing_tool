from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="WeaviateQueryResultMetadata")



@_attrs_define
class WeaviateQueryResultMetadata:
    """ Metadata from weaviate for a vector object:
    https://weaviate-python-client.readthedocs.io/en/latest/weaviate.collections.classes.html#module-
    weaviate.collections.classes.internal

        Attributes:
            creation_time (datetime.datetime | None | Unset): Vector object creation time.
            last_update_time (datetime.datetime | None | Unset): Vector object last update time.
            distance (float | None | Unset): Raw distance metric used in the vector search. Lower values indicate closer
                vectors.
            certainty (float | None | Unset): Similarity score measure between 0 and 1. Higher values correspond to more
                similar reesults.
            score (float | None | Unset): Normalized relevance metric that ranks search results.
            explain_score (None | str | Unset): Explanation of how the score was calculated.
            is_consistent (bool | None | Unset): Indicates if the object is consistent across all replicates in a multi-node
                Weaviate cluster.
     """

    creation_time: datetime.datetime | None | Unset = UNSET
    last_update_time: datetime.datetime | None | Unset = UNSET
    distance: float | None | Unset = UNSET
    certainty: float | None | Unset = UNSET
    score: float | None | Unset = UNSET
    explain_score: None | str | Unset = UNSET
    is_consistent: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        creation_time: None | str | Unset
        if isinstance(self.creation_time, Unset):
            creation_time = UNSET
        elif isinstance(self.creation_time, datetime.datetime):
            creation_time = self.creation_time.isoformat()
        else:
            creation_time = self.creation_time

        last_update_time: None | str | Unset
        if isinstance(self.last_update_time, Unset):
            last_update_time = UNSET
        elif isinstance(self.last_update_time, datetime.datetime):
            last_update_time = self.last_update_time.isoformat()
        else:
            last_update_time = self.last_update_time

        distance: float | None | Unset
        if isinstance(self.distance, Unset):
            distance = UNSET
        else:
            distance = self.distance

        certainty: float | None | Unset
        if isinstance(self.certainty, Unset):
            certainty = UNSET
        else:
            certainty = self.certainty

        score: float | None | Unset
        if isinstance(self.score, Unset):
            score = UNSET
        else:
            score = self.score

        explain_score: None | str | Unset
        if isinstance(self.explain_score, Unset):
            explain_score = UNSET
        else:
            explain_score = self.explain_score

        is_consistent: bool | None | Unset
        if isinstance(self.is_consistent, Unset):
            is_consistent = UNSET
        else:
            is_consistent = self.is_consistent


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if creation_time is not UNSET:
            field_dict["creation_time"] = creation_time
        if last_update_time is not UNSET:
            field_dict["last_update_time"] = last_update_time
        if distance is not UNSET:
            field_dict["distance"] = distance
        if certainty is not UNSET:
            field_dict["certainty"] = certainty
        if score is not UNSET:
            field_dict["score"] = score
        if explain_score is not UNSET:
            field_dict["explain_score"] = explain_score
        if is_consistent is not UNSET:
            field_dict["is_consistent"] = is_consistent

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_creation_time(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                creation_time_type_0 = isoparse(data)



                return creation_time_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        creation_time = _parse_creation_time(d.pop("creation_time", UNSET))


        def _parse_last_update_time(data: object) -> datetime.datetime | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                last_update_time_type_0 = isoparse(data)



                return last_update_time_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(datetime.datetime | None | Unset, data)

        last_update_time = _parse_last_update_time(d.pop("last_update_time", UNSET))


        def _parse_distance(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        distance = _parse_distance(d.pop("distance", UNSET))


        def _parse_certainty(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        certainty = _parse_certainty(d.pop("certainty", UNSET))


        def _parse_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        score = _parse_score(d.pop("score", UNSET))


        def _parse_explain_score(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        explain_score = _parse_explain_score(d.pop("explain_score", UNSET))


        def _parse_is_consistent(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_consistent = _parse_is_consistent(d.pop("is_consistent", UNSET))


        weaviate_query_result_metadata = cls(
            creation_time=creation_time,
            last_update_time=last_update_time,
            distance=distance,
            certainty=certainty,
            score=score,
            explain_score=explain_score,
            is_consistent=is_consistent,
        )


        weaviate_query_result_metadata.additional_properties = d
        return weaviate_query_result_metadata

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
