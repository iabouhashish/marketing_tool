from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="TokenUsageCount")



@_attrs_define
class TokenUsageCount:
    """ 
        Attributes:
            inference (int): Number of inference tokens sent to Arthur.
            eval_prompt (int): Number of Prompt tokens incurred by Arthur rules.
            eval_completion (int): Number of Completion tokens incurred by Arthur rules.
            user_input (int): Number of user input tokens sent to Arthur. This field is deprecated and will be removed in
                the future. Use inference instead.
            prompt (int): Number of Prompt tokens incurred by Arthur rules. This field is deprecated and will be removed in
                the future. Use eval_prompt instead.
            completion (int): Number of Completion tokens incurred by Arthur rules. This field is deprecated and will be
                removed in the future. Use eval_completion instead.
     """

    inference: int
    eval_prompt: int
    eval_completion: int
    user_input: int
    prompt: int
    completion: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        inference = self.inference

        eval_prompt = self.eval_prompt

        eval_completion = self.eval_completion

        user_input = self.user_input

        prompt = self.prompt

        completion = self.completion


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "inference": inference,
            "eval_prompt": eval_prompt,
            "eval_completion": eval_completion,
            "user_input": user_input,
            "prompt": prompt,
            "completion": completion,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        inference = d.pop("inference")

        eval_prompt = d.pop("eval_prompt")

        eval_completion = d.pop("eval_completion")

        user_input = d.pop("user_input")

        prompt = d.pop("prompt")

        completion = d.pop("completion")

        token_usage_count = cls(
            inference=inference,
            eval_prompt=eval_prompt,
            eval_completion=eval_completion,
            user_input=user_input,
            prompt=prompt,
            completion=completion,
        )


        token_usage_count.additional_properties = d
        return token_usage_count

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
