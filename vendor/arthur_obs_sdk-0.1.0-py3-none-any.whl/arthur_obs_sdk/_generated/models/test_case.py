from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.test_case_status import TestCaseStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.prompt_result import PromptResult
  from ..models.input_variable import InputVariable





T = TypeVar("T", bound="TestCase")



@_attrs_define
class TestCase:
    """ Individual test case result

        Attributes:
            status (TestCaseStatus): Status of a test case
            dataset_row_id (str): ID of the dataset row
            prompt_input_variables (list[InputVariable]): Input variables for the prompt
            prompt_results (list[PromptResult]): Results for each prompt version tested
            total_cost (None | str | Unset): Total cost for this test case
     """

    status: TestCaseStatus
    dataset_row_id: str
    prompt_input_variables: list[InputVariable]
    prompt_results: list[PromptResult]
    total_cost: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.prompt_result import PromptResult
        from ..models.input_variable import InputVariable
        status = self.status.value

        dataset_row_id = self.dataset_row_id

        prompt_input_variables = []
        for prompt_input_variables_item_data in self.prompt_input_variables:
            prompt_input_variables_item = prompt_input_variables_item_data.to_dict()
            prompt_input_variables.append(prompt_input_variables_item)



        prompt_results = []
        for prompt_results_item_data in self.prompt_results:
            prompt_results_item = prompt_results_item_data.to_dict()
            prompt_results.append(prompt_results_item)



        total_cost: None | str | Unset
        if isinstance(self.total_cost, Unset):
            total_cost = UNSET
        else:
            total_cost = self.total_cost


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
            "dataset_row_id": dataset_row_id,
            "prompt_input_variables": prompt_input_variables,
            "prompt_results": prompt_results,
        })
        if total_cost is not UNSET:
            field_dict["total_cost"] = total_cost

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.prompt_result import PromptResult
        from ..models.input_variable import InputVariable
        d = dict(src_dict)
        status = TestCaseStatus(d.pop("status"))




        dataset_row_id = d.pop("dataset_row_id")

        prompt_input_variables = []
        _prompt_input_variables = d.pop("prompt_input_variables")
        for prompt_input_variables_item_data in (_prompt_input_variables):
            prompt_input_variables_item = InputVariable.from_dict(prompt_input_variables_item_data)



            prompt_input_variables.append(prompt_input_variables_item)


        prompt_results = []
        _prompt_results = d.pop("prompt_results")
        for prompt_results_item_data in (_prompt_results):
            prompt_results_item = PromptResult.from_dict(prompt_results_item_data)



            prompt_results.append(prompt_results_item)


        def _parse_total_cost(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        total_cost = _parse_total_cost(d.pop("total_cost", UNSET))


        test_case = cls(
            status=status,
            dataset_row_id=dataset_row_id,
            prompt_input_variables=prompt_input_variables,
            prompt_results=prompt_results,
            total_cost=total_cost,
        )


        test_case.additional_properties = d
        return test_case

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
