from enum import Enum

class TestCaseStatus(str, Enum):
    COMPLETED = "completed"
    EVALUATING = "evaluating"
    FAILED = "failed"
    QUEUED = "queued"
    RUNNING = "running"

    def __str__(self) -> str:
        return str(self.value)
