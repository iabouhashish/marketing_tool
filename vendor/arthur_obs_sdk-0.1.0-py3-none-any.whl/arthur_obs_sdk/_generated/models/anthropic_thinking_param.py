from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import Literal, cast






T = TypeVar("T", bound="AnthropicThinkingParam")



@_attrs_define
class AnthropicThinkingParam:
    """ 
        Attributes:
            type_ (Literal['enabled'] | Unset):
            budget_tokens (int | Unset):
     """

    type_: Literal['enabled'] | Unset = UNSET
    budget_tokens: int | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        type_ = self.type_

        budget_tokens = self.budget_tokens


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if budget_tokens is not UNSET:
            field_dict["budget_tokens"] = budget_tokens

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        type_ = cast(Literal['enabled'] | Unset , d.pop("type", UNSET))
        if type_ != 'enabled'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'enabled', got '{type_}'")

        budget_tokens = d.pop("budget_tokens", UNSET)

        anthropic_thinking_param = cls(
            type_=type_,
            budget_tokens=budget_tokens,
        )


        anthropic_thinking_param.additional_properties = d
        return anthropic_thinking_param

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
