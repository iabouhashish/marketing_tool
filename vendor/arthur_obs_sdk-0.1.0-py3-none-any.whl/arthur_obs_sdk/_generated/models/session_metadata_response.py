from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime






T = TypeVar("T", bound="SessionMetadataResponse")



@_attrs_define
class SessionMetadataResponse:
    """ Session summary metadata

        Attributes:
            session_id (str): Session identifier
            task_id (str): Task ID this session belongs to
            trace_ids (list[str]): List of trace IDs in this session
            trace_count (int): Number of traces in this session
            span_count (int): Total number of spans in this session
            earliest_start_time (datetime.datetime): Start time of earliest trace
            latest_end_time (datetime.datetime): End time of latest trace
            duration_ms (float): Total session duration in milliseconds
            prompt_token_count (int | None | Unset): Number of prompt tokens
            completion_token_count (int | None | Unset): Number of completion tokens
            total_token_count (int | None | Unset): Total number of tokens
            prompt_token_cost (float | None | Unset): Cost of prompt tokens in USD
            completion_token_cost (float | None | Unset): Cost of completion tokens in USD
            total_token_cost (float | None | Unset): Total cost in USD
            user_id (None | str | Unset): User ID if available
     """

    session_id: str
    task_id: str
    trace_ids: list[str]
    trace_count: int
    span_count: int
    earliest_start_time: datetime.datetime
    latest_end_time: datetime.datetime
    duration_ms: float
    prompt_token_count: int | None | Unset = UNSET
    completion_token_count: int | None | Unset = UNSET
    total_token_count: int | None | Unset = UNSET
    prompt_token_cost: float | None | Unset = UNSET
    completion_token_cost: float | None | Unset = UNSET
    total_token_cost: float | None | Unset = UNSET
    user_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        session_id = self.session_id

        task_id = self.task_id

        trace_ids = self.trace_ids



        trace_count = self.trace_count

        span_count = self.span_count

        earliest_start_time = self.earliest_start_time.isoformat()

        latest_end_time = self.latest_end_time.isoformat()

        duration_ms = self.duration_ms

        prompt_token_count: int | None | Unset
        if isinstance(self.prompt_token_count, Unset):
            prompt_token_count = UNSET
        else:
            prompt_token_count = self.prompt_token_count

        completion_token_count: int | None | Unset
        if isinstance(self.completion_token_count, Unset):
            completion_token_count = UNSET
        else:
            completion_token_count = self.completion_token_count

        total_token_count: int | None | Unset
        if isinstance(self.total_token_count, Unset):
            total_token_count = UNSET
        else:
            total_token_count = self.total_token_count

        prompt_token_cost: float | None | Unset
        if isinstance(self.prompt_token_cost, Unset):
            prompt_token_cost = UNSET
        else:
            prompt_token_cost = self.prompt_token_cost

        completion_token_cost: float | None | Unset
        if isinstance(self.completion_token_cost, Unset):
            completion_token_cost = UNSET
        else:
            completion_token_cost = self.completion_token_cost

        total_token_cost: float | None | Unset
        if isinstance(self.total_token_cost, Unset):
            total_token_cost = UNSET
        else:
            total_token_cost = self.total_token_cost

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "session_id": session_id,
            "task_id": task_id,
            "trace_ids": trace_ids,
            "trace_count": trace_count,
            "span_count": span_count,
            "earliest_start_time": earliest_start_time,
            "latest_end_time": latest_end_time,
            "duration_ms": duration_ms,
        })
        if prompt_token_count is not UNSET:
            field_dict["prompt_token_count"] = prompt_token_count
        if completion_token_count is not UNSET:
            field_dict["completion_token_count"] = completion_token_count
        if total_token_count is not UNSET:
            field_dict["total_token_count"] = total_token_count
        if prompt_token_cost is not UNSET:
            field_dict["prompt_token_cost"] = prompt_token_cost
        if completion_token_cost is not UNSET:
            field_dict["completion_token_cost"] = completion_token_cost
        if total_token_cost is not UNSET:
            field_dict["total_token_cost"] = total_token_cost
        if user_id is not UNSET:
            field_dict["user_id"] = user_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        session_id = d.pop("session_id")

        task_id = d.pop("task_id")

        trace_ids = cast(list[str], d.pop("trace_ids"))


        trace_count = d.pop("trace_count")

        span_count = d.pop("span_count")

        earliest_start_time = isoparse(d.pop("earliest_start_time"))




        latest_end_time = isoparse(d.pop("latest_end_time"))




        duration_ms = d.pop("duration_ms")

        def _parse_prompt_token_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        prompt_token_count = _parse_prompt_token_count(d.pop("prompt_token_count", UNSET))


        def _parse_completion_token_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        completion_token_count = _parse_completion_token_count(d.pop("completion_token_count", UNSET))


        def _parse_total_token_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_token_count = _parse_total_token_count(d.pop("total_token_count", UNSET))


        def _parse_prompt_token_cost(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        prompt_token_cost = _parse_prompt_token_cost(d.pop("prompt_token_cost", UNSET))


        def _parse_completion_token_cost(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        completion_token_cost = _parse_completion_token_cost(d.pop("completion_token_cost", UNSET))


        def _parse_total_token_cost(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        total_token_cost = _parse_total_token_cost(d.pop("total_token_cost", UNSET))


        def _parse_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_id = _parse_user_id(d.pop("user_id", UNSET))


        session_metadata_response = cls(
            session_id=session_id,
            task_id=task_id,
            trace_ids=trace_ids,
            trace_count=trace_count,
            span_count=span_count,
            earliest_start_time=earliest_start_time,
            latest_end_time=latest_end_time,
            duration_ms=duration_ms,
            prompt_token_count=prompt_token_count,
            completion_token_count=completion_token_count,
            total_token_count=total_token_count,
            prompt_token_cost=prompt_token_cost,
            completion_token_cost=completion_token_cost,
            total_token_cost=total_token_cost,
            user_id=user_id,
        )


        session_metadata_response.additional_properties = d
        return session_metadata_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
