from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.inference_feedback_response import InferenceFeedbackResponse





T = TypeVar("T", bound="QueryFeedbackResponse")



@_attrs_define
class QueryFeedbackResponse:
    """ 
        Example:
            {'feedback': [{'created_at': '2024-06-06T06:37:46.123-04:00', 'id': '90f18c69-d793-4913-9bde-a0c7f3643de0',
                'inference_id': '81437d71-9557-4611-981b-9283d1c98643', 'reason': 'good reason', 'score': '0', 'target':
                'context', 'updated_at': '2024-06-06T06:37:46.123-04:00', 'user_id': 'user_1'}, {'created_at':
                '2023-05-05T05:26:35.987-04:00', 'id': '248381c2-543b-4de0-98cd-d7511fee6241', 'inference_id':
                'bcbc7ca0-4cfc-4f67-9cf8-26cb2291ba33', 'reason': 'some reason', 'score': '1', 'target': 'response_results',
                'updated_at': '2023-05-05T05:26:35.987-04:00', 'user_id': 'user_2'}], 'page': 1, 'page_size': 10, 'total_count':
                2, 'total_pages': 1}

        Attributes:
            feedback (list[InferenceFeedbackResponse]): List of inferences matching the search filters. Length is less than
                or equal to page_size parameter
            page (int): The current page number
            page_size (int): The number of feedback items per page
            total_pages (int): The total number of pages
            total_count (int): The total number of feedback items matching the query parameters
     """

    feedback: list[InferenceFeedbackResponse]
    page: int
    page_size: int
    total_pages: int
    total_count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.inference_feedback_response import InferenceFeedbackResponse
        feedback = []
        for feedback_item_data in self.feedback:
            feedback_item = feedback_item_data.to_dict()
            feedback.append(feedback_item)



        page = self.page

        page_size = self.page_size

        total_pages = self.total_pages

        total_count = self.total_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "feedback": feedback,
            "page": page,
            "page_size": page_size,
            "total_pages": total_pages,
            "total_count": total_count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.inference_feedback_response import InferenceFeedbackResponse
        d = dict(src_dict)
        feedback = []
        _feedback = d.pop("feedback")
        for feedback_item_data in (_feedback):
            feedback_item = InferenceFeedbackResponse.from_dict(feedback_item_data)



            feedback.append(feedback_item)


        page = d.pop("page")

        page_size = d.pop("page_size")

        total_pages = d.pop("total_pages")

        total_count = d.pop("total_count")

        query_feedback_response = cls(
            feedback=feedback,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
            total_count=total_count,
        )


        query_feedback_response.additional_properties = d
        return query_feedback_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
