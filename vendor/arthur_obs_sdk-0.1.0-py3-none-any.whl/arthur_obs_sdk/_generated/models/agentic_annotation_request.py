from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="AgenticAnnotationRequest")



@_attrs_define
class AgenticAnnotationRequest:
    """ 
        Attributes:
            annotation_score (int): Binary score for whether a traces has been liked or disliked (0 = disliked, 1 = liked)
            annotation_description (None | str | Unset): Description of the annotation
     """

    annotation_score: int
    annotation_description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        annotation_score = self.annotation_score

        annotation_description: None | str | Unset
        if isinstance(self.annotation_description, Unset):
            annotation_description = UNSET
        else:
            annotation_description = self.annotation_description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "annotation_score": annotation_score,
        })
        if annotation_description is not UNSET:
            field_dict["annotation_description"] = annotation_description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        annotation_score = d.pop("annotation_score")

        def _parse_annotation_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        annotation_description = _parse_annotation_description(d.pop("annotation_description", UNSET))


        agentic_annotation_request = cls(
            annotation_score=annotation_score,
            annotation_description=annotation_description,
        )


        agentic_annotation_request.additional_properties = d
        return agentic_annotation_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
