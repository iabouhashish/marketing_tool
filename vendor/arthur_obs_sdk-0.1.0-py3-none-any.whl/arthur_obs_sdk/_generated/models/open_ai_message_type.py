from enum import Enum

class OpenAIMessageType(str, Enum):
    IMAGE_URL = "image_url"
    INPUT_AUDIO = "input_audio"
    TEXT = "text"

    def __str__(self) -> str:
        return str(self.value)
