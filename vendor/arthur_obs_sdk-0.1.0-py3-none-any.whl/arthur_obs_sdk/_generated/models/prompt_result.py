from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.eval_execution import EvalExecution
  from ..models.prompt_output import PromptOutput





T = TypeVar("T", bound="PromptResult")



@_attrs_define
class PromptResult:
    """ Results from a prompt execution with evals

        Attributes:
            evals (list[EvalExecution]): Evaluation results for this execution
            prompt_key (str): Prompt key: 'saved:name:version' or 'unsaved:auto_name'
            prompt_type (str): Type: 'saved' or 'unsaved'
            rendered_prompt (str): Prompt with variables replaced
            name (None | str | Unset): Name of the prompt (for saved prompts)
            version (None | str | Unset): Version of the prompt (for saved prompts)
            output (None | PromptOutput | Unset): Output from the prompt (None if not yet executed)
     """

    evals: list[EvalExecution]
    prompt_key: str
    prompt_type: str
    rendered_prompt: str
    name: None | str | Unset = UNSET
    version: None | str | Unset = UNSET
    output: None | PromptOutput | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.eval_execution import EvalExecution
        from ..models.prompt_output import PromptOutput
        evals = []
        for evals_item_data in self.evals:
            evals_item = evals_item_data.to_dict()
            evals.append(evals_item)



        prompt_key = self.prompt_key

        prompt_type = self.prompt_type

        rendered_prompt = self.rendered_prompt

        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        version: None | str | Unset
        if isinstance(self.version, Unset):
            version = UNSET
        else:
            version = self.version

        output: dict[str, Any] | None | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        elif isinstance(self.output, PromptOutput):
            output = self.output.to_dict()
        else:
            output = self.output


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "evals": evals,
            "prompt_key": prompt_key,
            "prompt_type": prompt_type,
            "rendered_prompt": rendered_prompt,
        })
        if name is not UNSET:
            field_dict["name"] = name
        if version is not UNSET:
            field_dict["version"] = version
        if output is not UNSET:
            field_dict["output"] = output

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.eval_execution import EvalExecution
        from ..models.prompt_output import PromptOutput
        d = dict(src_dict)
        evals = []
        _evals = d.pop("evals")
        for evals_item_data in (_evals):
            evals_item = EvalExecution.from_dict(evals_item_data)



            evals.append(evals_item)


        prompt_key = d.pop("prompt_key")

        prompt_type = d.pop("prompt_type")

        rendered_prompt = d.pop("rendered_prompt")

        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))


        def _parse_version(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        version = _parse_version(d.pop("version", UNSET))


        def _parse_output(data: object) -> None | PromptOutput | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                output_type_0 = PromptOutput.from_dict(data)



                return output_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PromptOutput | Unset, data)

        output = _parse_output(d.pop("output", UNSET))


        prompt_result = cls(
            evals=evals,
            prompt_key=prompt_key,
            prompt_type=prompt_type,
            rendered_prompt=rendered_prompt,
            name=name,
            version=version,
            output=output,
        )


        prompt_result.additional_properties = d
        return prompt_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
