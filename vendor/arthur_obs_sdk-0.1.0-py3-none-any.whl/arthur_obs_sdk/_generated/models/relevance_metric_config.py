from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="RelevanceMetricConfig")



@_attrs_define
class RelevanceMetricConfig:
    """ Configuration for relevance metrics including QueryRelevance and ResponseRelevance

        Attributes:
            relevance_threshold (float | None | Unset): Threshold for determining relevance when not using LLM judge
            use_llm_judge (bool | Unset): Whether to use LLM as a judge for relevance scoring Default: True.
     """

    relevance_threshold: float | None | Unset = UNSET
    use_llm_judge: bool | Unset = True
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        relevance_threshold: float | None | Unset
        if isinstance(self.relevance_threshold, Unset):
            relevance_threshold = UNSET
        else:
            relevance_threshold = self.relevance_threshold

        use_llm_judge = self.use_llm_judge


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if relevance_threshold is not UNSET:
            field_dict["relevance_threshold"] = relevance_threshold
        if use_llm_judge is not UNSET:
            field_dict["use_llm_judge"] = use_llm_judge

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_relevance_threshold(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        relevance_threshold = _parse_relevance_threshold(d.pop("relevance_threshold", UNSET))


        use_llm_judge = d.pop("use_llm_judge", UNSET)

        relevance_metric_config = cls(
            relevance_threshold=relevance_threshold,
            use_llm_judge=use_llm_judge,
        )


        relevance_metric_config.additional_properties = d
        return relevance_metric_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
