from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.rule_result_enum import RuleResultEnum
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.external_rule_result import ExternalRuleResult





T = TypeVar("T", bound="ExternalInferencePrompt")



@_attrs_define
class ExternalInferencePrompt:
    """ 
        Attributes:
            id (str):
            inference_id (str):
            result (RuleResultEnum):
            created_at (int):
            updated_at (int):
            message (str):
            prompt_rule_results (list[ExternalRuleResult]):
            tokens (int | None | Unset):
     """

    id: str
    inference_id: str
    result: RuleResultEnum
    created_at: int
    updated_at: int
    message: str
    prompt_rule_results: list[ExternalRuleResult]
    tokens: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.external_rule_result import ExternalRuleResult
        id = self.id

        inference_id = self.inference_id

        result = self.result.value

        created_at = self.created_at

        updated_at = self.updated_at

        message = self.message

        prompt_rule_results = []
        for prompt_rule_results_item_data in self.prompt_rule_results:
            prompt_rule_results_item = prompt_rule_results_item_data.to_dict()
            prompt_rule_results.append(prompt_rule_results_item)



        tokens: int | None | Unset
        if isinstance(self.tokens, Unset):
            tokens = UNSET
        else:
            tokens = self.tokens


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "inference_id": inference_id,
            "result": result,
            "created_at": created_at,
            "updated_at": updated_at,
            "message": message,
            "prompt_rule_results": prompt_rule_results,
        })
        if tokens is not UNSET:
            field_dict["tokens"] = tokens

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.external_rule_result import ExternalRuleResult
        d = dict(src_dict)
        id = d.pop("id")

        inference_id = d.pop("inference_id")

        result = RuleResultEnum(d.pop("result"))




        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        message = d.pop("message")

        prompt_rule_results = []
        _prompt_rule_results = d.pop("prompt_rule_results")
        for prompt_rule_results_item_data in (_prompt_rule_results):
            prompt_rule_results_item = ExternalRuleResult.from_dict(prompt_rule_results_item_data)



            prompt_rule_results.append(prompt_rule_results_item)


        def _parse_tokens(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        tokens = _parse_tokens(d.pop("tokens", UNSET))


        external_inference_prompt = cls(
            id=id,
            inference_id=inference_id,
            result=result,
            created_at=created_at,
            updated_at=updated_at,
            message=message,
            prompt_rule_results=prompt_rule_results,
            tokens=tokens,
        )


        external_inference_prompt.additional_properties = d
        return external_inference_prompt

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
