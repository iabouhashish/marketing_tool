from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.rule_scope import RuleScope
from ..models.rule_type import RuleType
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="SearchRulesRequest")



@_attrs_define
class SearchRulesRequest:
    """ 
        Attributes:
            rule_ids (list[str] | None | Unset): List of rule IDs to search for.
            rule_scopes (list[RuleScope] | None | Unset): List of rule scopes to search for.
            prompt_enabled (bool | None | Unset): Include or exclude prompt-enabled rules.
            response_enabled (bool | None | Unset): Include or exclude response-enabled rules.
            rule_types (list[RuleType] | None | Unset): List of rule types to search for.
     """

    rule_ids: list[str] | None | Unset = UNSET
    rule_scopes: list[RuleScope] | None | Unset = UNSET
    prompt_enabled: bool | None | Unset = UNSET
    response_enabled: bool | None | Unset = UNSET
    rule_types: list[RuleType] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        rule_ids: list[str] | None | Unset
        if isinstance(self.rule_ids, Unset):
            rule_ids = UNSET
        elif isinstance(self.rule_ids, list):
            rule_ids = self.rule_ids


        else:
            rule_ids = self.rule_ids

        rule_scopes: list[str] | None | Unset
        if isinstance(self.rule_scopes, Unset):
            rule_scopes = UNSET
        elif isinstance(self.rule_scopes, list):
            rule_scopes = []
            for rule_scopes_type_0_item_data in self.rule_scopes:
                rule_scopes_type_0_item = rule_scopes_type_0_item_data.value
                rule_scopes.append(rule_scopes_type_0_item)


        else:
            rule_scopes = self.rule_scopes

        prompt_enabled: bool | None | Unset
        if isinstance(self.prompt_enabled, Unset):
            prompt_enabled = UNSET
        else:
            prompt_enabled = self.prompt_enabled

        response_enabled: bool | None | Unset
        if isinstance(self.response_enabled, Unset):
            response_enabled = UNSET
        else:
            response_enabled = self.response_enabled

        rule_types: list[str] | None | Unset
        if isinstance(self.rule_types, Unset):
            rule_types = UNSET
        elif isinstance(self.rule_types, list):
            rule_types = []
            for rule_types_type_0_item_data in self.rule_types:
                rule_types_type_0_item = rule_types_type_0_item_data.value
                rule_types.append(rule_types_type_0_item)


        else:
            rule_types = self.rule_types


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if rule_ids is not UNSET:
            field_dict["rule_ids"] = rule_ids
        if rule_scopes is not UNSET:
            field_dict["rule_scopes"] = rule_scopes
        if prompt_enabled is not UNSET:
            field_dict["prompt_enabled"] = prompt_enabled
        if response_enabled is not UNSET:
            field_dict["response_enabled"] = response_enabled
        if rule_types is not UNSET:
            field_dict["rule_types"] = rule_types

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_rule_ids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                rule_ids_type_0 = cast(list[str], data)

                return rule_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        rule_ids = _parse_rule_ids(d.pop("rule_ids", UNSET))


        def _parse_rule_scopes(data: object) -> list[RuleScope] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                rule_scopes_type_0 = []
                _rule_scopes_type_0 = data
                for rule_scopes_type_0_item_data in (_rule_scopes_type_0):
                    rule_scopes_type_0_item = RuleScope(rule_scopes_type_0_item_data)



                    rule_scopes_type_0.append(rule_scopes_type_0_item)

                return rule_scopes_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[RuleScope] | None | Unset, data)

        rule_scopes = _parse_rule_scopes(d.pop("rule_scopes", UNSET))


        def _parse_prompt_enabled(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        prompt_enabled = _parse_prompt_enabled(d.pop("prompt_enabled", UNSET))


        def _parse_response_enabled(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        response_enabled = _parse_response_enabled(d.pop("response_enabled", UNSET))


        def _parse_rule_types(data: object) -> list[RuleType] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                rule_types_type_0 = []
                _rule_types_type_0 = data
                for rule_types_type_0_item_data in (_rule_types_type_0):
                    rule_types_type_0_item = RuleType(rule_types_type_0_item_data)



                    rule_types_type_0.append(rule_types_type_0_item)

                return rule_types_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[RuleType] | None | Unset, data)

        rule_types = _parse_rule_types(d.pop("rule_types", UNSET))


        search_rules_request = cls(
            rule_ids=rule_ids,
            rule_scopes=rule_scopes,
            prompt_enabled=prompt_enabled,
            response_enabled=response_enabled,
            rule_types=rule_types,
        )


        search_rules_request.additional_properties = d
        return search_rules_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
