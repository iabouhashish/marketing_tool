from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.agentic_prompt_version_response import AgenticPromptVersionResponse





T = TypeVar("T", bound="AgenticPromptVersionListResponse")



@_attrs_define
class AgenticPromptVersionListResponse:
    """ 
        Attributes:
            versions (list[AgenticPromptVersionResponse]): List of prompt version metadata
            count (int): Total number of prompts matching filters
     """

    versions: list[AgenticPromptVersionResponse]
    count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.agentic_prompt_version_response import AgenticPromptVersionResponse
        versions = []
        for versions_item_data in self.versions:
            versions_item = versions_item_data.to_dict()
            versions.append(versions_item)



        count = self.count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "versions": versions,
            "count": count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.agentic_prompt_version_response import AgenticPromptVersionResponse
        d = dict(src_dict)
        versions = []
        _versions = d.pop("versions")
        for versions_item_data in (_versions):
            versions_item = AgenticPromptVersionResponse.from_dict(versions_item_data)



            versions.append(versions_item)


        count = d.pop("count")

        agentic_prompt_version_list_response = cls(
            versions=versions,
            count=count,
        )


        agentic_prompt_version_list_response.additional_properties = d
        return agentic_prompt_version_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
