from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.eval_execution import EvalExecution
  from ..models.rag_search_output import RagSearchOutput





T = TypeVar("T", bound="RagResult")



@_attrs_define
class RagResult:
    """ Results from a RAG search execution with evals

        Attributes:
            evals (list[EvalExecution]): Evaluation results for this execution
            rag_config_key (str): RAG config key: 'saved:setting_config_id:version' for saved, 'unsaved:uuid' for unsaved
            rag_config_type (str): Type: 'saved' or 'unsaved'
            query_text (str): Query text used for the search
            setting_configuration_id (None | Unset | UUID): ID of the RAG search setting configuration (for saved configs
                only)
            setting_configuration_version (int | None | Unset): Version of the RAG search setting configuration (for saved
                configs only)
            output (None | RagSearchOutput | Unset): Output from the RAG search (None if not yet executed)
     """

    evals: list[EvalExecution]
    rag_config_key: str
    rag_config_type: str
    query_text: str
    setting_configuration_id: None | Unset | UUID = UNSET
    setting_configuration_version: int | None | Unset = UNSET
    output: None | RagSearchOutput | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.eval_execution import EvalExecution
        from ..models.rag_search_output import RagSearchOutput
        evals = []
        for evals_item_data in self.evals:
            evals_item = evals_item_data.to_dict()
            evals.append(evals_item)



        rag_config_key = self.rag_config_key

        rag_config_type = self.rag_config_type

        query_text = self.query_text

        setting_configuration_id: None | str | Unset
        if isinstance(self.setting_configuration_id, Unset):
            setting_configuration_id = UNSET
        elif isinstance(self.setting_configuration_id, UUID):
            setting_configuration_id = str(self.setting_configuration_id)
        else:
            setting_configuration_id = self.setting_configuration_id

        setting_configuration_version: int | None | Unset
        if isinstance(self.setting_configuration_version, Unset):
            setting_configuration_version = UNSET
        else:
            setting_configuration_version = self.setting_configuration_version

        output: dict[str, Any] | None | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        elif isinstance(self.output, RagSearchOutput):
            output = self.output.to_dict()
        else:
            output = self.output


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "evals": evals,
            "rag_config_key": rag_config_key,
            "rag_config_type": rag_config_type,
            "query_text": query_text,
        })
        if setting_configuration_id is not UNSET:
            field_dict["setting_configuration_id"] = setting_configuration_id
        if setting_configuration_version is not UNSET:
            field_dict["setting_configuration_version"] = setting_configuration_version
        if output is not UNSET:
            field_dict["output"] = output

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.eval_execution import EvalExecution
        from ..models.rag_search_output import RagSearchOutput
        d = dict(src_dict)
        evals = []
        _evals = d.pop("evals")
        for evals_item_data in (_evals):
            evals_item = EvalExecution.from_dict(evals_item_data)



            evals.append(evals_item)


        rag_config_key = d.pop("rag_config_key")

        rag_config_type = d.pop("rag_config_type")

        query_text = d.pop("query_text")

        def _parse_setting_configuration_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                setting_configuration_id_type_0 = UUID(data)



                return setting_configuration_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        setting_configuration_id = _parse_setting_configuration_id(d.pop("setting_configuration_id", UNSET))


        def _parse_setting_configuration_version(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        setting_configuration_version = _parse_setting_configuration_version(d.pop("setting_configuration_version", UNSET))


        def _parse_output(data: object) -> None | RagSearchOutput | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                output_type_0 = RagSearchOutput.from_dict(data)



                return output_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RagSearchOutput | Unset, data)

        output = _parse_output(d.pop("output", UNSET))


        rag_result = cls(
            evals=evals,
            rag_config_key=rag_config_key,
            rag_config_type=rag_config_type,
            query_text=query_text,
            setting_configuration_id=setting_configuration_id,
            setting_configuration_version=setting_configuration_version,
            output=output,
        )


        rag_result.additional_properties = d
        return rag_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
