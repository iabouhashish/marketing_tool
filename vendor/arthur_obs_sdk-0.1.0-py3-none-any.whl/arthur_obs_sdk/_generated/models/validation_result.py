from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.external_rule_result import ExternalRuleResult





T = TypeVar("T", bound="ValidationResult")



@_attrs_define
class ValidationResult:
    """ 
        Example:
            {'inference_id': '4dd1fae1-34b9-4aec-8abe-fe7bf12af31d', 'rule_results': [{'id':
                '90f18c69-d793-4913-9bde-a0c7f3643de0', 'name': 'PII Check', 'result': 'Pass'}, {'id':
                '946c4a44-b367-4229-84d4-1a8e461cb132', 'name': 'Sensitive Data Check', 'result': 'Pass'}]}

        Attributes:
            inference_id (None | str | Unset): ID of the inference
            rule_results (list[ExternalRuleResult] | None | Unset): List of rule results
            user_id (None | str | Unset): The user ID this prompt belongs to
            model_name (None | str | Unset): The model name and version used for this validation (e.g., 'gpt-4',
                'gpt-3.5-turbo', 'claude-3-opus', 'gemini-pro').
     """

    inference_id: None | str | Unset = UNSET
    rule_results: list[ExternalRuleResult] | None | Unset = UNSET
    user_id: None | str | Unset = UNSET
    model_name: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.external_rule_result import ExternalRuleResult
        inference_id: None | str | Unset
        if isinstance(self.inference_id, Unset):
            inference_id = UNSET
        else:
            inference_id = self.inference_id

        rule_results: list[dict[str, Any]] | None | Unset
        if isinstance(self.rule_results, Unset):
            rule_results = UNSET
        elif isinstance(self.rule_results, list):
            rule_results = []
            for rule_results_type_0_item_data in self.rule_results:
                rule_results_type_0_item = rule_results_type_0_item_data.to_dict()
                rule_results.append(rule_results_type_0_item)


        else:
            rule_results = self.rule_results

        user_id: None | str | Unset
        if isinstance(self.user_id, Unset):
            user_id = UNSET
        else:
            user_id = self.user_id

        model_name: None | str | Unset
        if isinstance(self.model_name, Unset):
            model_name = UNSET
        else:
            model_name = self.model_name


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if inference_id is not UNSET:
            field_dict["inference_id"] = inference_id
        if rule_results is not UNSET:
            field_dict["rule_results"] = rule_results
        if user_id is not UNSET:
            field_dict["user_id"] = user_id
        if model_name is not UNSET:
            field_dict["model_name"] = model_name

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.external_rule_result import ExternalRuleResult
        d = dict(src_dict)
        def _parse_inference_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        inference_id = _parse_inference_id(d.pop("inference_id", UNSET))


        def _parse_rule_results(data: object) -> list[ExternalRuleResult] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                rule_results_type_0 = []
                _rule_results_type_0 = data
                for rule_results_type_0_item_data in (_rule_results_type_0):
                    rule_results_type_0_item = ExternalRuleResult.from_dict(rule_results_type_0_item_data)



                    rule_results_type_0.append(rule_results_type_0_item)

                return rule_results_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[ExternalRuleResult] | None | Unset, data)

        rule_results = _parse_rule_results(d.pop("rule_results", UNSET))


        def _parse_user_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        user_id = _parse_user_id(d.pop("user_id", UNSET))


        def _parse_model_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        model_name = _parse_model_name(d.pop("model_name", UNSET))


        validation_result = cls(
            inference_id=inference_id,
            rule_results=rule_results,
            user_id=user_id,
            model_name=model_name,
        )


        validation_result.additional_properties = d
        return validation_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
