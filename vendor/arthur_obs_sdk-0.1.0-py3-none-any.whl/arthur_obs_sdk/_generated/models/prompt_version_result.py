from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.test_case_status import TestCaseStatus
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.eval_execution import EvalExecution
  from ..models.prompt_output import PromptOutput
  from ..models.input_variable import InputVariable





T = TypeVar("T", bound="PromptVersionResult")



@_attrs_define
class PromptVersionResult:
    """ Result for a specific prompt version within a test case

        Attributes:
            status (TestCaseStatus): Status of a test case
            dataset_row_id (str): ID of the dataset row
            evals (list[EvalExecution]): Evaluation results for this specific config
            prompt_input_variables (list[InputVariable]): Input variables for the prompt
            rendered_prompt (str): Prompt with variables replaced
            total_cost (None | str | Unset): Total cost for this config test case execution
            output (None | PromptOutput | Unset): Output from the prompt (None if not yet executed)
     """

    status: TestCaseStatus
    dataset_row_id: str
    evals: list[EvalExecution]
    prompt_input_variables: list[InputVariable]
    rendered_prompt: str
    total_cost: None | str | Unset = UNSET
    output: None | PromptOutput | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.eval_execution import EvalExecution
        from ..models.prompt_output import PromptOutput
        from ..models.input_variable import InputVariable
        status = self.status.value

        dataset_row_id = self.dataset_row_id

        evals = []
        for evals_item_data in self.evals:
            evals_item = evals_item_data.to_dict()
            evals.append(evals_item)



        prompt_input_variables = []
        for prompt_input_variables_item_data in self.prompt_input_variables:
            prompt_input_variables_item = prompt_input_variables_item_data.to_dict()
            prompt_input_variables.append(prompt_input_variables_item)



        rendered_prompt = self.rendered_prompt

        total_cost: None | str | Unset
        if isinstance(self.total_cost, Unset):
            total_cost = UNSET
        else:
            total_cost = self.total_cost

        output: dict[str, Any] | None | Unset
        if isinstance(self.output, Unset):
            output = UNSET
        elif isinstance(self.output, PromptOutput):
            output = self.output.to_dict()
        else:
            output = self.output


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "status": status,
            "dataset_row_id": dataset_row_id,
            "evals": evals,
            "prompt_input_variables": prompt_input_variables,
            "rendered_prompt": rendered_prompt,
        })
        if total_cost is not UNSET:
            field_dict["total_cost"] = total_cost
        if output is not UNSET:
            field_dict["output"] = output

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.eval_execution import EvalExecution
        from ..models.prompt_output import PromptOutput
        from ..models.input_variable import InputVariable
        d = dict(src_dict)
        status = TestCaseStatus(d.pop("status"))




        dataset_row_id = d.pop("dataset_row_id")

        evals = []
        _evals = d.pop("evals")
        for evals_item_data in (_evals):
            evals_item = EvalExecution.from_dict(evals_item_data)



            evals.append(evals_item)


        prompt_input_variables = []
        _prompt_input_variables = d.pop("prompt_input_variables")
        for prompt_input_variables_item_data in (_prompt_input_variables):
            prompt_input_variables_item = InputVariable.from_dict(prompt_input_variables_item_data)



            prompt_input_variables.append(prompt_input_variables_item)


        rendered_prompt = d.pop("rendered_prompt")

        def _parse_total_cost(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        total_cost = _parse_total_cost(d.pop("total_cost", UNSET))


        def _parse_output(data: object) -> None | PromptOutput | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                output_type_0 = PromptOutput.from_dict(data)



                return output_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | PromptOutput | Unset, data)

        output = _parse_output(d.pop("output", UNSET))


        prompt_version_result = cls(
            status=status,
            dataset_row_id=dataset_row_id,
            evals=evals,
            prompt_input_variables=prompt_input_variables,
            rendered_prompt=rendered_prompt,
            total_cost=total_cost,
            output=output,
        )


        prompt_version_result.additional_properties = d
        return prompt_version_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
