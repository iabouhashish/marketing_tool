from enum import Enum

class UserPermissionAction(str, Enum):
    CREATE = "create"
    READ = "read"

    def __str__(self) -> str:
        return str(self.value)
