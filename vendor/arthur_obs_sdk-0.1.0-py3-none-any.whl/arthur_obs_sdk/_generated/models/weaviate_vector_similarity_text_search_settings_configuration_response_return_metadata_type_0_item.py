from enum import Enum

class WeaviateVectorSimilarityTextSearchSettingsConfigurationResponseReturnMetadataType0Item(str, Enum):
    CERTAINTY = "certainty"
    CREATION_TIME = "creation_time"
    DISTANCE = "distance"
    EXPLAIN_SCORE = "explain_score"
    IS_CONSISTENT = "is_consistent"
    LAST_UPDATE_TIME = "last_update_time"
    SCORE = "score"

    def __str__(self) -> str:
        return str(self.value)
