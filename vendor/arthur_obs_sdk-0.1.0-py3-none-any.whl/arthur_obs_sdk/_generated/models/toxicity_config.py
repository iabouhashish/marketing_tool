from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset






T = TypeVar("T", bound="ToxicityConfig")



@_attrs_define
class ToxicityConfig:
    """ 
        Example:
            {'threshold': 0.5}

        Attributes:
            threshold (float | Unset): Optional. Float (0, 1) indicating the level of tolerable toxicity to consider the
                rule passed or failed. Min: 0 (no toxic language) Max: 1 (very toxic language). Default: 0.5 Default: 0.5.
     """

    threshold: float | Unset = 0.5





    def to_dict(self) -> dict[str, Any]:
        threshold = self.threshold


        field_dict: dict[str, Any] = {}

        field_dict.update({
        })
        if threshold is not UNSET:
            field_dict["threshold"] = threshold

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        threshold = d.pop("threshold", UNSET)

        toxicity_config = cls(
            threshold=threshold,
        )

        return toxicity_config

