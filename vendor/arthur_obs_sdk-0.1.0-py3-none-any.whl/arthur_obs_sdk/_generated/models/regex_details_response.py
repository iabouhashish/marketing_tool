from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.regex_span_response import RegexSpanResponse





T = TypeVar("T", bound="RegexDetailsResponse")



@_attrs_define
class RegexDetailsResponse:
    """ 
        Attributes:
            score (bool | None | Unset):
            message (None | str | Unset):
            regex_matches (list[RegexSpanResponse] | Unset): Each string in this list corresponds to a matching span from
                the input text that matches the configured regex rule.
     """

    score: bool | None | Unset = UNSET
    message: None | str | Unset = UNSET
    regex_matches: list[RegexSpanResponse] | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.regex_span_response import RegexSpanResponse
        score: bool | None | Unset
        if isinstance(self.score, Unset):
            score = UNSET
        else:
            score = self.score

        message: None | str | Unset
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        regex_matches: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.regex_matches, Unset):
            regex_matches = []
            for regex_matches_item_data in self.regex_matches:
                regex_matches_item = regex_matches_item_data.to_dict()
                regex_matches.append(regex_matches_item)




        field_dict: dict[str, Any] = {}

        field_dict.update({
        })
        if score is not UNSET:
            field_dict["score"] = score
        if message is not UNSET:
            field_dict["message"] = message
        if regex_matches is not UNSET:
            field_dict["regex_matches"] = regex_matches

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.regex_span_response import RegexSpanResponse
        d = dict(src_dict)
        def _parse_score(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        score = _parse_score(d.pop("score", UNSET))


        def _parse_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        message = _parse_message(d.pop("message", UNSET))


        _regex_matches = d.pop("regex_matches", UNSET)
        regex_matches: list[RegexSpanResponse] | Unset = UNSET
        if _regex_matches is not UNSET:
            regex_matches = []
            for regex_matches_item_data in _regex_matches:
                regex_matches_item = RegexSpanResponse.from_dict(regex_matches_item_data)



                regex_matches.append(regex_matches_item)


        regex_details_response = cls(
            score=score,
            message=message,
            regex_matches=regex_matches,
        )

        return regex_details_response

