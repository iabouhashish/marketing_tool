from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.metric_type import MetricType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.relevance_metric_config import RelevanceMetricConfig





T = TypeVar("T", bound="NewMetricRequest")



@_attrs_define
class NewMetricRequest:
    """ 
        Attributes:
            type_ (MetricType):
            name (str): Name of metric
            metric_metadata (str): Additional metadata for the metric
            config (None | RelevanceMetricConfig | Unset): Configuration for the metric. Currently only applies to
                UserQueryRelevance and ResponseRelevance metric types.
     """

    type_: MetricType
    name: str
    metric_metadata: str
    config: None | RelevanceMetricConfig | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.relevance_metric_config import RelevanceMetricConfig
        type_ = self.type_.value

        name = self.name

        metric_metadata = self.metric_metadata

        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, RelevanceMetricConfig):
            config = self.config.to_dict()
        else:
            config = self.config


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "type": type_,
            "name": name,
            "metric_metadata": metric_metadata,
        })
        if config is not UNSET:
            field_dict["config"] = config

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.relevance_metric_config import RelevanceMetricConfig
        d = dict(src_dict)
        type_ = MetricType(d.pop("type"))




        name = d.pop("name")

        metric_metadata = d.pop("metric_metadata")

        def _parse_config(data: object) -> None | RelevanceMetricConfig | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0 = RelevanceMetricConfig.from_dict(data)



                return config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RelevanceMetricConfig | Unset, data)

        config = _parse_config(d.pop("config", UNSET))


        new_metric_request = cls(
            type_=type_,
            name=name,
            metric_metadata=metric_metadata,
            config=config,
        )


        new_metric_request.additional_properties = d
        return new_metric_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
