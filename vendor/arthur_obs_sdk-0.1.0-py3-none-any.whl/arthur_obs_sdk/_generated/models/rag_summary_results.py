from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.rag_eval_result_summaries import RagEvalResultSummaries





T = TypeVar("T", bound="RagSummaryResults")



@_attrs_define
class RagSummaryResults:
    """ Summary results across all RAG configurations and evaluations

        Attributes:
            rag_eval_summaries (list[RagEvalResultSummaries]): Summary for each RAG configuration tested
     """

    rag_eval_summaries: list[RagEvalResultSummaries]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rag_eval_result_summaries import RagEvalResultSummaries
        rag_eval_summaries = []
        for rag_eval_summaries_item_data in self.rag_eval_summaries:
            rag_eval_summaries_item = rag_eval_summaries_item_data.to_dict()
            rag_eval_summaries.append(rag_eval_summaries_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "rag_eval_summaries": rag_eval_summaries,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rag_eval_result_summaries import RagEvalResultSummaries
        d = dict(src_dict)
        rag_eval_summaries = []
        _rag_eval_summaries = d.pop("rag_eval_summaries")
        for rag_eval_summaries_item_data in (_rag_eval_summaries):
            rag_eval_summaries_item = RagEvalResultSummaries.from_dict(rag_eval_summaries_item_data)



            rag_eval_summaries.append(rag_eval_summaries_item)


        rag_summary_results = cls(
            rag_eval_summaries=rag_eval_summaries,
        )


        rag_summary_results.additional_properties = d
        return rag_summary_results

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
