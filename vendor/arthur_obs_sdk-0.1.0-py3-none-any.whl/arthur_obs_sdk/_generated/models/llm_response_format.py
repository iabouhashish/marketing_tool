from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.llm_response_format_enum import LLMResponseFormatEnum
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.llm_response_schema import LLMResponseSchema





T = TypeVar("T", bound="LLMResponseFormat")



@_attrs_define
class LLMResponseFormat:
    """ 
        Attributes:
            type_ (LLMResponseFormatEnum):
            json_schema (LLMResponseSchema | None | Unset): JSON schema definition (required when type is 'json_schema')
     """

    type_: LLMResponseFormatEnum
    json_schema: LLMResponseSchema | None | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        from ..models.llm_response_schema import LLMResponseSchema
        type_ = self.type_.value

        json_schema: dict[str, Any] | None | Unset
        if isinstance(self.json_schema, Unset):
            json_schema = UNSET
        elif isinstance(self.json_schema, LLMResponseSchema):
            json_schema = self.json_schema.to_dict()
        else:
            json_schema = self.json_schema


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "type": type_,
        })
        if json_schema is not UNSET:
            field_dict["json_schema"] = json_schema

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.llm_response_schema import LLMResponseSchema
        d = dict(src_dict)
        type_ = LLMResponseFormatEnum(d.pop("type"))




        def _parse_json_schema(data: object) -> LLMResponseSchema | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                json_schema_type_0 = LLMResponseSchema.from_dict(data)



                return json_schema_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(LLMResponseSchema | None | Unset, data)

        json_schema = _parse_json_schema(d.pop("json_schema", UNSET))


        llm_response_format = cls(
            type_=type_,
            json_schema=json_schema,
        )

        return llm_response_format

