from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID






T = TypeVar("T", bound="RagSearchSettingConfigurationUpdateRequest")



@_attrs_define
class RagSearchSettingConfigurationUpdateRequest:
    """ 
        Attributes:
            name (None | str | Unset): Name of the setting configuration.
            description (None | str | Unset): Description of the setting configuration.
            rag_provider_id (None | Unset | UUID): ID of the rag provider configuration to use the settings with.
     """

    name: None | str | Unset = UNSET
    description: None | str | Unset = UNSET
    rag_provider_id: None | Unset | UUID = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        name: None | str | Unset
        if isinstance(self.name, Unset):
            name = UNSET
        else:
            name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        rag_provider_id: None | str | Unset
        if isinstance(self.rag_provider_id, Unset):
            rag_provider_id = UNSET
        elif isinstance(self.rag_provider_id, UUID):
            rag_provider_id = str(self.rag_provider_id)
        else:
            rag_provider_id = self.rag_provider_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if name is not UNSET:
            field_dict["name"] = name
        if description is not UNSET:
            field_dict["description"] = description
        if rag_provider_id is not UNSET:
            field_dict["rag_provider_id"] = rag_provider_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        name = _parse_name(d.pop("name", UNSET))


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_rag_provider_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                rag_provider_id_type_0 = UUID(data)



                return rag_provider_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        rag_provider_id = _parse_rag_provider_id(d.pop("rag_provider_id", UNSET))


        rag_search_setting_configuration_update_request = cls(
            name=name,
            description=description,
            rag_provider_id=rag_provider_id,
        )


        rag_search_setting_configuration_update_request.additional_properties = d
        return rag_search_setting_configuration_update_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
