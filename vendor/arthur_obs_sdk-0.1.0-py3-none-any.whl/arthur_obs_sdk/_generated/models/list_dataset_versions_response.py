from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.dataset_version_metadata_response import DatasetVersionMetadataResponse





T = TypeVar("T", bound="ListDatasetVersionsResponse")



@_attrs_define
class ListDatasetVersionsResponse:
    """ 
        Attributes:
            versions (list[DatasetVersionMetadataResponse]): List of existing versions for the dataset.
            page (int): The current page number for the included rows.
            page_size (int): The number of rows per page.
            total_pages (int): The total number of pages.
            total_count (int): The total number of rows in the dataset version.
     """

    versions: list[DatasetVersionMetadataResponse]
    page: int
    page_size: int
    total_pages: int
    total_count: int
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.dataset_version_metadata_response import DatasetVersionMetadataResponse
        versions = []
        for versions_item_data in self.versions:
            versions_item = versions_item_data.to_dict()
            versions.append(versions_item)



        page = self.page

        page_size = self.page_size

        total_pages = self.total_pages

        total_count = self.total_count


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "versions": versions,
            "page": page,
            "page_size": page_size,
            "total_pages": total_pages,
            "total_count": total_count,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.dataset_version_metadata_response import DatasetVersionMetadataResponse
        d = dict(src_dict)
        versions = []
        _versions = d.pop("versions")
        for versions_item_data in (_versions):
            versions_item = DatasetVersionMetadataResponse.from_dict(versions_item_data)



            versions.append(versions_item)


        page = d.pop("page")

        page_size = d.pop("page_size")

        total_pages = d.pop("total_pages")

        total_count = d.pop("total_count")

        list_dataset_versions_response = cls(
            versions=versions,
            page=page,
            page_size=page_size,
            total_pages=total_pages,
            total_count=total_count,
        )


        list_dataset_versions_response.additional_properties = d
        return list_dataset_versions_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
