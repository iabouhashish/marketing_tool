from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.span_metadata_response import SpanMetadataResponse





T = TypeVar("T", bound="SpanListResponse")



@_attrs_define
class SpanListResponse:
    """ Response for span list endpoint

        Attributes:
            count (int): Total number of spans matching filters
            spans (list[SpanMetadataResponse]): List of span metadata
     """

    count: int
    spans: list[SpanMetadataResponse]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.span_metadata_response import SpanMetadataResponse
        count = self.count

        spans = []
        for spans_item_data in self.spans:
            spans_item = spans_item_data.to_dict()
            spans.append(spans_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "count": count,
            "spans": spans,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.span_metadata_response import SpanMetadataResponse
        d = dict(src_dict)
        count = d.pop("count")

        spans = []
        _spans = d.pop("spans")
        for spans_item_data in (_spans):
            spans_item = SpanMetadataResponse.from_dict(spans_item_data)



            spans.append(spans_item)


        span_list_response = cls(
            count=count,
            spans=spans,
        )


        span_list_response.additional_properties = d
        return span_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
