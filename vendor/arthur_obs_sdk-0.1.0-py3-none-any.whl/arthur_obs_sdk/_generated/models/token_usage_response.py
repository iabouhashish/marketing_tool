from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.token_usage_count import TokenUsageCount





T = TypeVar("T", bound="TokenUsageResponse")



@_attrs_define
class TokenUsageResponse:
    """ 
        Attributes:
            count (TokenUsageCount):
            rule_type (None | str | Unset):
            task_id (None | str | Unset):
     """

    count: TokenUsageCount
    rule_type: None | str | Unset = UNSET
    task_id: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.token_usage_count import TokenUsageCount
        count = self.count.to_dict()

        rule_type: None | str | Unset
        if isinstance(self.rule_type, Unset):
            rule_type = UNSET
        else:
            rule_type = self.rule_type

        task_id: None | str | Unset
        if isinstance(self.task_id, Unset):
            task_id = UNSET
        else:
            task_id = self.task_id


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "count": count,
        })
        if rule_type is not UNSET:
            field_dict["rule_type"] = rule_type
        if task_id is not UNSET:
            field_dict["task_id"] = task_id

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.token_usage_count import TokenUsageCount
        d = dict(src_dict)
        count = TokenUsageCount.from_dict(d.pop("count"))




        def _parse_rule_type(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        rule_type = _parse_rule_type(d.pop("rule_type", UNSET))


        def _parse_task_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        task_id = _parse_task_id(d.pop("task_id", UNSET))


        token_usage_response = cls(
            count=count,
            rule_type=rule_type,
            task_id=task_id,
        )


        token_usage_response.additional_properties = d
        return token_usage_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
