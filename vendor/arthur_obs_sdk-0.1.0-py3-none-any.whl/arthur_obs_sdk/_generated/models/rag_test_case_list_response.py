from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast

if TYPE_CHECKING:
  from ..models.rag_test_case import RagTestCase





T = TypeVar("T", bound="RagTestCaseListResponse")



@_attrs_define
class RagTestCaseListResponse:
    """ Paginated list of RAG test cases

        Attributes:
            page (int): Current page number (0-indexed)
            page_size (int): Number of items per page
            total_pages (int): Total number of pages
            total_count (int): Total number of records
            data (list[RagTestCase]): List of test cases
     """

    page: int
    page_size: int
    total_pages: int
    total_count: int
    data: list[RagTestCase]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rag_test_case import RagTestCase
        page = self.page

        page_size = self.page_size

        total_pages = self.total_pages

        total_count = self.total_count

        data = []
        for data_item_data in self.data:
            data_item = data_item_data.to_dict()
            data.append(data_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "page": page,
            "page_size": page_size,
            "total_pages": total_pages,
            "total_count": total_count,
            "data": data,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rag_test_case import RagTestCase
        d = dict(src_dict)
        page = d.pop("page")

        page_size = d.pop("page_size")

        total_pages = d.pop("total_pages")

        total_count = d.pop("total_count")

        data = []
        _data = d.pop("data")
        for data_item_data in (_data):
            data_item = RagTestCase.from_dict(data_item_data)



            data.append(data_item)


        rag_test_case_list_response = cls(
            page=page,
            page_size=page_size,
            total_pages=total_pages,
            total_count=total_count,
            data=data,
        )


        rag_test_case_list_response.additional_properties = d
        return rag_test_case_list_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
