from enum import Enum

class AgenticAnnotationType(str, Enum):
    CONTINUOUS_EVAL = "continuous_eval"
    HUMAN = "human"

    def __str__(self) -> str:
        return str(self.value)
