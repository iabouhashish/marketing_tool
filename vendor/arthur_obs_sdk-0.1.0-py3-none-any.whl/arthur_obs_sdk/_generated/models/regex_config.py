from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="RegexConfig")



@_attrs_define
class RegexConfig:
    r""" 
        Example:
            {'regex_patterns': ['\\d{3}-\\d{2}-\\d{4}', '\\d{5}-\\d{6}-\\d{7}']}

        Attributes:
            regex_patterns (list[str]): List of Regex patterns to be used for validation. Be sure to encode requests in JSON
                and account for escape characters.
     """

    regex_patterns: list[str]





    def to_dict(self) -> dict[str, Any]:
        regex_patterns = self.regex_patterns




        field_dict: dict[str, Any] = {}

        field_dict.update({
            "regex_patterns": regex_patterns,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        regex_patterns = cast(list[str], d.pop("regex_patterns"))


        regex_config = cls(
            regex_patterns=regex_patterns,
        )

        return regex_config

