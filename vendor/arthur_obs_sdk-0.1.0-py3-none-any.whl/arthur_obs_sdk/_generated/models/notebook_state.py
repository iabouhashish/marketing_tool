from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
  from ..models.saved_prompt_config import SavedPromptConfig
  from ..models.prompt_variable_mapping import PromptVariableMapping
  from ..models.unsaved_prompt_config import UnsavedPromptConfig
  from ..models.dataset_ref import DatasetRef
  from ..models.eval_ref import EvalRef





T = TypeVar("T", bound="NotebookState")



@_attrs_define
class NotebookState:
    """ Draft state of a notebook - mirrors experiment config but all fields optional.

        Attributes:
            prompt_configs (list[SavedPromptConfig | UnsavedPromptConfig] | None | Unset): List of prompt configurations
            prompt_variable_mapping (list[PromptVariableMapping] | None | Unset): Variable mappings for prompts
            dataset_ref (DatasetRef | None | Unset): Dataset reference (includes name)
            dataset_row_filter (list[NewDatasetVersionRowColumnItemRequest] | None | Unset): Optional list of column name
                and value filters. Only rows matching ALL specified column name-value pairs (AND condition) will be included.
            eval_list (list[EvalRef] | None | Unset): List of evaluations
     """

    prompt_configs: list[SavedPromptConfig | UnsavedPromptConfig] | None | Unset = UNSET
    prompt_variable_mapping: list[PromptVariableMapping] | None | Unset = UNSET
    dataset_ref: DatasetRef | None | Unset = UNSET
    dataset_row_filter: list[NewDatasetVersionRowColumnItemRequest] | None | Unset = UNSET
    eval_list: list[EvalRef] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        from ..models.saved_prompt_config import SavedPromptConfig
        from ..models.prompt_variable_mapping import PromptVariableMapping
        from ..models.unsaved_prompt_config import UnsavedPromptConfig
        from ..models.dataset_ref import DatasetRef
        from ..models.eval_ref import EvalRef
        prompt_configs: list[dict[str, Any]] | None | Unset
        if isinstance(self.prompt_configs, Unset):
            prompt_configs = UNSET
        elif isinstance(self.prompt_configs, list):
            prompt_configs = []
            for prompt_configs_type_0_item_data in self.prompt_configs:
                prompt_configs_type_0_item: dict[str, Any]
                if isinstance(prompt_configs_type_0_item_data, SavedPromptConfig):
                    prompt_configs_type_0_item = prompt_configs_type_0_item_data.to_dict()
                else:
                    prompt_configs_type_0_item = prompt_configs_type_0_item_data.to_dict()

                prompt_configs.append(prompt_configs_type_0_item)


        else:
            prompt_configs = self.prompt_configs

        prompt_variable_mapping: list[dict[str, Any]] | None | Unset
        if isinstance(self.prompt_variable_mapping, Unset):
            prompt_variable_mapping = UNSET
        elif isinstance(self.prompt_variable_mapping, list):
            prompt_variable_mapping = []
            for prompt_variable_mapping_type_0_item_data in self.prompt_variable_mapping:
                prompt_variable_mapping_type_0_item = prompt_variable_mapping_type_0_item_data.to_dict()
                prompt_variable_mapping.append(prompt_variable_mapping_type_0_item)


        else:
            prompt_variable_mapping = self.prompt_variable_mapping

        dataset_ref: dict[str, Any] | None | Unset
        if isinstance(self.dataset_ref, Unset):
            dataset_ref = UNSET
        elif isinstance(self.dataset_ref, DatasetRef):
            dataset_ref = self.dataset_ref.to_dict()
        else:
            dataset_ref = self.dataset_ref

        dataset_row_filter: list[dict[str, Any]] | None | Unset
        if isinstance(self.dataset_row_filter, Unset):
            dataset_row_filter = UNSET
        elif isinstance(self.dataset_row_filter, list):
            dataset_row_filter = []
            for dataset_row_filter_type_0_item_data in self.dataset_row_filter:
                dataset_row_filter_type_0_item = dataset_row_filter_type_0_item_data.to_dict()
                dataset_row_filter.append(dataset_row_filter_type_0_item)


        else:
            dataset_row_filter = self.dataset_row_filter

        eval_list: list[dict[str, Any]] | None | Unset
        if isinstance(self.eval_list, Unset):
            eval_list = UNSET
        elif isinstance(self.eval_list, list):
            eval_list = []
            for eval_list_type_0_item_data in self.eval_list:
                eval_list_type_0_item = eval_list_type_0_item_data.to_dict()
                eval_list.append(eval_list_type_0_item)


        else:
            eval_list = self.eval_list


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if prompt_configs is not UNSET:
            field_dict["prompt_configs"] = prompt_configs
        if prompt_variable_mapping is not UNSET:
            field_dict["prompt_variable_mapping"] = prompt_variable_mapping
        if dataset_ref is not UNSET:
            field_dict["dataset_ref"] = dataset_ref
        if dataset_row_filter is not UNSET:
            field_dict["dataset_row_filter"] = dataset_row_filter
        if eval_list is not UNSET:
            field_dict["eval_list"] = eval_list

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
        from ..models.saved_prompt_config import SavedPromptConfig
        from ..models.prompt_variable_mapping import PromptVariableMapping
        from ..models.unsaved_prompt_config import UnsavedPromptConfig
        from ..models.dataset_ref import DatasetRef
        from ..models.eval_ref import EvalRef
        d = dict(src_dict)
        def _parse_prompt_configs(data: object) -> list[SavedPromptConfig | UnsavedPromptConfig] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                prompt_configs_type_0 = []
                _prompt_configs_type_0 = data
                for prompt_configs_type_0_item_data in (_prompt_configs_type_0):
                    def _parse_prompt_configs_type_0_item(data: object) -> SavedPromptConfig | UnsavedPromptConfig:
                        try:
                            if not isinstance(data, dict):
                                raise TypeError()
                            prompt_configs_type_0_item_type_0 = SavedPromptConfig.from_dict(data)



                            return prompt_configs_type_0_item_type_0
                        except (TypeError, ValueError, AttributeError, KeyError):
                            pass
                        if not isinstance(data, dict):
                            raise TypeError()
                        prompt_configs_type_0_item_type_1 = UnsavedPromptConfig.from_dict(data)



                        return prompt_configs_type_0_item_type_1

                    prompt_configs_type_0_item = _parse_prompt_configs_type_0_item(prompt_configs_type_0_item_data)

                    prompt_configs_type_0.append(prompt_configs_type_0_item)

                return prompt_configs_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[SavedPromptConfig | UnsavedPromptConfig] | None | Unset, data)

        prompt_configs = _parse_prompt_configs(d.pop("prompt_configs", UNSET))


        def _parse_prompt_variable_mapping(data: object) -> list[PromptVariableMapping] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                prompt_variable_mapping_type_0 = []
                _prompt_variable_mapping_type_0 = data
                for prompt_variable_mapping_type_0_item_data in (_prompt_variable_mapping_type_0):
                    prompt_variable_mapping_type_0_item = PromptVariableMapping.from_dict(prompt_variable_mapping_type_0_item_data)



                    prompt_variable_mapping_type_0.append(prompt_variable_mapping_type_0_item)

                return prompt_variable_mapping_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[PromptVariableMapping] | None | Unset, data)

        prompt_variable_mapping = _parse_prompt_variable_mapping(d.pop("prompt_variable_mapping", UNSET))


        def _parse_dataset_ref(data: object) -> DatasetRef | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                dataset_ref_type_0 = DatasetRef.from_dict(data)



                return dataset_ref_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(DatasetRef | None | Unset, data)

        dataset_ref = _parse_dataset_ref(d.pop("dataset_ref", UNSET))


        def _parse_dataset_row_filter(data: object) -> list[NewDatasetVersionRowColumnItemRequest] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                dataset_row_filter_type_0 = []
                _dataset_row_filter_type_0 = data
                for dataset_row_filter_type_0_item_data in (_dataset_row_filter_type_0):
                    dataset_row_filter_type_0_item = NewDatasetVersionRowColumnItemRequest.from_dict(dataset_row_filter_type_0_item_data)



                    dataset_row_filter_type_0.append(dataset_row_filter_type_0_item)

                return dataset_row_filter_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[NewDatasetVersionRowColumnItemRequest] | None | Unset, data)

        dataset_row_filter = _parse_dataset_row_filter(d.pop("dataset_row_filter", UNSET))


        def _parse_eval_list(data: object) -> list[EvalRef] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                eval_list_type_0 = []
                _eval_list_type_0 = data
                for eval_list_type_0_item_data in (_eval_list_type_0):
                    eval_list_type_0_item = EvalRef.from_dict(eval_list_type_0_item_data)



                    eval_list_type_0.append(eval_list_type_0_item)

                return eval_list_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[EvalRef] | None | Unset, data)

        eval_list = _parse_eval_list(d.pop("eval_list", UNSET))


        notebook_state = cls(
            prompt_configs=prompt_configs,
            prompt_variable_mapping=prompt_variable_mapping,
            dataset_ref=dataset_ref,
            dataset_row_filter=dataset_row_filter,
            eval_list=eval_list,
        )


        notebook_state.additional_properties = d
        return notebook_state

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
