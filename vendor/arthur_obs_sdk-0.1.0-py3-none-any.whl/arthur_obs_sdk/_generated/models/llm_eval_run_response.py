from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset







T = TypeVar("T", bound="LLMEvalRunResponse")



@_attrs_define
class LLMEvalRunResponse:
    """ 
        Attributes:
            reason (str): Explanation for how the llm arrived at this answer.
            score (int): Score for this llm eval
            cost (str): Cost of this llm completion
     """

    reason: str
    score: int
    cost: str
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        reason = self.reason

        score = self.score

        cost = self.cost


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "reason": reason,
            "score": score,
            "cost": cost,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        reason = d.pop("reason")

        score = d.pop("score")

        cost = d.pop("cost")

        llm_eval_run_response = cls(
            reason=reason,
            score=score,
            cost=cost,
        )


        llm_eval_run_response.additional_properties = d
        return llm_eval_run_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
