from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime






T = TypeVar("T", bound="ContinuousEvalResponse")



@_attrs_define
class ContinuousEvalResponse:
    """ 
        Attributes:
            id (UUID): ID of the transform.
            name (str): Name of the continuous eval.
            task_id (str): ID of the parent task.
            llm_eval_name (str): Name of the llm eval.
            llm_eval_version (int): Version of the llm eval.
            transform_id (UUID): ID of the transform.
            created_at (datetime.datetime): Timestamp representing the time the transform was added to the llm eval.
            updated_at (datetime.datetime): Timestamp representing the time the continuous eval was last updated.
            description (None | str | Unset): Description of the continuous eval.
     """

    id: UUID
    name: str
    task_id: str
    llm_eval_name: str
    llm_eval_version: int
    transform_id: UUID
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        id = str(self.id)

        name = self.name

        task_id = self.task_id

        llm_eval_name = self.llm_eval_name

        llm_eval_version = self.llm_eval_version

        transform_id = str(self.transform_id)

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "task_id": task_id,
            "llm_eval_name": llm_eval_name,
            "llm_eval_version": llm_eval_version,
            "transform_id": transform_id,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        name = d.pop("name")

        task_id = d.pop("task_id")

        llm_eval_name = d.pop("llm_eval_name")

        llm_eval_version = d.pop("llm_eval_version")

        transform_id = UUID(d.pop("transform_id"))




        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        continuous_eval_response = cls(
            id=id,
            name=name,
            task_id=task_id,
            llm_eval_name=llm_eval_name,
            llm_eval_version=llm_eval_version,
            transform_id=transform_id,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
        )


        continuous_eval_response.additional_properties = d
        return continuous_eval_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
