from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.weaviate_vector_similarity_text_search_settings_configuration_request import WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest
  from ..models.weaviate_hybrid_search_settings_configuration_request import WeaviateHybridSearchSettingsConfigurationRequest
  from ..models.weaviate_keyword_search_settings_configuration_request import WeaviateKeywordSearchSettingsConfigurationRequest





T = TypeVar("T", bound="RagSearchSettingConfigurationNewVersionRequest")



@_attrs_define
class RagSearchSettingConfigurationNewVersionRequest:
    """ 
        Attributes:
            settings (WeaviateHybridSearchSettingsConfigurationRequest | WeaviateKeywordSearchSettingsConfigurationRequest |
                WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest): Settings configuration for a search request to
                a RAG provider.
            tags (list[str] | Unset): List of tags to configure for this version of the search settings configuration.
     """

    settings: WeaviateHybridSearchSettingsConfigurationRequest | WeaviateKeywordSearchSettingsConfigurationRequest | WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest
    tags: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.weaviate_vector_similarity_text_search_settings_configuration_request import WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest
        from ..models.weaviate_hybrid_search_settings_configuration_request import WeaviateHybridSearchSettingsConfigurationRequest
        from ..models.weaviate_keyword_search_settings_configuration_request import WeaviateKeywordSearchSettingsConfigurationRequest
        settings: dict[str, Any]
        if isinstance(self.settings, WeaviateHybridSearchSettingsConfigurationRequest):
            settings = self.settings.to_dict()
        elif isinstance(self.settings, WeaviateKeywordSearchSettingsConfigurationRequest):
            settings = self.settings.to_dict()
        else:
            settings = self.settings.to_dict()


        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "settings": settings,
        })
        if tags is not UNSET:
            field_dict["tags"] = tags

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.weaviate_vector_similarity_text_search_settings_configuration_request import WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest
        from ..models.weaviate_hybrid_search_settings_configuration_request import WeaviateHybridSearchSettingsConfigurationRequest
        from ..models.weaviate_keyword_search_settings_configuration_request import WeaviateKeywordSearchSettingsConfigurationRequest
        d = dict(src_dict)
        def _parse_settings(data: object) -> WeaviateHybridSearchSettingsConfigurationRequest | WeaviateKeywordSearchSettingsConfigurationRequest | WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                settings_type_0 = WeaviateHybridSearchSettingsConfigurationRequest.from_dict(data)



                return settings_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                settings_type_1 = WeaviateKeywordSearchSettingsConfigurationRequest.from_dict(data)



                return settings_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            settings_type_2 = WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest.from_dict(data)



            return settings_type_2

        settings = _parse_settings(d.pop("settings"))


        tags = cast(list[str], d.pop("tags", UNSET))


        rag_search_setting_configuration_new_version_request = cls(
            settings=settings,
            tags=tags,
        )


        rag_search_setting_configuration_new_version_request.additional_properties = d
        return rag_search_setting_configuration_new_version_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
