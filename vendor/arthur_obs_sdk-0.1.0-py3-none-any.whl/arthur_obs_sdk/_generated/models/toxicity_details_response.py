from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.toxicity_violation_type import ToxicityViolationType
from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="ToxicityDetailsResponse")



@_attrs_define
class ToxicityDetailsResponse:
    """ 
        Attributes:
            toxicity_violation_type (ToxicityViolationType):
            score (bool | None | Unset):
            message (None | str | Unset):
            toxicity_score (float | None | Unset):
     """

    toxicity_violation_type: ToxicityViolationType
    score: bool | None | Unset = UNSET
    message: None | str | Unset = UNSET
    toxicity_score: float | None | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        toxicity_violation_type = self.toxicity_violation_type.value

        score: bool | None | Unset
        if isinstance(self.score, Unset):
            score = UNSET
        else:
            score = self.score

        message: None | str | Unset
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message

        toxicity_score: float | None | Unset
        if isinstance(self.toxicity_score, Unset):
            toxicity_score = UNSET
        else:
            toxicity_score = self.toxicity_score


        field_dict: dict[str, Any] = {}

        field_dict.update({
            "toxicity_violation_type": toxicity_violation_type,
        })
        if score is not UNSET:
            field_dict["score"] = score
        if message is not UNSET:
            field_dict["message"] = message
        if toxicity_score is not UNSET:
            field_dict["toxicity_score"] = toxicity_score

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        toxicity_violation_type = ToxicityViolationType(d.pop("toxicity_violation_type"))




        def _parse_score(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        score = _parse_score(d.pop("score", UNSET))


        def _parse_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        message = _parse_message(d.pop("message", UNSET))


        def _parse_toxicity_score(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        toxicity_score = _parse_toxicity_score(d.pop("toxicity_score", UNSET))


        toxicity_details_response = cls(
            toxicity_violation_type=toxicity_violation_type,
            score=score,
            message=message,
            toxicity_score=toxicity_score,
        )

        return toxicity_details_response

