""" Contains all the data models used in inputs/outputs """

from .agentic_annotation_request import AgenticAnnotationRequest
from .agentic_annotation_response import AgenticAnnotationResponse
from .agentic_annotation_type import AgenticAnnotationType
from .agentic_prompt_run_response import AgenticPromptRunResponse
from .agentic_prompt_version_list_response import AgenticPromptVersionListResponse
from .agentic_prompt_version_response import AgenticPromptVersionResponse
from .anthropic_thinking_param import AnthropicThinkingParam
from .api_key_rag_authentication_config_request import ApiKeyRagAuthenticationConfigRequest
from .api_key_rag_authentication_config_response import ApiKeyRagAuthenticationConfigResponse
from .api_key_rag_authentication_config_update_request import ApiKeyRagAuthenticationConfigUpdateRequest
from .api_key_response import ApiKeyResponse
from .api_keys_roles_enum import APIKeysRolesEnum
from .auth_user_role import AuthUserRole
from .base_completion_request import BaseCompletionRequest
from .base_details_response import BaseDetailsResponse
from .base_model import BaseModel
from .body_add_tag_to_agentic_prompt_version_api_v1_tasks_task_id_prompts_prompt_name_versions_prompt_version_tags_put import BodyAddTagToAgenticPromptVersionApiV1TasksTaskIdPromptsPromptNameVersionsPromptVersionTagsPut
from .body_add_tag_to_llm_eval_version_api_v1_tasks_task_id_llm_evals_eval_name_versions_eval_version_tags_put import BodyAddTagToLlmEvalVersionApiV1TasksTaskIdLlmEvalsEvalNameVersionsEvalVersionTagsPut
from .body_upload_embeddings_file_api_chat_files_post import BodyUploadEmbeddingsFileApiChatFilesPost
from .chat_completion_message_tool_call import ChatCompletionMessageToolCall
from .chat_default_task_request import ChatDefaultTaskRequest
from .chat_default_task_response import ChatDefaultTaskResponse
from .chat_document_context import ChatDocumentContext
from .chat_request import ChatRequest
from .chat_response import ChatResponse
from .completion_request import CompletionRequest
from .connection_check_outcome import ConnectionCheckOutcome
from .connection_check_result import ConnectionCheckResult
from .continuous_eval_create_request import ContinuousEvalCreateRequest
from .continuous_eval_rerun_response import ContinuousEvalRerunResponse
from .continuous_eval_response import ContinuousEvalResponse
from .continuous_eval_run_status import ContinuousEvalRunStatus
from .conversation_base_response import ConversationBaseResponse
from .create_agentic_prompt_request import CreateAgenticPromptRequest
from .create_eval_request import CreateEvalRequest
from .create_notebook_request import CreateNotebookRequest
from .create_prompt_experiment_request import CreatePromptExperimentRequest
from .create_rag_experiment_request import CreateRagExperimentRequest
from .create_rag_notebook_request import CreateRagNotebookRequest
from .create_user_request import CreateUserRequest
from .dataset_column_source import DatasetColumnSource
from .dataset_column_variable_source import DatasetColumnVariableSource
from .dataset_ref import DatasetRef
from .dataset_ref_input import DatasetRefInput
from .dataset_response import DatasetResponse
from .dataset_response_metadata_type_0 import DatasetResponseMetadataType0
from .dataset_update_request import DatasetUpdateRequest
from .dataset_update_request_metadata_type_0 import DatasetUpdateRequestMetadataType0
from .dataset_version_metadata_response import DatasetVersionMetadataResponse
from .dataset_version_response import DatasetVersionResponse
from .dataset_version_row_column_item_response import DatasetVersionRowColumnItemResponse
from .dataset_version_row_response import DatasetVersionRowResponse
from .eval_execution import EvalExecution
from .eval_execution_result import EvalExecutionResult
from .eval_ref import EvalRef
from .eval_result_summary import EvalResultSummary
from .eval_variable_mapping import EvalVariableMapping
from .example_config import ExampleConfig
from .examples_config import ExamplesConfig
from .experiment_output_source import ExperimentOutputSource
from .experiment_output_variable_source import ExperimentOutputVariableSource
from .experiment_status import ExperimentStatus
from .external_document import ExternalDocument
from .external_inference import ExternalInference
from .external_inference_prompt import ExternalInferencePrompt
from .external_inference_response import ExternalInferenceResponse
from .external_rule_result import ExternalRuleResult
from .feedback_request import FeedbackRequest
from .file_upload_result import FileUploadResult
from .hallucination_claim_response import HallucinationClaimResponse
from .hallucination_details_response import HallucinationDetailsResponse
from .http_error import HTTPError
from .http_validation_error import HTTPValidationError
from .hybrid_fusion import HybridFusion
from .image_url import ImageURL
from .inference_feedback_response import InferenceFeedbackResponse
from .inference_feedback_target import InferenceFeedbackTarget
from .input_audio import InputAudio
from .input_variable import InputVariable
from .json_property_schema import JsonPropertySchema
from .json_schema import JsonSchema
from .json_schema_properties import JsonSchemaProperties
from .keyword_details_response import KeywordDetailsResponse
from .keyword_span_response import KeywordSpanResponse
from .keywords_config import KeywordsConfig
from .list_agentic_annotations_response import ListAgenticAnnotationsResponse
from .list_continuous_evals_response import ListContinuousEvalsResponse
from .list_dataset_versions_response import ListDatasetVersionsResponse
from .list_rag_search_setting_configuration_versions_response import ListRagSearchSettingConfigurationVersionsResponse
from .list_rag_search_setting_configurations_response import ListRagSearchSettingConfigurationsResponse
from .list_trace_transforms_response import ListTraceTransformsResponse
from .llm_base_config_settings import LLMBaseConfigSettings
from .llm_eval import LLMEval
from .llm_eval_run_response import LLMEvalRunResponse
from .llm_evals_version_list_response import LLMEvalsVersionListResponse
from .llm_get_all_metadata_list_response import LLMGetAllMetadataListResponse
from .llm_get_all_metadata_response import LLMGetAllMetadataResponse
from .llm_prompt_request_config_settings import LLMPromptRequestConfigSettings
from .llm_request_config_settings import LLMRequestConfigSettings
from .llm_response_format import LLMResponseFormat
from .llm_response_format_enum import LLMResponseFormatEnum
from .llm_response_schema import LLMResponseSchema
from .llm_tool import LLMTool
from .llm_version_response import LLMVersionResponse
from .logit_bias_item import LogitBiasItem
from .message_role import MessageRole
from .metadata_query import MetadataQuery
from .metric_response import MetricResponse
from .metric_result_response import MetricResultResponse
from .metric_type import MetricType
from .model_provider import ModelProvider
from .model_provider_list import ModelProviderList
from .model_provider_model_list import ModelProviderModelList
from .model_provider_response import ModelProviderResponse
from .multi_target_vector_join import MultiTargetVectorJoin
from .multi_target_vector_join_enum import MultiTargetVectorJoinEnum
from .multi_target_vector_join_weights_type_0 import MultiTargetVectorJoinWeightsType0
from .nested_span_with_metrics_response import NestedSpanWithMetricsResponse
from .nested_span_with_metrics_response_raw_data import NestedSpanWithMetricsResponseRawData
from .new_api_key_request import NewApiKeyRequest
from .new_dataset_request import NewDatasetRequest
from .new_dataset_request_metadata_type_0 import NewDatasetRequestMetadataType0
from .new_dataset_version_request import NewDatasetVersionRequest
from .new_dataset_version_row_column_item_request import NewDatasetVersionRowColumnItemRequest
from .new_dataset_version_row_request import NewDatasetVersionRowRequest
from .new_dataset_version_update_row_request import NewDatasetVersionUpdateRowRequest
from .new_metric_request import NewMetricRequest
from .new_rule_request import NewRuleRequest
from .new_task_request import NewTaskRequest
from .new_trace_transform_request import NewTraceTransformRequest
from .notebook_list_response import NotebookListResponse
from .notebook_state import NotebookState
from .notebook_summary import NotebookSummary
from .open_ai_message import OpenAIMessage
from .open_ai_message_item import OpenAIMessageItem
from .open_ai_message_type import OpenAIMessageType
from .page_conversation_base_response import PageConversationBaseResponse
from .pagination_sort_method import PaginationSortMethod
from .password_reset_request import PasswordResetRequest
from .pii_config import PIIConfig
from .pii_details_response import PIIDetailsResponse
from .pii_entity_span_response import PIIEntitySpanResponse
from .pii_entity_types import PIIEntityTypes
from .prompt_completion_request import PromptCompletionRequest
from .prompt_eval_result_summaries import PromptEvalResultSummaries
from .prompt_experiment_list_response import PromptExperimentListResponse
from .prompt_experiment_summary import PromptExperimentSummary
from .prompt_output import PromptOutput
from .prompt_result import PromptResult
from .prompt_validation_request import PromptValidationRequest
from .prompt_variable_mapping import PromptVariableMapping
from .prompt_version_result import PromptVersionResult
from .prompt_version_result_list_response import PromptVersionResultListResponse
from .put_model_provider_credentials import PutModelProviderCredentials
from .query_feedback_response import QueryFeedbackResponse
from .query_inferences_response import QueryInferencesResponse
from .query_spans_response import QuerySpansResponse
from .query_traces_with_metrics_response import QueryTracesWithMetricsResponse
from .rag_api_key_authentication_provider_enum import RagAPIKeyAuthenticationProviderEnum
from .rag_config_result import RagConfigResult
from .rag_config_result_list_response import RagConfigResultListResponse
from .rag_eval_result_summaries import RagEvalResultSummaries
from .rag_hybrid_search_setting_request import RagHybridSearchSettingRequest
from .rag_keyword_search_setting_request import RagKeywordSearchSettingRequest
from .rag_notebook_list_response import RagNotebookListResponse
from .rag_notebook_state import RagNotebookState
from .rag_notebook_summary import RagNotebookSummary
from .rag_provider_authentication_method_enum import RagProviderAuthenticationMethodEnum
from .rag_provider_collection_response import RagProviderCollectionResponse
from .rag_provider_configuration_request import RagProviderConfigurationRequest
from .rag_provider_configuration_response import RagProviderConfigurationResponse
from .rag_provider_configuration_update_request import RagProviderConfigurationUpdateRequest
from .rag_provider_query_response import RagProviderQueryResponse
from .rag_provider_test_configuration_request import RagProviderTestConfigurationRequest
from .rag_result import RagResult
from .rag_search_output import RagSearchOutput
from .rag_search_setting_configuration_new_version_request import RagSearchSettingConfigurationNewVersionRequest
from .rag_search_setting_configuration_request import RagSearchSettingConfigurationRequest
from .rag_search_setting_configuration_response import RagSearchSettingConfigurationResponse
from .rag_search_setting_configuration_update_request import RagSearchSettingConfigurationUpdateRequest
from .rag_search_setting_configuration_version_response import RagSearchSettingConfigurationVersionResponse
from .rag_search_setting_configuration_version_update_request import RagSearchSettingConfigurationVersionUpdateRequest
from .rag_summary_results import RagSummaryResults
from .rag_test_case import RagTestCase
from .rag_test_case_list_response import RagTestCaseListResponse
from .rag_vector_similarity_text_search_setting_request import RagVectorSimilarityTextSearchSettingRequest
from .reasoning_effort_enum import ReasoningEffortEnum
from .regex_config import RegexConfig
from .regex_details_response import RegexDetailsResponse
from .regex_span_response import RegexSpanResponse
from .relevance_metric_config import RelevanceMetricConfig
from .response_validation_request import ResponseValidationRequest
from .rule_response import RuleResponse
from .rule_result_enum import RuleResultEnum
from .rule_scope import RuleScope
from .rule_type import RuleType
from .saved_prompt_config import SavedPromptConfig
from .saved_prompt_rendering_request import SavedPromptRenderingRequest
from .saved_rag_config import SavedRagConfig
from .search_datasets_response import SearchDatasetsResponse
from .search_rag_provider_collections_response import SearchRagProviderCollectionsResponse
from .search_rag_provider_configurations_response import SearchRagProviderConfigurationsResponse
from .search_rules_request import SearchRulesRequest
from .search_rules_response import SearchRulesResponse
from .search_tasks_request import SearchTasksRequest
from .search_tasks_response import SearchTasksResponse
from .session_list_response import SessionListResponse
from .session_metadata_response import SessionMetadataResponse
from .session_traces_response import SessionTracesResponse
from .set_notebook_state_request import SetNotebookStateRequest
from .set_rag_notebook_state_request import SetRagNotebookStateRequest
from .span_list_response import SpanListResponse
from .span_metadata_response import SpanMetadataResponse
from .span_with_metrics_response import SpanWithMetricsResponse
from .span_with_metrics_response_raw_data import SpanWithMetricsResponseRawData
from .stream_options import StreamOptions
from .summary_results import SummaryResults
from .task_response import TaskResponse
from .test_case import TestCase
from .test_case_list_response import TestCaseListResponse
from .test_case_status import TestCaseStatus
from .token_usage_count import TokenUsageCount
from .token_usage_response import TokenUsageResponse
from .token_usage_scope import TokenUsageScope
from .tool_call import ToolCall
from .tool_call_function import ToolCallFunction
from .tool_choice import ToolChoice
from .tool_choice_enum import ToolChoiceEnum
from .tool_choice_function import ToolChoiceFunction
from .tool_class_enum import ToolClassEnum
from .tool_function import ToolFunction
from .toxicity_config import ToxicityConfig
from .toxicity_details_response import ToxicityDetailsResponse
from .toxicity_violation_type import ToxicityViolationType
from .trace_list_response import TraceListResponse
from .trace_metadata_response import TraceMetadataResponse
from .trace_response import TraceResponse
from .trace_transform_definition import TraceTransformDefinition
from .trace_transform_response import TraceTransformResponse
from .trace_transform_update_request import TraceTransformUpdateRequest
from .trace_transform_variable_definition import TraceTransformVariableDefinition
from .trace_user_list_response import TraceUserListResponse
from .trace_user_metadata_response import TraceUserMetadataResponse
from .transform_extraction_response_list import TransformExtractionResponseList
from .unregistered_root_span_group import UnregisteredRootSpanGroup
from .unregistered_root_spans_response import UnregisteredRootSpansResponse
from .unsaved_prompt_config import UnsavedPromptConfig
from .unsaved_prompt_config_config_type_0 import UnsavedPromptConfigConfigType0
from .unsaved_prompt_config_messages_item import UnsavedPromptConfigMessagesItem
from .unsaved_prompt_config_tools_type_0_item import UnsavedPromptConfigToolsType0Item
from .unsaved_prompt_rendering_request import UnsavedPromptRenderingRequest
from .unsaved_prompt_variables_list_response import UnsavedPromptVariablesListResponse
from .unsaved_prompt_variables_request import UnsavedPromptVariablesRequest
from .unsaved_rag_config import UnsavedRagConfig
from .unsaved_rag_config_response import UnsavedRagConfigResponse
from .update_continuous_eval_request import UpdateContinuousEvalRequest
from .update_metric_request import UpdateMetricRequest
from .update_notebook_request import UpdateNotebookRequest
from .update_rag_notebook_request import UpdateRagNotebookRequest
from .update_rule_request import UpdateRuleRequest
from .user_permission_action import UserPermissionAction
from .user_permission_resource import UserPermissionResource
from .user_response import UserResponse
from .validation_error import ValidationError
from .validation_result import ValidationResult
from .variable_rendering_request import VariableRenderingRequest
from .variable_template_value import VariableTemplateValue
from .weaviate_hybrid_search_settings_configuration_request import WeaviateHybridSearchSettingsConfigurationRequest
from .weaviate_hybrid_search_settings_configuration_request_return_metadata_type_0_item import WeaviateHybridSearchSettingsConfigurationRequestReturnMetadataType0Item
from .weaviate_hybrid_search_settings_configuration_response import WeaviateHybridSearchSettingsConfigurationResponse
from .weaviate_hybrid_search_settings_configuration_response_return_metadata_type_0_item import WeaviateHybridSearchSettingsConfigurationResponseReturnMetadataType0Item
from .weaviate_hybrid_search_settings_request import WeaviateHybridSearchSettingsRequest
from .weaviate_hybrid_search_settings_request_return_metadata_type_0_item import WeaviateHybridSearchSettingsRequestReturnMetadataType0Item
from .weaviate_keyword_search_settings_configuration_request import WeaviateKeywordSearchSettingsConfigurationRequest
from .weaviate_keyword_search_settings_configuration_request_return_metadata_type_0_item import WeaviateKeywordSearchSettingsConfigurationRequestReturnMetadataType0Item
from .weaviate_keyword_search_settings_configuration_response import WeaviateKeywordSearchSettingsConfigurationResponse
from .weaviate_keyword_search_settings_configuration_response_return_metadata_type_0_item import WeaviateKeywordSearchSettingsConfigurationResponseReturnMetadataType0Item
from .weaviate_keyword_search_settings_request import WeaviateKeywordSearchSettingsRequest
from .weaviate_keyword_search_settings_request_return_metadata_type_0_item import WeaviateKeywordSearchSettingsRequestReturnMetadataType0Item
from .weaviate_query_result import WeaviateQueryResult
from .weaviate_query_result_metadata import WeaviateQueryResultMetadata
from .weaviate_query_result_properties import WeaviateQueryResultProperties
from .weaviate_query_result_vector_type_0 import WeaviateQueryResultVectorType0
from .weaviate_query_results import WeaviateQueryResults
from .weaviate_vector_similarity_text_search_settings_configuration_request import WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest
from .weaviate_vector_similarity_text_search_settings_configuration_request_return_metadata_type_0_item import WeaviateVectorSimilarityTextSearchSettingsConfigurationRequestReturnMetadataType0Item
from .weaviate_vector_similarity_text_search_settings_configuration_response import WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse
from .weaviate_vector_similarity_text_search_settings_configuration_response_return_metadata_type_0_item import WeaviateVectorSimilarityTextSearchSettingsConfigurationResponseReturnMetadataType0Item
from .weaviate_vector_similarity_text_search_settings_request import WeaviateVectorSimilarityTextSearchSettingsRequest
from .weaviate_vector_similarity_text_search_settings_request_return_metadata_type_0_item import WeaviateVectorSimilarityTextSearchSettingsRequestReturnMetadataType0Item

__all__ = (
    "AgenticAnnotationRequest",
    "AgenticAnnotationResponse",
    "AgenticAnnotationType",
    "AgenticPromptRunResponse",
    "AgenticPromptVersionListResponse",
    "AgenticPromptVersionResponse",
    "AnthropicThinkingParam",
    "ApiKeyRagAuthenticationConfigRequest",
    "ApiKeyRagAuthenticationConfigResponse",
    "ApiKeyRagAuthenticationConfigUpdateRequest",
    "ApiKeyResponse",
    "APIKeysRolesEnum",
    "AuthUserRole",
    "BaseCompletionRequest",
    "BaseDetailsResponse",
    "BaseModel",
    "BodyAddTagToAgenticPromptVersionApiV1TasksTaskIdPromptsPromptNameVersionsPromptVersionTagsPut",
    "BodyAddTagToLlmEvalVersionApiV1TasksTaskIdLlmEvalsEvalNameVersionsEvalVersionTagsPut",
    "BodyUploadEmbeddingsFileApiChatFilesPost",
    "ChatCompletionMessageToolCall",
    "ChatDefaultTaskRequest",
    "ChatDefaultTaskResponse",
    "ChatDocumentContext",
    "ChatRequest",
    "ChatResponse",
    "CompletionRequest",
    "ConnectionCheckOutcome",
    "ConnectionCheckResult",
    "ContinuousEvalCreateRequest",
    "ContinuousEvalRerunResponse",
    "ContinuousEvalResponse",
    "ContinuousEvalRunStatus",
    "ConversationBaseResponse",
    "CreateAgenticPromptRequest",
    "CreateEvalRequest",
    "CreateNotebookRequest",
    "CreatePromptExperimentRequest",
    "CreateRagExperimentRequest",
    "CreateRagNotebookRequest",
    "CreateUserRequest",
    "DatasetColumnSource",
    "DatasetColumnVariableSource",
    "DatasetRef",
    "DatasetRefInput",
    "DatasetResponse",
    "DatasetResponseMetadataType0",
    "DatasetUpdateRequest",
    "DatasetUpdateRequestMetadataType0",
    "DatasetVersionMetadataResponse",
    "DatasetVersionResponse",
    "DatasetVersionRowColumnItemResponse",
    "DatasetVersionRowResponse",
    "EvalExecution",
    "EvalExecutionResult",
    "EvalRef",
    "EvalResultSummary",
    "EvalVariableMapping",
    "ExampleConfig",
    "ExamplesConfig",
    "ExperimentOutputSource",
    "ExperimentOutputVariableSource",
    "ExperimentStatus",
    "ExternalDocument",
    "ExternalInference",
    "ExternalInferencePrompt",
    "ExternalInferenceResponse",
    "ExternalRuleResult",
    "FeedbackRequest",
    "FileUploadResult",
    "HallucinationClaimResponse",
    "HallucinationDetailsResponse",
    "HTTPError",
    "HTTPValidationError",
    "HybridFusion",
    "ImageURL",
    "InferenceFeedbackResponse",
    "InferenceFeedbackTarget",
    "InputAudio",
    "InputVariable",
    "JsonPropertySchema",
    "JsonSchema",
    "JsonSchemaProperties",
    "KeywordDetailsResponse",
    "KeywordsConfig",
    "KeywordSpanResponse",
    "ListAgenticAnnotationsResponse",
    "ListContinuousEvalsResponse",
    "ListDatasetVersionsResponse",
    "ListRagSearchSettingConfigurationsResponse",
    "ListRagSearchSettingConfigurationVersionsResponse",
    "ListTraceTransformsResponse",
    "LLMBaseConfigSettings",
    "LLMEval",
    "LLMEvalRunResponse",
    "LLMEvalsVersionListResponse",
    "LLMGetAllMetadataListResponse",
    "LLMGetAllMetadataResponse",
    "LLMPromptRequestConfigSettings",
    "LLMRequestConfigSettings",
    "LLMResponseFormat",
    "LLMResponseFormatEnum",
    "LLMResponseSchema",
    "LLMTool",
    "LLMVersionResponse",
    "LogitBiasItem",
    "MessageRole",
    "MetadataQuery",
    "MetricResponse",
    "MetricResultResponse",
    "MetricType",
    "ModelProvider",
    "ModelProviderList",
    "ModelProviderModelList",
    "ModelProviderResponse",
    "MultiTargetVectorJoin",
    "MultiTargetVectorJoinEnum",
    "MultiTargetVectorJoinWeightsType0",
    "NestedSpanWithMetricsResponse",
    "NestedSpanWithMetricsResponseRawData",
    "NewApiKeyRequest",
    "NewDatasetRequest",
    "NewDatasetRequestMetadataType0",
    "NewDatasetVersionRequest",
    "NewDatasetVersionRowColumnItemRequest",
    "NewDatasetVersionRowRequest",
    "NewDatasetVersionUpdateRowRequest",
    "NewMetricRequest",
    "NewRuleRequest",
    "NewTaskRequest",
    "NewTraceTransformRequest",
    "NotebookListResponse",
    "NotebookState",
    "NotebookSummary",
    "OpenAIMessage",
    "OpenAIMessageItem",
    "OpenAIMessageType",
    "PageConversationBaseResponse",
    "PaginationSortMethod",
    "PasswordResetRequest",
    "PIIConfig",
    "PIIDetailsResponse",
    "PIIEntitySpanResponse",
    "PIIEntityTypes",
    "PromptCompletionRequest",
    "PromptEvalResultSummaries",
    "PromptExperimentListResponse",
    "PromptExperimentSummary",
    "PromptOutput",
    "PromptResult",
    "PromptValidationRequest",
    "PromptVariableMapping",
    "PromptVersionResult",
    "PromptVersionResultListResponse",
    "PutModelProviderCredentials",
    "QueryFeedbackResponse",
    "QueryInferencesResponse",
    "QuerySpansResponse",
    "QueryTracesWithMetricsResponse",
    "RagAPIKeyAuthenticationProviderEnum",
    "RagConfigResult",
    "RagConfigResultListResponse",
    "RagEvalResultSummaries",
    "RagHybridSearchSettingRequest",
    "RagKeywordSearchSettingRequest",
    "RagNotebookListResponse",
    "RagNotebookState",
    "RagNotebookSummary",
    "RagProviderAuthenticationMethodEnum",
    "RagProviderCollectionResponse",
    "RagProviderConfigurationRequest",
    "RagProviderConfigurationResponse",
    "RagProviderConfigurationUpdateRequest",
    "RagProviderQueryResponse",
    "RagProviderTestConfigurationRequest",
    "RagResult",
    "RagSearchOutput",
    "RagSearchSettingConfigurationNewVersionRequest",
    "RagSearchSettingConfigurationRequest",
    "RagSearchSettingConfigurationResponse",
    "RagSearchSettingConfigurationUpdateRequest",
    "RagSearchSettingConfigurationVersionResponse",
    "RagSearchSettingConfigurationVersionUpdateRequest",
    "RagSummaryResults",
    "RagTestCase",
    "RagTestCaseListResponse",
    "RagVectorSimilarityTextSearchSettingRequest",
    "ReasoningEffortEnum",
    "RegexConfig",
    "RegexDetailsResponse",
    "RegexSpanResponse",
    "RelevanceMetricConfig",
    "ResponseValidationRequest",
    "RuleResponse",
    "RuleResultEnum",
    "RuleScope",
    "RuleType",
    "SavedPromptConfig",
    "SavedPromptRenderingRequest",
    "SavedRagConfig",
    "SearchDatasetsResponse",
    "SearchRagProviderCollectionsResponse",
    "SearchRagProviderConfigurationsResponse",
    "SearchRulesRequest",
    "SearchRulesResponse",
    "SearchTasksRequest",
    "SearchTasksResponse",
    "SessionListResponse",
    "SessionMetadataResponse",
    "SessionTracesResponse",
    "SetNotebookStateRequest",
    "SetRagNotebookStateRequest",
    "SpanListResponse",
    "SpanMetadataResponse",
    "SpanWithMetricsResponse",
    "SpanWithMetricsResponseRawData",
    "StreamOptions",
    "SummaryResults",
    "TaskResponse",
    "TestCase",
    "TestCaseListResponse",
    "TestCaseStatus",
    "TokenUsageCount",
    "TokenUsageResponse",
    "TokenUsageScope",
    "ToolCall",
    "ToolCallFunction",
    "ToolChoice",
    "ToolChoiceEnum",
    "ToolChoiceFunction",
    "ToolClassEnum",
    "ToolFunction",
    "ToxicityConfig",
    "ToxicityDetailsResponse",
    "ToxicityViolationType",
    "TraceListResponse",
    "TraceMetadataResponse",
    "TraceResponse",
    "TraceTransformDefinition",
    "TraceTransformResponse",
    "TraceTransformUpdateRequest",
    "TraceTransformVariableDefinition",
    "TraceUserListResponse",
    "TraceUserMetadataResponse",
    "TransformExtractionResponseList",
    "UnregisteredRootSpanGroup",
    "UnregisteredRootSpansResponse",
    "UnsavedPromptConfig",
    "UnsavedPromptConfigConfigType0",
    "UnsavedPromptConfigMessagesItem",
    "UnsavedPromptConfigToolsType0Item",
    "UnsavedPromptRenderingRequest",
    "UnsavedPromptVariablesListResponse",
    "UnsavedPromptVariablesRequest",
    "UnsavedRagConfig",
    "UnsavedRagConfigResponse",
    "UpdateContinuousEvalRequest",
    "UpdateMetricRequest",
    "UpdateNotebookRequest",
    "UpdateRagNotebookRequest",
    "UpdateRuleRequest",
    "UserPermissionAction",
    "UserPermissionResource",
    "UserResponse",
    "ValidationError",
    "ValidationResult",
    "VariableRenderingRequest",
    "VariableTemplateValue",
    "WeaviateHybridSearchSettingsConfigurationRequest",
    "WeaviateHybridSearchSettingsConfigurationRequestReturnMetadataType0Item",
    "WeaviateHybridSearchSettingsConfigurationResponse",
    "WeaviateHybridSearchSettingsConfigurationResponseReturnMetadataType0Item",
    "WeaviateHybridSearchSettingsRequest",
    "WeaviateHybridSearchSettingsRequestReturnMetadataType0Item",
    "WeaviateKeywordSearchSettingsConfigurationRequest",
    "WeaviateKeywordSearchSettingsConfigurationRequestReturnMetadataType0Item",
    "WeaviateKeywordSearchSettingsConfigurationResponse",
    "WeaviateKeywordSearchSettingsConfigurationResponseReturnMetadataType0Item",
    "WeaviateKeywordSearchSettingsRequest",
    "WeaviateKeywordSearchSettingsRequestReturnMetadataType0Item",
    "WeaviateQueryResult",
    "WeaviateQueryResultMetadata",
    "WeaviateQueryResultProperties",
    "WeaviateQueryResults",
    "WeaviateQueryResultVectorType0",
    "WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest",
    "WeaviateVectorSimilarityTextSearchSettingsConfigurationRequestReturnMetadataType0Item",
    "WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse",
    "WeaviateVectorSimilarityTextSearchSettingsConfigurationResponseReturnMetadataType0Item",
    "WeaviateVectorSimilarityTextSearchSettingsRequest",
    "WeaviateVectorSimilarityTextSearchSettingsRequestReturnMetadataType0Item",
)
