from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.tool_function import ToolFunction





T = TypeVar("T", bound="LLMTool")



@_attrs_define
class LLMTool:
    """ 
        Attributes:
            function (ToolFunction):
            type_ (str | Unset): The type of tool. Should always be 'function' Default: 'function'.
            strict (bool | None | Unset): Whether the function definition should use OpenAI's strict mode
     """

    function: ToolFunction
    type_: str | Unset = 'function'
    strict: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.tool_function import ToolFunction
        function = self.function.to_dict()

        type_ = self.type_

        strict: bool | None | Unset
        if isinstance(self.strict, Unset):
            strict = UNSET
        else:
            strict = self.strict


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "function": function,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if strict is not UNSET:
            field_dict["strict"] = strict

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tool_function import ToolFunction
        d = dict(src_dict)
        function = ToolFunction.from_dict(d.pop("function"))




        type_ = d.pop("type", UNSET)

        def _parse_strict(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        strict = _parse_strict(d.pop("strict", UNSET))


        llm_tool = cls(
            function=function,
            type_=type_,
            strict=strict,
        )


        llm_tool.additional_properties = d
        return llm_tool

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
