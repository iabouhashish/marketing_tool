from enum import Enum

class InferenceFeedbackTarget(str, Enum):
    CONTEXT = "context"
    PROMPT_RESULTS = "prompt_results"
    RESPONSE_RESULTS = "response_results"

    def __str__(self) -> str:
        return str(self.value)
