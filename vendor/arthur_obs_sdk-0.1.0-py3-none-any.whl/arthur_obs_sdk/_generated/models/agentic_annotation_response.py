from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.agentic_annotation_type import AgenticAnnotationType
from ..models.continuous_eval_run_status import ContinuousEvalRunStatus
from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.variable_template_value import VariableTemplateValue





T = TypeVar("T", bound="AgenticAnnotationResponse")



@_attrs_define
class AgenticAnnotationResponse:
    """ 
        Attributes:
            id (str): ID of the annotation
            annotation_type (AgenticAnnotationType):
            trace_id (str): ID of the trace this annotation belongs to
            created_at (datetime.datetime): Time the annotation was created
            updated_at (datetime.datetime): Time the annotation was last updated
            continuous_eval_id (None | str | Unset): ID of the continuous eval this annotation belongs to
            continuous_eval_name (None | str | Unset): Name of the continuous eval this annotation belongs to
            eval_name (None | str | Unset): Name of the eval the continuous eval used when scoring
            eval_version (int | None | Unset): Version of the eval the continuous eval used when scoring
            annotation_score (int | None | Unset): Binary score for a positive or negative annotation.
            annotation_description (None | str | Unset): Description of the annotation.
            input_variables (list[VariableTemplateValue] | None | Unset): Input variables for the continuous eval
            run_status (ContinuousEvalRunStatus | None | Unset): Status of the continuous eval run
            cost (float | None | Unset): Cost of the continuous eval run
     """

    id: str
    annotation_type: AgenticAnnotationType
    trace_id: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    continuous_eval_id: None | str | Unset = UNSET
    continuous_eval_name: None | str | Unset = UNSET
    eval_name: None | str | Unset = UNSET
    eval_version: int | None | Unset = UNSET
    annotation_score: int | None | Unset = UNSET
    annotation_description: None | str | Unset = UNSET
    input_variables: list[VariableTemplateValue] | None | Unset = UNSET
    run_status: ContinuousEvalRunStatus | None | Unset = UNSET
    cost: float | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.variable_template_value import VariableTemplateValue
        id = self.id

        annotation_type = self.annotation_type.value

        trace_id = self.trace_id

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        continuous_eval_id: None | str | Unset
        if isinstance(self.continuous_eval_id, Unset):
            continuous_eval_id = UNSET
        else:
            continuous_eval_id = self.continuous_eval_id

        continuous_eval_name: None | str | Unset
        if isinstance(self.continuous_eval_name, Unset):
            continuous_eval_name = UNSET
        else:
            continuous_eval_name = self.continuous_eval_name

        eval_name: None | str | Unset
        if isinstance(self.eval_name, Unset):
            eval_name = UNSET
        else:
            eval_name = self.eval_name

        eval_version: int | None | Unset
        if isinstance(self.eval_version, Unset):
            eval_version = UNSET
        else:
            eval_version = self.eval_version

        annotation_score: int | None | Unset
        if isinstance(self.annotation_score, Unset):
            annotation_score = UNSET
        else:
            annotation_score = self.annotation_score

        annotation_description: None | str | Unset
        if isinstance(self.annotation_description, Unset):
            annotation_description = UNSET
        else:
            annotation_description = self.annotation_description

        input_variables: list[dict[str, Any]] | None | Unset
        if isinstance(self.input_variables, Unset):
            input_variables = UNSET
        elif isinstance(self.input_variables, list):
            input_variables = []
            for input_variables_type_0_item_data in self.input_variables:
                input_variables_type_0_item = input_variables_type_0_item_data.to_dict()
                input_variables.append(input_variables_type_0_item)


        else:
            input_variables = self.input_variables

        run_status: None | str | Unset
        if isinstance(self.run_status, Unset):
            run_status = UNSET
        elif isinstance(self.run_status, ContinuousEvalRunStatus):
            run_status = self.run_status.value
        else:
            run_status = self.run_status

        cost: float | None | Unset
        if isinstance(self.cost, Unset):
            cost = UNSET
        else:
            cost = self.cost


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "annotation_type": annotation_type,
            "trace_id": trace_id,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if continuous_eval_id is not UNSET:
            field_dict["continuous_eval_id"] = continuous_eval_id
        if continuous_eval_name is not UNSET:
            field_dict["continuous_eval_name"] = continuous_eval_name
        if eval_name is not UNSET:
            field_dict["eval_name"] = eval_name
        if eval_version is not UNSET:
            field_dict["eval_version"] = eval_version
        if annotation_score is not UNSET:
            field_dict["annotation_score"] = annotation_score
        if annotation_description is not UNSET:
            field_dict["annotation_description"] = annotation_description
        if input_variables is not UNSET:
            field_dict["input_variables"] = input_variables
        if run_status is not UNSET:
            field_dict["run_status"] = run_status
        if cost is not UNSET:
            field_dict["cost"] = cost

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.variable_template_value import VariableTemplateValue
        d = dict(src_dict)
        id = d.pop("id")

        annotation_type = AgenticAnnotationType(d.pop("annotation_type"))




        trace_id = d.pop("trace_id")

        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        def _parse_continuous_eval_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        continuous_eval_id = _parse_continuous_eval_id(d.pop("continuous_eval_id", UNSET))


        def _parse_continuous_eval_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        continuous_eval_name = _parse_continuous_eval_name(d.pop("continuous_eval_name", UNSET))


        def _parse_eval_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        eval_name = _parse_eval_name(d.pop("eval_name", UNSET))


        def _parse_eval_version(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        eval_version = _parse_eval_version(d.pop("eval_version", UNSET))


        def _parse_annotation_score(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        annotation_score = _parse_annotation_score(d.pop("annotation_score", UNSET))


        def _parse_annotation_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        annotation_description = _parse_annotation_description(d.pop("annotation_description", UNSET))


        def _parse_input_variables(data: object) -> list[VariableTemplateValue] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                input_variables_type_0 = []
                _input_variables_type_0 = data
                for input_variables_type_0_item_data in (_input_variables_type_0):
                    input_variables_type_0_item = VariableTemplateValue.from_dict(input_variables_type_0_item_data)



                    input_variables_type_0.append(input_variables_type_0_item)

                return input_variables_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[VariableTemplateValue] | None | Unset, data)

        input_variables = _parse_input_variables(d.pop("input_variables", UNSET))


        def _parse_run_status(data: object) -> ContinuousEvalRunStatus | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                run_status_type_0 = ContinuousEvalRunStatus(data)



                return run_status_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(ContinuousEvalRunStatus | None | Unset, data)

        run_status = _parse_run_status(d.pop("run_status", UNSET))


        def _parse_cost(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        cost = _parse_cost(d.pop("cost", UNSET))


        agentic_annotation_response = cls(
            id=id,
            annotation_type=annotation_type,
            trace_id=trace_id,
            created_at=created_at,
            updated_at=updated_at,
            continuous_eval_id=continuous_eval_id,
            continuous_eval_name=continuous_eval_name,
            eval_name=eval_name,
            eval_version=eval_version,
            annotation_score=annotation_score,
            annotation_description=annotation_description,
            input_variables=input_variables,
            run_status=run_status,
            cost=cost,
        )


        agentic_annotation_response.additional_properties = d
        return agentic_annotation_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
