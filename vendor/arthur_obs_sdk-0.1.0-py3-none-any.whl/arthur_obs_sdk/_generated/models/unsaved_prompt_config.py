from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.model_provider import ModelProvider
from ..types import UNSET, Unset
from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.unsaved_prompt_config_messages_item import UnsavedPromptConfigMessagesItem
  from ..models.unsaved_prompt_config_tools_type_0_item import UnsavedPromptConfigToolsType0Item
  from ..models.unsaved_prompt_config_config_type_0 import UnsavedPromptConfigConfigType0





T = TypeVar("T", bound="UnsavedPromptConfig")



@_attrs_define
class UnsavedPromptConfig:
    """ Configuration for an unsaved prompt

        Attributes:
            messages (list[UnsavedPromptConfigMessagesItem]): Prompt messages
            model_name (str): LLM model name
            model_provider (ModelProvider):
            type_ (Literal['unsaved'] | Unset):  Default: 'unsaved'.
            auto_name (None | str | Unset): Auto-generated name (set by backend)
            tools (list[UnsavedPromptConfigToolsType0Item] | None | Unset): Available tools
            config (None | UnsavedPromptConfigConfigType0 | Unset): LLM config settings
            variables (list[str] | None | Unset): Variables (auto-detected if not provided)
     """

    messages: list[UnsavedPromptConfigMessagesItem]
    model_name: str
    model_provider: ModelProvider
    type_: Literal['unsaved'] | Unset = 'unsaved'
    auto_name: None | str | Unset = UNSET
    tools: list[UnsavedPromptConfigToolsType0Item] | None | Unset = UNSET
    config: None | UnsavedPromptConfigConfigType0 | Unset = UNSET
    variables: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.unsaved_prompt_config_messages_item import UnsavedPromptConfigMessagesItem
        from ..models.unsaved_prompt_config_tools_type_0_item import UnsavedPromptConfigToolsType0Item
        from ..models.unsaved_prompt_config_config_type_0 import UnsavedPromptConfigConfigType0
        messages = []
        for messages_item_data in self.messages:
            messages_item = messages_item_data.to_dict()
            messages.append(messages_item)



        model_name = self.model_name

        model_provider = self.model_provider.value

        type_ = self.type_

        auto_name: None | str | Unset
        if isinstance(self.auto_name, Unset):
            auto_name = UNSET
        else:
            auto_name = self.auto_name

        tools: list[dict[str, Any]] | None | Unset
        if isinstance(self.tools, Unset):
            tools = UNSET
        elif isinstance(self.tools, list):
            tools = []
            for tools_type_0_item_data in self.tools:
                tools_type_0_item = tools_type_0_item_data.to_dict()
                tools.append(tools_type_0_item)


        else:
            tools = self.tools

        config: dict[str, Any] | None | Unset
        if isinstance(self.config, Unset):
            config = UNSET
        elif isinstance(self.config, UnsavedPromptConfigConfigType0):
            config = self.config.to_dict()
        else:
            config = self.config

        variables: list[str] | None | Unset
        if isinstance(self.variables, Unset):
            variables = UNSET
        elif isinstance(self.variables, list):
            variables = self.variables


        else:
            variables = self.variables


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "messages": messages,
            "model_name": model_name,
            "model_provider": model_provider,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_
        if auto_name is not UNSET:
            field_dict["auto_name"] = auto_name
        if tools is not UNSET:
            field_dict["tools"] = tools
        if config is not UNSET:
            field_dict["config"] = config
        if variables is not UNSET:
            field_dict["variables"] = variables

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.unsaved_prompt_config_messages_item import UnsavedPromptConfigMessagesItem
        from ..models.unsaved_prompt_config_tools_type_0_item import UnsavedPromptConfigToolsType0Item
        from ..models.unsaved_prompt_config_config_type_0 import UnsavedPromptConfigConfigType0
        d = dict(src_dict)
        messages = []
        _messages = d.pop("messages")
        for messages_item_data in (_messages):
            messages_item = UnsavedPromptConfigMessagesItem.from_dict(messages_item_data)



            messages.append(messages_item)


        model_name = d.pop("model_name")

        model_provider = ModelProvider(d.pop("model_provider"))




        type_ = cast(Literal['unsaved'] | Unset , d.pop("type", UNSET))
        if type_ != 'unsaved'and not isinstance(type_, Unset):
            raise ValueError(f"type must match const 'unsaved', got '{type_}'")

        def _parse_auto_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        auto_name = _parse_auto_name(d.pop("auto_name", UNSET))


        def _parse_tools(data: object) -> list[UnsavedPromptConfigToolsType0Item] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tools_type_0 = []
                _tools_type_0 = data
                for tools_type_0_item_data in (_tools_type_0):
                    tools_type_0_item = UnsavedPromptConfigToolsType0Item.from_dict(tools_type_0_item_data)



                    tools_type_0.append(tools_type_0_item)

                return tools_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[UnsavedPromptConfigToolsType0Item] | None | Unset, data)

        tools = _parse_tools(d.pop("tools", UNSET))


        def _parse_config(data: object) -> None | UnsavedPromptConfigConfigType0 | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                config_type_0 = UnsavedPromptConfigConfigType0.from_dict(data)



                return config_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | UnsavedPromptConfigConfigType0 | Unset, data)

        config = _parse_config(d.pop("config", UNSET))


        def _parse_variables(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                variables_type_0 = cast(list[str], data)

                return variables_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        variables = _parse_variables(d.pop("variables", UNSET))


        unsaved_prompt_config = cls(
            messages=messages,
            model_name=model_name,
            model_provider=model_provider,
            type_=type_,
            auto_name=auto_name,
            tools=tools,
            config=config,
            variables=variables,
        )


        unsaved_prompt_config.additional_properties = d
        return unsaved_prompt_config

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
