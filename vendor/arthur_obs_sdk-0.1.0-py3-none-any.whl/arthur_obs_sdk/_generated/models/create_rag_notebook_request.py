from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.rag_notebook_state import RagNotebookState





T = TypeVar("T", bound="CreateRagNotebookRequest")



@_attrs_define
class CreateRagNotebookRequest:
    """ Request to create a new RAG notebook

        Attributes:
            name (str): Name of the notebook
            description (None | str | Unset): Description
            state (None | RagNotebookState | Unset): Initial state
     """

    name: str
    description: None | str | Unset = UNSET
    state: None | RagNotebookState | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rag_notebook_state import RagNotebookState
        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        state: dict[str, Any] | None | Unset
        if isinstance(self.state, Unset):
            state = UNSET
        elif isinstance(self.state, RagNotebookState):
            state = self.state.to_dict()
        else:
            state = self.state


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "name": name,
        })
        if description is not UNSET:
            field_dict["description"] = description
        if state is not UNSET:
            field_dict["state"] = state

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rag_notebook_state import RagNotebookState
        d = dict(src_dict)
        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_state(data: object) -> None | RagNotebookState | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                state_type_0 = RagNotebookState.from_dict(data)



                return state_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | RagNotebookState | Unset, data)

        state = _parse_state(d.pop("state", UNSET))


        create_rag_notebook_request = cls(
            name=name,
            description=description,
            state=state,
        )


        create_rag_notebook_request.additional_properties = d
        return create_rag_notebook_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
