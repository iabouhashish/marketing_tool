from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="PIIConfig")



@_attrs_define
class PIIConfig:
    """ 
        Example:
            {'allow_list': ['arthur.ai', 'Arthur'], 'confidence_threshold': '0.5', 'disabled_pii_entities': ['PERSON',
                'URL']}

        Attributes:
            disabled_pii_entities (list[str] | None | Unset): Optional. List of PII entities to disable. Valid values are: C
                REDIT_CARD,CRYPTO,DATE_TIME,EMAIL_ADDRESS,IBAN_CODE,IP_ADDRESS,NRP,LOCATION,PERSON,PHONE_NUMBER,MEDICAL_LICENSE,
                URL,US_BANK_NUMBER,US_DRIVER_LICENSE,US_ITIN,US_PASSPORT,US_SSN
            confidence_threshold (float | None | Unset): Optional. Float (0, 1) indicating the level of tolerable PII to
                consider the rule passed or failed. Min: 0 (less confident) Max: 1 (very confident). Default: 0 Default: 0.0.
            allow_list (list[str] | None | Unset): Optional. List of strings to pass PII validation.
     """

    disabled_pii_entities: list[str] | None | Unset = UNSET
    confidence_threshold: float | None | Unset = 0.0
    allow_list: list[str] | None | Unset = UNSET





    def to_dict(self) -> dict[str, Any]:
        disabled_pii_entities: list[str] | None | Unset
        if isinstance(self.disabled_pii_entities, Unset):
            disabled_pii_entities = UNSET
        elif isinstance(self.disabled_pii_entities, list):
            disabled_pii_entities = self.disabled_pii_entities


        else:
            disabled_pii_entities = self.disabled_pii_entities

        confidence_threshold: float | None | Unset
        if isinstance(self.confidence_threshold, Unset):
            confidence_threshold = UNSET
        else:
            confidence_threshold = self.confidence_threshold

        allow_list: list[str] | None | Unset
        if isinstance(self.allow_list, Unset):
            allow_list = UNSET
        elif isinstance(self.allow_list, list):
            allow_list = self.allow_list


        else:
            allow_list = self.allow_list


        field_dict: dict[str, Any] = {}

        field_dict.update({
        })
        if disabled_pii_entities is not UNSET:
            field_dict["disabled_pii_entities"] = disabled_pii_entities
        if confidence_threshold is not UNSET:
            field_dict["confidence_threshold"] = confidence_threshold
        if allow_list is not UNSET:
            field_dict["allow_list"] = allow_list

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_disabled_pii_entities(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                disabled_pii_entities_type_0 = cast(list[str], data)

                return disabled_pii_entities_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        disabled_pii_entities = _parse_disabled_pii_entities(d.pop("disabled_pii_entities", UNSET))


        def _parse_confidence_threshold(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        confidence_threshold = _parse_confidence_threshold(d.pop("confidence_threshold", UNSET))


        def _parse_allow_list(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                allow_list_type_0 = cast(list[str], data)

                return allow_list_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        allow_list = _parse_allow_list(d.pop("allow_list", UNSET))


        pii_config = cls(
            disabled_pii_entities=disabled_pii_entities,
            confidence_threshold=confidence_threshold,
            allow_list=allow_list,
        )

        return pii_config

