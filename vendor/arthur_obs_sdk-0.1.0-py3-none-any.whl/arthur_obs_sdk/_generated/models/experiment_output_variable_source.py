from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast
from typing import Literal, cast

if TYPE_CHECKING:
  from ..models.experiment_output_source import ExperimentOutputSource





T = TypeVar("T", bound="ExperimentOutputVariableSource")



@_attrs_define
class ExperimentOutputVariableSource:
    """ Variable source from experiment output

        Attributes:
            type_ (Literal['experiment_output']): Type of source: 'experiment_output'
            experiment_output (ExperimentOutputSource): Reference to experiment output
     """

    type_: Literal['experiment_output']
    experiment_output: ExperimentOutputSource
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.experiment_output_source import ExperimentOutputSource
        type_ = self.type_

        experiment_output = self.experiment_output.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "type": type_,
            "experiment_output": experiment_output,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.experiment_output_source import ExperimentOutputSource
        d = dict(src_dict)
        type_ = cast(Literal['experiment_output'] , d.pop("type"))
        if type_ != 'experiment_output':
            raise ValueError(f"type must match const 'experiment_output', got '{type_}'")

        experiment_output = ExperimentOutputSource.from_dict(d.pop("experiment_output"))




        experiment_output_variable_source = cls(
            type_=type_,
            experiment_output=experiment_output,
        )


        experiment_output_variable_source.additional_properties = d
        return experiment_output_variable_source

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
