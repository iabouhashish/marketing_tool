from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
import datetime

if TYPE_CHECKING:
  from ..models.span_with_metrics_response_raw_data import SpanWithMetricsResponseRawData
  from ..models.metric_result_response import MetricResultResponse





T = TypeVar("T", bound="SpanWithMetricsResponse")



@_attrs_define
class SpanWithMetricsResponse:
    """ 
        Attributes:
            id (str):
            trace_id (str):
            span_id (str):
            start_time (datetime.datetime):
            end_time (datetime.datetime):
            status_code (str): Status code for the span (Unset, Error, Ok)
            created_at (datetime.datetime):
            updated_at (datetime.datetime):
            raw_data (SpanWithMetricsResponseRawData):
            prompt_token_count (int | None | Unset): Number of prompt tokens
            completion_token_count (int | None | Unset): Number of completion tokens
            total_token_count (int | None | Unset): Total number of tokens
            prompt_token_cost (float | None | Unset): Cost of prompt tokens in USD
            completion_token_cost (float | None | Unset): Cost of completion tokens in USD
            total_token_cost (float | None | Unset): Total cost in USD
            parent_span_id (None | str | Unset):
            span_kind (None | str | Unset):
            span_name (None | str | Unset):
            task_id (None | str | Unset):
            session_id (None | str | Unset):
            input_content (None | str | Unset): Span input value from raw_data.attributes.input.value
            output_content (None | str | Unset): Span output value from raw_data.attributes.output.value
            metric_results (list[MetricResultResponse] | Unset): List of metric results for this span
     """

    id: str
    trace_id: str
    span_id: str
    start_time: datetime.datetime
    end_time: datetime.datetime
    status_code: str
    created_at: datetime.datetime
    updated_at: datetime.datetime
    raw_data: SpanWithMetricsResponseRawData
    prompt_token_count: int | None | Unset = UNSET
    completion_token_count: int | None | Unset = UNSET
    total_token_count: int | None | Unset = UNSET
    prompt_token_cost: float | None | Unset = UNSET
    completion_token_cost: float | None | Unset = UNSET
    total_token_cost: float | None | Unset = UNSET
    parent_span_id: None | str | Unset = UNSET
    span_kind: None | str | Unset = UNSET
    span_name: None | str | Unset = UNSET
    task_id: None | str | Unset = UNSET
    session_id: None | str | Unset = UNSET
    input_content: None | str | Unset = UNSET
    output_content: None | str | Unset = UNSET
    metric_results: list[MetricResultResponse] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.span_with_metrics_response_raw_data import SpanWithMetricsResponseRawData
        from ..models.metric_result_response import MetricResultResponse
        id = self.id

        trace_id = self.trace_id

        span_id = self.span_id

        start_time = self.start_time.isoformat()

        end_time = self.end_time.isoformat()

        status_code = self.status_code

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        raw_data = self.raw_data.to_dict()

        prompt_token_count: int | None | Unset
        if isinstance(self.prompt_token_count, Unset):
            prompt_token_count = UNSET
        else:
            prompt_token_count = self.prompt_token_count

        completion_token_count: int | None | Unset
        if isinstance(self.completion_token_count, Unset):
            completion_token_count = UNSET
        else:
            completion_token_count = self.completion_token_count

        total_token_count: int | None | Unset
        if isinstance(self.total_token_count, Unset):
            total_token_count = UNSET
        else:
            total_token_count = self.total_token_count

        prompt_token_cost: float | None | Unset
        if isinstance(self.prompt_token_cost, Unset):
            prompt_token_cost = UNSET
        else:
            prompt_token_cost = self.prompt_token_cost

        completion_token_cost: float | None | Unset
        if isinstance(self.completion_token_cost, Unset):
            completion_token_cost = UNSET
        else:
            completion_token_cost = self.completion_token_cost

        total_token_cost: float | None | Unset
        if isinstance(self.total_token_cost, Unset):
            total_token_cost = UNSET
        else:
            total_token_cost = self.total_token_cost

        parent_span_id: None | str | Unset
        if isinstance(self.parent_span_id, Unset):
            parent_span_id = UNSET
        else:
            parent_span_id = self.parent_span_id

        span_kind: None | str | Unset
        if isinstance(self.span_kind, Unset):
            span_kind = UNSET
        else:
            span_kind = self.span_kind

        span_name: None | str | Unset
        if isinstance(self.span_name, Unset):
            span_name = UNSET
        else:
            span_name = self.span_name

        task_id: None | str | Unset
        if isinstance(self.task_id, Unset):
            task_id = UNSET
        else:
            task_id = self.task_id

        session_id: None | str | Unset
        if isinstance(self.session_id, Unset):
            session_id = UNSET
        else:
            session_id = self.session_id

        input_content: None | str | Unset
        if isinstance(self.input_content, Unset):
            input_content = UNSET
        else:
            input_content = self.input_content

        output_content: None | str | Unset
        if isinstance(self.output_content, Unset):
            output_content = UNSET
        else:
            output_content = self.output_content

        metric_results: list[dict[str, Any]] | Unset = UNSET
        if not isinstance(self.metric_results, Unset):
            metric_results = []
            for metric_results_item_data in self.metric_results:
                metric_results_item = metric_results_item_data.to_dict()
                metric_results.append(metric_results_item)




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "trace_id": trace_id,
            "span_id": span_id,
            "start_time": start_time,
            "end_time": end_time,
            "status_code": status_code,
            "created_at": created_at,
            "updated_at": updated_at,
            "raw_data": raw_data,
        })
        if prompt_token_count is not UNSET:
            field_dict["prompt_token_count"] = prompt_token_count
        if completion_token_count is not UNSET:
            field_dict["completion_token_count"] = completion_token_count
        if total_token_count is not UNSET:
            field_dict["total_token_count"] = total_token_count
        if prompt_token_cost is not UNSET:
            field_dict["prompt_token_cost"] = prompt_token_cost
        if completion_token_cost is not UNSET:
            field_dict["completion_token_cost"] = completion_token_cost
        if total_token_cost is not UNSET:
            field_dict["total_token_cost"] = total_token_cost
        if parent_span_id is not UNSET:
            field_dict["parent_span_id"] = parent_span_id
        if span_kind is not UNSET:
            field_dict["span_kind"] = span_kind
        if span_name is not UNSET:
            field_dict["span_name"] = span_name
        if task_id is not UNSET:
            field_dict["task_id"] = task_id
        if session_id is not UNSET:
            field_dict["session_id"] = session_id
        if input_content is not UNSET:
            field_dict["input_content"] = input_content
        if output_content is not UNSET:
            field_dict["output_content"] = output_content
        if metric_results is not UNSET:
            field_dict["metric_results"] = metric_results

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.span_with_metrics_response_raw_data import SpanWithMetricsResponseRawData
        from ..models.metric_result_response import MetricResultResponse
        d = dict(src_dict)
        id = d.pop("id")

        trace_id = d.pop("trace_id")

        span_id = d.pop("span_id")

        start_time = isoparse(d.pop("start_time"))




        end_time = isoparse(d.pop("end_time"))




        status_code = d.pop("status_code")

        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        raw_data = SpanWithMetricsResponseRawData.from_dict(d.pop("raw_data"))




        def _parse_prompt_token_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        prompt_token_count = _parse_prompt_token_count(d.pop("prompt_token_count", UNSET))


        def _parse_completion_token_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        completion_token_count = _parse_completion_token_count(d.pop("completion_token_count", UNSET))


        def _parse_total_token_count(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        total_token_count = _parse_total_token_count(d.pop("total_token_count", UNSET))


        def _parse_prompt_token_cost(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        prompt_token_cost = _parse_prompt_token_cost(d.pop("prompt_token_cost", UNSET))


        def _parse_completion_token_cost(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        completion_token_cost = _parse_completion_token_cost(d.pop("completion_token_cost", UNSET))


        def _parse_total_token_cost(data: object) -> float | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(float | None | Unset, data)

        total_token_cost = _parse_total_token_cost(d.pop("total_token_cost", UNSET))


        def _parse_parent_span_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        parent_span_id = _parse_parent_span_id(d.pop("parent_span_id", UNSET))


        def _parse_span_kind(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        span_kind = _parse_span_kind(d.pop("span_kind", UNSET))


        def _parse_span_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        span_name = _parse_span_name(d.pop("span_name", UNSET))


        def _parse_task_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        task_id = _parse_task_id(d.pop("task_id", UNSET))


        def _parse_session_id(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        session_id = _parse_session_id(d.pop("session_id", UNSET))


        def _parse_input_content(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        input_content = _parse_input_content(d.pop("input_content", UNSET))


        def _parse_output_content(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        output_content = _parse_output_content(d.pop("output_content", UNSET))


        _metric_results = d.pop("metric_results", UNSET)
        metric_results: list[MetricResultResponse] | Unset = UNSET
        if _metric_results is not UNSET:
            metric_results = []
            for metric_results_item_data in _metric_results:
                metric_results_item = MetricResultResponse.from_dict(metric_results_item_data)



                metric_results.append(metric_results_item)


        span_with_metrics_response = cls(
            id=id,
            trace_id=trace_id,
            span_id=span_id,
            start_time=start_time,
            end_time=end_time,
            status_code=status_code,
            created_at=created_at,
            updated_at=updated_at,
            raw_data=raw_data,
            prompt_token_count=prompt_token_count,
            completion_token_count=completion_token_count,
            total_token_count=total_token_count,
            prompt_token_cost=prompt_token_cost,
            completion_token_cost=completion_token_cost,
            total_token_cost=total_token_cost,
            parent_span_id=parent_span_id,
            span_kind=span_kind,
            span_name=span_name,
            task_id=task_id,
            session_id=session_id,
            input_content=input_content,
            output_content=output_content,
            metric_results=metric_results,
        )


        span_with_metrics_response.additional_properties = d
        return span_with_metrics_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
