from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.variable_template_value import VariableTemplateValue





T = TypeVar("T", bound="BaseCompletionRequest")



@_attrs_define
class BaseCompletionRequest:
    """ 
        Attributes:
            variables (list[VariableTemplateValue] | None | Unset): List of VariableTemplateValue fields that specify the
                values to fill in for each template in the prompt
     """

    variables: list[VariableTemplateValue] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.variable_template_value import VariableTemplateValue
        variables: list[dict[str, Any]] | None | Unset
        if isinstance(self.variables, Unset):
            variables = UNSET
        elif isinstance(self.variables, list):
            variables = []
            for variables_type_0_item_data in self.variables:
                variables_type_0_item = variables_type_0_item_data.to_dict()
                variables.append(variables_type_0_item)


        else:
            variables = self.variables


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if variables is not UNSET:
            field_dict["variables"] = variables

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.variable_template_value import VariableTemplateValue
        d = dict(src_dict)
        def _parse_variables(data: object) -> list[VariableTemplateValue] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                variables_type_0 = []
                _variables_type_0 = data
                for variables_type_0_item_data in (_variables_type_0):
                    variables_type_0_item = VariableTemplateValue.from_dict(variables_type_0_item_data)



                    variables_type_0.append(variables_type_0_item)

                return variables_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[VariableTemplateValue] | None | Unset, data)

        variables = _parse_variables(d.pop("variables", UNSET))


        base_completion_request = cls(
            variables=variables,
        )


        base_completion_request.additional_properties = d
        return base_completion_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
