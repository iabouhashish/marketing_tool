from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.pii_entity_span_response import PIIEntitySpanResponse





T = TypeVar("T", bound="PIIDetailsResponse")



@_attrs_define
class PIIDetailsResponse:
    """ 
        Attributes:
            pii_entities (list[PIIEntitySpanResponse]):
            score (bool | None | Unset):
            message (None | str | Unset):
     """

    pii_entities: list[PIIEntitySpanResponse]
    score: bool | None | Unset = UNSET
    message: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.pii_entity_span_response import PIIEntitySpanResponse
        pii_entities = []
        for pii_entities_item_data in self.pii_entities:
            pii_entities_item = pii_entities_item_data.to_dict()
            pii_entities.append(pii_entities_item)



        score: bool | None | Unset
        if isinstance(self.score, Unset):
            score = UNSET
        else:
            score = self.score

        message: None | str | Unset
        if isinstance(self.message, Unset):
            message = UNSET
        else:
            message = self.message


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "pii_entities": pii_entities,
        })
        if score is not UNSET:
            field_dict["score"] = score
        if message is not UNSET:
            field_dict["message"] = message

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.pii_entity_span_response import PIIEntitySpanResponse
        d = dict(src_dict)
        pii_entities = []
        _pii_entities = d.pop("pii_entities")
        for pii_entities_item_data in (_pii_entities):
            pii_entities_item = PIIEntitySpanResponse.from_dict(pii_entities_item_data)



            pii_entities.append(pii_entities_item)


        def _parse_score(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        score = _parse_score(d.pop("score", UNSET))


        def _parse_message(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        message = _parse_message(d.pop("message", UNSET))


        pii_details_response = cls(
            pii_entities=pii_entities,
            score=score,
            message=message,
        )


        pii_details_response.additional_properties = d
        return pii_details_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
