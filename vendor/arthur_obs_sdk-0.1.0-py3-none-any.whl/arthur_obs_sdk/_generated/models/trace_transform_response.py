from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from dateutil.parser import isoparse
from typing import cast
from uuid import UUID
import datetime

if TYPE_CHECKING:
  from ..models.trace_transform_definition import TraceTransformDefinition





T = TypeVar("T", bound="TraceTransformResponse")



@_attrs_define
class TraceTransformResponse:
    """ 
        Attributes:
            id (UUID): ID of the transform.
            task_id (str): ID of the parent task.
            name (str): Name of the transform.
            definition (TraceTransformDefinition):
            created_at (datetime.datetime): Timestamp representing the time of transform creation
            updated_at (datetime.datetime): Timestamp representing the time of the last transform update
            description (None | str | Unset): Description of the transform.
     """

    id: UUID
    task_id: str
    name: str
    definition: TraceTransformDefinition
    created_at: datetime.datetime
    updated_at: datetime.datetime
    description: None | str | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.trace_transform_definition import TraceTransformDefinition
        id = str(self.id)

        task_id = self.task_id

        name = self.name

        definition = self.definition.to_dict()

        created_at = self.created_at.isoformat()

        updated_at = self.updated_at.isoformat()

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "task_id": task_id,
            "name": name,
            "definition": definition,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if description is not UNSET:
            field_dict["description"] = description

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.trace_transform_definition import TraceTransformDefinition
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        task_id = d.pop("task_id")

        name = d.pop("name")

        definition = TraceTransformDefinition.from_dict(d.pop("definition"))




        created_at = isoparse(d.pop("created_at"))




        updated_at = isoparse(d.pop("updated_at"))




        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        trace_transform_response = cls(
            id=id,
            task_id=task_id,
            name=name,
            definition=definition,
            created_at=created_at,
            updated_at=updated_at,
            description=description,
        )


        trace_transform_response.additional_properties = d
        return trace_transform_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
