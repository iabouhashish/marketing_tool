from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.rag_search_setting_configuration_version_response import RagSearchSettingConfigurationVersionResponse





T = TypeVar("T", bound="RagSearchSettingConfigurationResponse")



@_attrs_define
class RagSearchSettingConfigurationResponse:
    """ 
        Attributes:
            id (UUID): ID of the setting configuration.
            task_id (str): ID of the parent task.
            name (str): Name of the setting configuration.
            latest_version_number (int): The latest version number of the settings configuration.
            latest_version (RagSearchSettingConfigurationVersionResponse):
            created_at (int): Time the RAG settings configuration was created in unix milliseconds.
            updated_at (int): Time the RAG settings configuration was updated in unix milliseconds. Will be updated if a new
                version of the configuration was created.
            rag_provider_id (None | Unset | UUID): ID of the rag provider to use with the settings. None if initial rag
                provider configuration was deleted.
            description (None | str | Unset): Description of the setting configuration.
            all_possible_tags (list[str] | None | Unset): Set of all tags applied for any version of the settings
                configuration.
     """

    id: UUID
    task_id: str
    name: str
    latest_version_number: int
    latest_version: RagSearchSettingConfigurationVersionResponse
    created_at: int
    updated_at: int
    rag_provider_id: None | Unset | UUID = UNSET
    description: None | str | Unset = UNSET
    all_possible_tags: list[str] | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.rag_search_setting_configuration_version_response import RagSearchSettingConfigurationVersionResponse
        id = str(self.id)

        task_id = self.task_id

        name = self.name

        latest_version_number = self.latest_version_number

        latest_version = self.latest_version.to_dict()

        created_at = self.created_at

        updated_at = self.updated_at

        rag_provider_id: None | str | Unset
        if isinstance(self.rag_provider_id, Unset):
            rag_provider_id = UNSET
        elif isinstance(self.rag_provider_id, UUID):
            rag_provider_id = str(self.rag_provider_id)
        else:
            rag_provider_id = self.rag_provider_id

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        all_possible_tags: list[str] | None | Unset
        if isinstance(self.all_possible_tags, Unset):
            all_possible_tags = UNSET
        elif isinstance(self.all_possible_tags, list):
            all_possible_tags = self.all_possible_tags


        else:
            all_possible_tags = self.all_possible_tags


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "task_id": task_id,
            "name": name,
            "latest_version_number": latest_version_number,
            "latest_version": latest_version,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if rag_provider_id is not UNSET:
            field_dict["rag_provider_id"] = rag_provider_id
        if description is not UNSET:
            field_dict["description"] = description
        if all_possible_tags is not UNSET:
            field_dict["all_possible_tags"] = all_possible_tags

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.rag_search_setting_configuration_version_response import RagSearchSettingConfigurationVersionResponse
        d = dict(src_dict)
        id = UUID(d.pop("id"))




        task_id = d.pop("task_id")

        name = d.pop("name")

        latest_version_number = d.pop("latest_version_number")

        latest_version = RagSearchSettingConfigurationVersionResponse.from_dict(d.pop("latest_version"))




        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        def _parse_rag_provider_id(data: object) -> None | Unset | UUID:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, str):
                    raise TypeError()
                rag_provider_id_type_0 = UUID(data)



                return rag_provider_id_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | UUID, data)

        rag_provider_id = _parse_rag_provider_id(d.pop("rag_provider_id", UNSET))


        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        def _parse_all_possible_tags(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                all_possible_tags_type_0 = cast(list[str], data)

                return all_possible_tags_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        all_possible_tags = _parse_all_possible_tags(d.pop("all_possible_tags", UNSET))


        rag_search_setting_configuration_response = cls(
            id=id,
            task_id=task_id,
            name=name,
            latest_version_number=latest_version_number,
            latest_version=latest_version,
            created_at=created_at,
            updated_at=updated_at,
            rag_provider_id=rag_provider_id,
            description=description,
            all_possible_tags=all_possible_tags,
        )


        rag_search_setting_configuration_response.additional_properties = d
        return rag_search_setting_configuration_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
