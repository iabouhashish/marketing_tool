from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.tool_call_function import ToolCallFunction





T = TypeVar("T", bound="ToolCall")



@_attrs_define
class ToolCall:
    """ 
        Attributes:
            id (str): Unique identifier for the tool call
            function (ToolCallFunction):
            type_ (str | Unset): The type of tool call. Currently the only type supported is 'function'. Default:
                'function'.
     """

    id: str
    function: ToolCallFunction
    type_: str | Unset = 'function'
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.tool_call_function import ToolCallFunction
        id = self.id

        function = self.function.to_dict()

        type_ = self.type_


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "function": function,
        })
        if type_ is not UNSET:
            field_dict["type"] = type_

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.tool_call_function import ToolCallFunction
        d = dict(src_dict)
        id = d.pop("id")

        function = ToolCallFunction.from_dict(d.pop("function"))




        type_ = d.pop("type", UNSET)

        tool_call = cls(
            id=id,
            function=function,
            type_=type_,
        )


        tool_call.additional_properties = d
        return tool_call

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
