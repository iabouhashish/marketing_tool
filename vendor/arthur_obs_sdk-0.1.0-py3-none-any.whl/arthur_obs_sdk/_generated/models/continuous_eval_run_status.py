from enum import Enum

class ContinuousEvalRunStatus(str, Enum):
    ERROR = "error"
    FAILED = "failed"
    PASSED = "passed"
    PENDING = "pending"
    RUNNING = "running"
    SKIPPED = "skipped"

    def __str__(self) -> str:
        return str(self.value)
