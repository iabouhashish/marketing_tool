from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.variable_rendering_request import VariableRenderingRequest
  from ..models.open_ai_message import OpenAIMessage





T = TypeVar("T", bound="UnsavedPromptRenderingRequest")



@_attrs_define
class UnsavedPromptRenderingRequest:
    """ Request schema for rendering an unsaved agentic prompt with variables

        Attributes:
            messages (list[OpenAIMessage]): List of chat messages in OpenAI format (e.g., [{'role': 'user', 'content':
                'Hello'}])
            completion_request (VariableRenderingRequest | Unset):
     """

    messages: list[OpenAIMessage]
    completion_request: VariableRenderingRequest | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.variable_rendering_request import VariableRenderingRequest
        from ..models.open_ai_message import OpenAIMessage
        messages = []
        for messages_item_data in self.messages:
            messages_item = messages_item_data.to_dict()
            messages.append(messages_item)



        completion_request: dict[str, Any] | Unset = UNSET
        if not isinstance(self.completion_request, Unset):
            completion_request = self.completion_request.to_dict()


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "messages": messages,
        })
        if completion_request is not UNSET:
            field_dict["completion_request"] = completion_request

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.variable_rendering_request import VariableRenderingRequest
        from ..models.open_ai_message import OpenAIMessage
        d = dict(src_dict)
        messages = []
        _messages = d.pop("messages")
        for messages_item_data in (_messages):
            messages_item = OpenAIMessage.from_dict(messages_item_data)



            messages.append(messages_item)


        _completion_request = d.pop("completion_request", UNSET)
        completion_request: VariableRenderingRequest | Unset
        if isinstance(_completion_request,  Unset):
            completion_request = UNSET
        else:
            completion_request = VariableRenderingRequest.from_dict(_completion_request)




        unsaved_prompt_rendering_request = cls(
            messages=messages,
            completion_request=completion_request,
        )


        unsaved_prompt_rendering_request.additional_properties = d
        return unsaved_prompt_rendering_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
