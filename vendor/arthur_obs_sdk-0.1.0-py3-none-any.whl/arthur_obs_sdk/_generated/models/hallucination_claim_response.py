from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="HallucinationClaimResponse")



@_attrs_define
class HallucinationClaimResponse:
    """ 
        Attributes:
            claim (str):
            valid (bool):
            reason (str):
            order_number (int | None | Unset): This field is a helper for ordering the claims Default: -1.
     """

    claim: str
    valid: bool
    reason: str
    order_number: int | None | Unset = -1
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        claim = self.claim

        valid = self.valid

        reason = self.reason

        order_number: int | None | Unset
        if isinstance(self.order_number, Unset):
            order_number = UNSET
        else:
            order_number = self.order_number


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "claim": claim,
            "valid": valid,
            "reason": reason,
        })
        if order_number is not UNSET:
            field_dict["order_number"] = order_number

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        claim = d.pop("claim")

        valid = d.pop("valid")

        reason = d.pop("reason")

        def _parse_order_number(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        order_number = _parse_order_number(d.pop("order_number", UNSET))


        hallucination_claim_response = cls(
            claim=claim,
            valid=valid,
            reason=reason,
            order_number=order_number,
        )


        hallucination_claim_response.additional_properties = d
        return hallucination_claim_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
