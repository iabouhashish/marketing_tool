from enum import Enum

class MetricType(str, Enum):
    QUERYRELEVANCE = "QueryRelevance"
    RESPONSERELEVANCE = "ResponseRelevance"
    TOOLSELECTION = "ToolSelection"

    def __str__(self) -> str:
        return str(self.value)
