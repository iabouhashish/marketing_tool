from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from typing import cast






T = TypeVar("T", bound="ChatRequest")



@_attrs_define
class ChatRequest:
    """ 
        Attributes:
            user_prompt (str): Prompt user wants to send to chat.
            conversation_id (str): Conversation ID
            file_ids (list[str]): list of file IDs to retrieve from during chat.
     """

    user_prompt: str
    conversation_id: str
    file_ids: list[str]
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        user_prompt = self.user_prompt

        conversation_id = self.conversation_id

        file_ids = self.file_ids




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "user_prompt": user_prompt,
            "conversation_id": conversation_id,
            "file_ids": file_ids,
        })

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        user_prompt = d.pop("user_prompt")

        conversation_id = d.pop("conversation_id")

        file_ids = cast(list[str], d.pop("file_ids"))


        chat_request = cls(
            user_prompt=user_prompt,
            conversation_id=conversation_id,
            file_ids=file_ids,
        )


        chat_request.additional_properties = d
        return chat_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
