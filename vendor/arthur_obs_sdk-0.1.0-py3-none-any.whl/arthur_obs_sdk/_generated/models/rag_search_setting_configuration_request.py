from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.weaviate_vector_similarity_text_search_settings_configuration_request import WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest
  from ..models.weaviate_hybrid_search_settings_configuration_request import WeaviateHybridSearchSettingsConfigurationRequest
  from ..models.weaviate_keyword_search_settings_configuration_request import WeaviateKeywordSearchSettingsConfigurationRequest





T = TypeVar("T", bound="RagSearchSettingConfigurationRequest")



@_attrs_define
class RagSearchSettingConfigurationRequest:
    """ 
        Attributes:
            settings (WeaviateHybridSearchSettingsConfigurationRequest | WeaviateKeywordSearchSettingsConfigurationRequest |
                WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest): Settings configuration for a search request to
                a RAG provider.
            rag_provider_id (UUID): ID of the rag provider to use with the settings.
            name (str): Name of the search setting configuration.
            description (None | str | Unset): Description of the search setting configuration.
            tags (list[str] | Unset): List of tags to configure for this version of the search settings configuration.
     """

    settings: WeaviateHybridSearchSettingsConfigurationRequest | WeaviateKeywordSearchSettingsConfigurationRequest | WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest
    rag_provider_id: UUID
    name: str
    description: None | str | Unset = UNSET
    tags: list[str] | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.weaviate_vector_similarity_text_search_settings_configuration_request import WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest
        from ..models.weaviate_hybrid_search_settings_configuration_request import WeaviateHybridSearchSettingsConfigurationRequest
        from ..models.weaviate_keyword_search_settings_configuration_request import WeaviateKeywordSearchSettingsConfigurationRequest
        settings: dict[str, Any]
        if isinstance(self.settings, WeaviateHybridSearchSettingsConfigurationRequest):
            settings = self.settings.to_dict()
        elif isinstance(self.settings, WeaviateKeywordSearchSettingsConfigurationRequest):
            settings = self.settings.to_dict()
        else:
            settings = self.settings.to_dict()


        rag_provider_id = str(self.rag_provider_id)

        name = self.name

        description: None | str | Unset
        if isinstance(self.description, Unset):
            description = UNSET
        else:
            description = self.description

        tags: list[str] | Unset = UNSET
        if not isinstance(self.tags, Unset):
            tags = self.tags




        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "settings": settings,
            "rag_provider_id": rag_provider_id,
            "name": name,
        })
        if description is not UNSET:
            field_dict["description"] = description
        if tags is not UNSET:
            field_dict["tags"] = tags

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.weaviate_vector_similarity_text_search_settings_configuration_request import WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest
        from ..models.weaviate_hybrid_search_settings_configuration_request import WeaviateHybridSearchSettingsConfigurationRequest
        from ..models.weaviate_keyword_search_settings_configuration_request import WeaviateKeywordSearchSettingsConfigurationRequest
        d = dict(src_dict)
        def _parse_settings(data: object) -> WeaviateHybridSearchSettingsConfigurationRequest | WeaviateKeywordSearchSettingsConfigurationRequest | WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest:
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                settings_type_0 = WeaviateHybridSearchSettingsConfigurationRequest.from_dict(data)



                return settings_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                settings_type_1 = WeaviateKeywordSearchSettingsConfigurationRequest.from_dict(data)



                return settings_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            if not isinstance(data, dict):
                raise TypeError()
            settings_type_2 = WeaviateVectorSimilarityTextSearchSettingsConfigurationRequest.from_dict(data)



            return settings_type_2

        settings = _parse_settings(d.pop("settings"))


        rag_provider_id = UUID(d.pop("rag_provider_id"))




        name = d.pop("name")

        def _parse_description(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        description = _parse_description(d.pop("description", UNSET))


        tags = cast(list[str], d.pop("tags", UNSET))


        rag_search_setting_configuration_request = cls(
            settings=settings,
            rag_provider_id=rag_provider_id,
            name=name,
            description=description,
            tags=tags,
        )


        rag_search_setting_configuration_request.additional_properties = d
        return rag_search_setting_configuration_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
