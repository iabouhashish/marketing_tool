from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast






T = TypeVar("T", bound="SearchTasksRequest")



@_attrs_define
class SearchTasksRequest:
    """ 
        Attributes:
            task_ids (list[str] | None | Unset): List of tasks to query for.
            task_name (None | str | Unset): Task name substring search string.
            is_agentic (bool | None | Unset): Filter tasks by agentic status. If not provided, returns both agentic and non-
                agentic tasks.
     """

    task_ids: list[str] | None | Unset = UNSET
    task_name: None | str | Unset = UNSET
    is_agentic: bool | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        task_ids: list[str] | None | Unset
        if isinstance(self.task_ids, Unset):
            task_ids = UNSET
        elif isinstance(self.task_ids, list):
            task_ids = self.task_ids


        else:
            task_ids = self.task_ids

        task_name: None | str | Unset
        if isinstance(self.task_name, Unset):
            task_name = UNSET
        else:
            task_name = self.task_name

        is_agentic: bool | None | Unset
        if isinstance(self.is_agentic, Unset):
            is_agentic = UNSET
        else:
            is_agentic = self.is_agentic


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
        })
        if task_ids is not UNSET:
            field_dict["task_ids"] = task_ids
        if task_name is not UNSET:
            field_dict["task_name"] = task_name
        if is_agentic is not UNSET:
            field_dict["is_agentic"] = is_agentic

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        d = dict(src_dict)
        def _parse_task_ids(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                task_ids_type_0 = cast(list[str], data)

                return task_ids_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        task_ids = _parse_task_ids(d.pop("task_ids", UNSET))


        def _parse_task_name(data: object) -> None | str | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(None | str | Unset, data)

        task_name = _parse_task_name(d.pop("task_name", UNSET))


        def _parse_is_agentic(data: object) -> bool | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(bool | None | Unset, data)

        is_agentic = _parse_is_agentic(d.pop("is_agentic", UNSET))


        search_tasks_request = cls(
            task_ids=task_ids,
            task_name=task_name,
            is_agentic=is_agentic,
        )


        search_tasks_request.additional_properties = d
        return search_tasks_request

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
