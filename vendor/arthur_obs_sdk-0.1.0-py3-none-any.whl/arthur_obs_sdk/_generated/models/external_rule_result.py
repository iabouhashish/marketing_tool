from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..models.rule_result_enum import RuleResultEnum
from ..models.rule_scope import RuleScope
from ..models.rule_type import RuleType
from ..types import UNSET, Unset
from typing import cast

if TYPE_CHECKING:
  from ..models.regex_details_response import RegexDetailsResponse
  from ..models.keyword_details_response import KeywordDetailsResponse
  from ..models.pii_details_response import PIIDetailsResponse
  from ..models.hallucination_details_response import HallucinationDetailsResponse
  from ..models.base_details_response import BaseDetailsResponse
  from ..models.toxicity_details_response import ToxicityDetailsResponse





T = TypeVar("T", bound="ExternalRuleResult")



@_attrs_define
class ExternalRuleResult:
    """ 
        Example:
            {'id': '90f18c69-d793-4913-9bde-a0c7f3643de0', 'name': 'PII Rule', 'result': 'Pass'}

        Attributes:
            id (str):  ID of the rule
            name (str): Name of the rule
            rule_type (RuleType):
            scope (RuleScope):
            result (RuleResultEnum):
            latency_ms (int): Duration in millisesconds of rule execution
            details (BaseDetailsResponse | HallucinationDetailsResponse | KeywordDetailsResponse | None | PIIDetailsResponse
                | RegexDetailsResponse | ToxicityDetailsResponse | Unset): Details of the rule output
     """

    id: str
    name: str
    rule_type: RuleType
    scope: RuleScope
    result: RuleResultEnum
    latency_ms: int
    details: BaseDetailsResponse | HallucinationDetailsResponse | KeywordDetailsResponse | None | PIIDetailsResponse | RegexDetailsResponse | ToxicityDetailsResponse | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.regex_details_response import RegexDetailsResponse
        from ..models.keyword_details_response import KeywordDetailsResponse
        from ..models.pii_details_response import PIIDetailsResponse
        from ..models.hallucination_details_response import HallucinationDetailsResponse
        from ..models.base_details_response import BaseDetailsResponse
        from ..models.toxicity_details_response import ToxicityDetailsResponse
        id = self.id

        name = self.name

        rule_type = self.rule_type.value

        scope = self.scope.value

        result = self.result.value

        latency_ms = self.latency_ms

        details: dict[str, Any] | None | Unset
        if isinstance(self.details, Unset):
            details = UNSET
        elif isinstance(self.details, KeywordDetailsResponse):
            details = self.details.to_dict()
        elif isinstance(self.details, RegexDetailsResponse):
            details = self.details.to_dict()
        elif isinstance(self.details, HallucinationDetailsResponse):
            details = self.details.to_dict()
        elif isinstance(self.details, PIIDetailsResponse):
            details = self.details.to_dict()
        elif isinstance(self.details, ToxicityDetailsResponse):
            details = self.details.to_dict()
        elif isinstance(self.details, BaseDetailsResponse):
            details = self.details.to_dict()
        else:
            details = self.details


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "id": id,
            "name": name,
            "rule_type": rule_type,
            "scope": scope,
            "result": result,
            "latency_ms": latency_ms,
        })
        if details is not UNSET:
            field_dict["details"] = details

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.regex_details_response import RegexDetailsResponse
        from ..models.keyword_details_response import KeywordDetailsResponse
        from ..models.pii_details_response import PIIDetailsResponse
        from ..models.hallucination_details_response import HallucinationDetailsResponse
        from ..models.base_details_response import BaseDetailsResponse
        from ..models.toxicity_details_response import ToxicityDetailsResponse
        d = dict(src_dict)
        id = d.pop("id")

        name = d.pop("name")

        rule_type = RuleType(d.pop("rule_type"))




        scope = RuleScope(d.pop("scope"))




        result = RuleResultEnum(d.pop("result"))




        latency_ms = d.pop("latency_ms")

        def _parse_details(data: object) -> BaseDetailsResponse | HallucinationDetailsResponse | KeywordDetailsResponse | None | PIIDetailsResponse | RegexDetailsResponse | ToxicityDetailsResponse | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                details_type_0 = KeywordDetailsResponse.from_dict(data)



                return details_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                details_type_1 = RegexDetailsResponse.from_dict(data)



                return details_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                details_type_2 = HallucinationDetailsResponse.from_dict(data)



                return details_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                details_type_3 = PIIDetailsResponse.from_dict(data)



                return details_type_3
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                details_type_4 = ToxicityDetailsResponse.from_dict(data)



                return details_type_4
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                details_type_5 = BaseDetailsResponse.from_dict(data)



                return details_type_5
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(BaseDetailsResponse | HallucinationDetailsResponse | KeywordDetailsResponse | None | PIIDetailsResponse | RegexDetailsResponse | ToxicityDetailsResponse | Unset, data)

        details = _parse_details(d.pop("details", UNSET))


        external_rule_result = cls(
            id=id,
            name=name,
            rule_type=rule_type,
            scope=scope,
            result=result,
            latency_ms=latency_ms,
            details=details,
        )


        external_rule_result.additional_properties = d
        return external_rule_result

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
