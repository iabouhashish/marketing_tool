from __future__ import annotations

from collections.abc import Mapping
from typing import Any, TypeVar, BinaryIO, TextIO, TYPE_CHECKING, Generator

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

from ..types import UNSET, Unset
from typing import cast
from uuid import UUID

if TYPE_CHECKING:
  from ..models.weaviate_hybrid_search_settings_configuration_response import WeaviateHybridSearchSettingsConfigurationResponse
  from ..models.weaviate_keyword_search_settings_configuration_response import WeaviateKeywordSearchSettingsConfigurationResponse
  from ..models.weaviate_vector_similarity_text_search_settings_configuration_response import WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse





T = TypeVar("T", bound="RagSearchSettingConfigurationVersionResponse")



@_attrs_define
class RagSearchSettingConfigurationVersionResponse:
    """ 
        Attributes:
            setting_configuration_id (UUID): ID of the parent setting configuration.
            version_number (int): Version number of the setting configuration.
            created_at (int): Time the RAG provider settings configuration version was created in unix milliseconds
            updated_at (int): Time the RAG provider settings configuration version was updated in unix milliseconds
            tags (list[str] | None | Unset): Optional list of tags configured for this version of the settings
                configuration.
            settings (None | Unset | WeaviateHybridSearchSettingsConfigurationResponse |
                WeaviateKeywordSearchSettingsConfigurationResponse |
                WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse): Settings configuration for a search request to
                a RAG provider. None if version has been soft-deleted.
            deleted_at (int | None | Unset): Time the RAG provider settings configuration version was soft-deleted in unix
                milliseconds
     """

    setting_configuration_id: UUID
    version_number: int
    created_at: int
    updated_at: int
    tags: list[str] | None | Unset = UNSET
    settings: None | Unset | WeaviateHybridSearchSettingsConfigurationResponse | WeaviateKeywordSearchSettingsConfigurationResponse | WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse = UNSET
    deleted_at: int | None | Unset = UNSET
    additional_properties: dict[str, Any] = _attrs_field(init=False, factory=dict)





    def to_dict(self) -> dict[str, Any]:
        from ..models.weaviate_hybrid_search_settings_configuration_response import WeaviateHybridSearchSettingsConfigurationResponse
        from ..models.weaviate_keyword_search_settings_configuration_response import WeaviateKeywordSearchSettingsConfigurationResponse
        from ..models.weaviate_vector_similarity_text_search_settings_configuration_response import WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse
        setting_configuration_id = str(self.setting_configuration_id)

        version_number = self.version_number

        created_at = self.created_at

        updated_at = self.updated_at

        tags: list[str] | None | Unset
        if isinstance(self.tags, Unset):
            tags = UNSET
        elif isinstance(self.tags, list):
            tags = self.tags


        else:
            tags = self.tags

        settings: dict[str, Any] | None | Unset
        if isinstance(self.settings, Unset):
            settings = UNSET
        elif isinstance(self.settings, WeaviateHybridSearchSettingsConfigurationResponse):
            settings = self.settings.to_dict()
        elif isinstance(self.settings, WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse):
            settings = self.settings.to_dict()
        elif isinstance(self.settings, WeaviateKeywordSearchSettingsConfigurationResponse):
            settings = self.settings.to_dict()
        else:
            settings = self.settings

        deleted_at: int | None | Unset
        if isinstance(self.deleted_at, Unset):
            deleted_at = UNSET
        else:
            deleted_at = self.deleted_at


        field_dict: dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "setting_configuration_id": setting_configuration_id,
            "version_number": version_number,
            "created_at": created_at,
            "updated_at": updated_at,
        })
        if tags is not UNSET:
            field_dict["tags"] = tags
        if settings is not UNSET:
            field_dict["settings"] = settings
        if deleted_at is not UNSET:
            field_dict["deleted_at"] = deleted_at

        return field_dict



    @classmethod
    def from_dict(cls: type[T], src_dict: Mapping[str, Any]) -> T:
        from ..models.weaviate_hybrid_search_settings_configuration_response import WeaviateHybridSearchSettingsConfigurationResponse
        from ..models.weaviate_keyword_search_settings_configuration_response import WeaviateKeywordSearchSettingsConfigurationResponse
        from ..models.weaviate_vector_similarity_text_search_settings_configuration_response import WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse
        d = dict(src_dict)
        setting_configuration_id = UUID(d.pop("setting_configuration_id"))




        version_number = d.pop("version_number")

        created_at = d.pop("created_at")

        updated_at = d.pop("updated_at")

        def _parse_tags(data: object) -> list[str] | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, list):
                    raise TypeError()
                tags_type_0 = cast(list[str], data)

                return tags_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(list[str] | None | Unset, data)

        tags = _parse_tags(d.pop("tags", UNSET))


        def _parse_settings(data: object) -> None | Unset | WeaviateHybridSearchSettingsConfigurationResponse | WeaviateKeywordSearchSettingsConfigurationResponse | WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                settings_type_0 = WeaviateHybridSearchSettingsConfigurationResponse.from_dict(data)



                return settings_type_0
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                settings_type_1 = WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse.from_dict(data)



                return settings_type_1
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            try:
                if not isinstance(data, dict):
                    raise TypeError()
                settings_type_2 = WeaviateKeywordSearchSettingsConfigurationResponse.from_dict(data)



                return settings_type_2
            except (TypeError, ValueError, AttributeError, KeyError):
                pass
            return cast(None | Unset | WeaviateHybridSearchSettingsConfigurationResponse | WeaviateKeywordSearchSettingsConfigurationResponse | WeaviateVectorSimilarityTextSearchSettingsConfigurationResponse, data)

        settings = _parse_settings(d.pop("settings", UNSET))


        def _parse_deleted_at(data: object) -> int | None | Unset:
            if data is None:
                return data
            if isinstance(data, Unset):
                return data
            return cast(int | None | Unset, data)

        deleted_at = _parse_deleted_at(d.pop("deleted_at", UNSET))


        rag_search_setting_configuration_version_response = cls(
            setting_configuration_id=setting_configuration_id,
            version_number=version_number,
            created_at=created_at,
            updated_at=updated_at,
            tags=tags,
            settings=settings,
            deleted_at=deleted_at,
        )


        rag_search_setting_configuration_version_response.additional_properties = d
        return rag_search_setting_configuration_version_response

    @property
    def additional_keys(self) -> list[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
